// Search aliases stay out of the visible guide.
const GUIDE = [
  {
    cat: '논문 보관', items: [
      { t: 'PDF 추가하기', k: ['업로드', '열기', '드래그', '여러 개', '중복', '오프라인'], b: [
        '<b>PDF 추가</b>를 누르거나 PDF를 화면에 끌어다 놓으세요. 원문 읽기와 메모에는 AI 계정이 필요 없습니다.',
        '여러 편을 넣으면 파일마다 결과가 표시됩니다. 실패한 파일만 다시 시도할 수 있습니다. 같은 PDF는 기존 논문으로 연결됩니다.',
        '바로 번역하려면 <b>PDF 추가</b> 옆 화살표(<b>PDF 추가 옵션</b>)를 열고 <b>추가하면서 번역·요약</b>을 선택하세요. 추가한 논문 내용이 연결한 AI 서비스에 전송됩니다.'] },
      { t: 'Windows 폴더에서 PDF 자동으로 가져오기', k: ['연결', '감시', '디렉터리', '원본', '동기화'], b: [
        'Windows 앱 홈에서 <b>PDF 추가 ▾ → PDF 폴더 연결</b>을 누르고 평소 PDF를 보관하는 폴더를 고르세요.',
        '앱 창을 열어 두면 그 폴더 바로 안에 넣은 PDF가 라이브러리에 추가됩니다. 원본은 그대로 남습니다.',
        '홈의 <b>⋯ → Windows 앱 관리 → PDF 폴더</b>에서 연결할 폴더를 바꾸거나 연결을 해제할 수 있습니다. 이미 가져온 논문과 메모는 계속 열 수 있습니다.'] },
      { t: '폴더로 정리하기', k: ['주제', '분류', '이동', '삭제'], b: [
        '홈에서 <b>라이브러리</b>를 열고 <b>정리</b>를 누르세요. 논문 옆의 <b>이동</b>을 눌러 보관할 폴더를 고르세요.',
        '여러 편을 한꺼번에 옮기려면 논문들을 선택한 뒤 <b>폴더로 이동</b>을 누르세요.',
        '폴더를 지우면 안에 있던 논문은 <b>미분류</b>에 남습니다.'] },
      { t: '여러 논문을 비교표로 읽기', k: ['엑셀', '비교', '열', 'xlsx', 'csv', '표', '실험', '폴더 요약'], b: [
        '홈의 <b>⋯ → 논문 비교표 → 새 표</b>에서 논문을 고르세요. <b>내 PC</b>에서는 PDF 여러 편이나 하위 폴더를 포함한 폴더를 고를 수 있습니다.',
        '<b>열 설정</b>에서 항목과 순서를 정하거나 AI에 원하는 열을 설명하세요. <b>표 만들기</b>를 누르면 완료된 논문부터 한 행씩 나타납니다.',
        '논문 이름을 누르면 항목별 내용과 <b>원문 근거</b>를 읽을 수 있습니다. 표와 인용문은 이 PC에 보관됩니다. <b>저장된 표 → 다운로드</b>에서 Excel 또는 CSV로 받을 수 있습니다.'] },
      { t: '백업과 복원', k: ['데이터', '메모', '복구', '새 컴퓨터'], b: [
        'Windows 앱 홈에서 <b>⋯ → Windows 앱 관리 → 백업 및 복원 → 라이브러리 백업</b>을 선택하세요. PDF, 폴더, 요약과 메모가 백업 ZIP 하나에 저장됩니다.',
        '복원하려면 같은 메뉴에서 <b>백업에서 복원</b>을 누르고 백업 ZIP을 고르세요. 복원이 끝나면 Sunlight가 다시 시작됩니다. 1.4 이전에 만든 백업 폴더는 그 안의 <code>backup.json</code>을 고르세요.'] },
    ],
  },
  {
    cat: '읽기와 메모', items: [
      { t: '원문과 번역 나란히 보기', k: ['병렬', '문단', '툴팁', '마우스'], b: [
        '논문을 처음 번역할 때는 상단의 <b>번역 시작</b>을 누르세요. 번역본이 준비되면 <b>병렬</b>로 원문과 번역을 나란히 볼 수 있습니다.',
        '번역한 문단에 마우스를 올리면 원문이 보입니다. 병렬 보기에서는 양쪽의 같은 문단이 강조됩니다.'] },
      { t: '페이지 이동, 확대와 논문 도구', k: ['확대', '축소', '화면 맞춤', '폭 맞춤', '쪽 맞춤', '쪽 번호', '패널', '너비', 'zoom', '목차'], b: [
        '상단의 쪽 번호 칸에 쪽을 입력하고 <kbd>Enter</kbd>를 누르면 그 쪽으로 이동합니다. 논문에 목차가 있으면 <b>목차</b>에서 장을 고를 수 있습니다.',
        '상단의 <b>−</b>, <b>+</b>, <b>폭 맞춤</b>, <b>쪽 맞춤</b>으로 배율을 바꾸세요. 논문 위에서 <kbd>Ctrl</kbd>을 누른 채 휠을 돌려도 됩니다. 좁은 창에서는 <b>⋯</b>에 있습니다.',
        '상단의 <b>논문 도구</b>를 누르면 요약·대화·메모가 열립니다. 넓은 창에서는 본문과 도구 사이의 경계를 드래그하거나 방향키로 너비를 조절하세요. <kbd>Enter</kbd>로 기본 너비를 복원합니다.'] },
      { t: '문장과 문단 선택', k: ['드래그', '¶', '여러 문단', '트리플클릭', '키보드'], b: [
        '문장을 드래그하세요. 문단 전체는 세 번 클릭하거나 왼쪽 여백의 <b>¶</b>를 누르면 선택됩니다.',
        '<kbd>Shift</kbd>를 누른 채 다른 문단을 클릭하면 선택에 추가하거나 뺄 수 있습니다.',
        '키보드로는 논문 화면에서 <kbd>Enter</kbd>를 눌러 맨 위 문단을 고르고, <kbd>Alt</kbd>와 <kbd>↑</kbd>/<kbd>↓</kbd>로 다른 문단이나 그림으로 옮기세요. <kbd>Shift</kbd>를 함께 누르면 문단을 더합니다.'] },
      { t: '논문 속 링크 따라가기', k: ['링크', '참고문헌', '인용', '그림 번호', '뒤로'], b: [
        '논문 안의 링크(참고문헌, 그림·표 번호, 웹 주소)를 누르면 해당 위치로 이동하거나 웹 주소가 새 창에서 열립니다.',
        '논문 안에서 이동했다면 왼쪽 아래 <b>← 이전 위치</b>나 <kbd>Alt</kbd>+<kbd>←</kbd>로 읽던 곳으로 돌아갑니다.',
        '키보드로는 <kbd>Alt</kbd>+<kbd>L</kbd>로 보이는 쪽의 첫 링크에 가고, 방향키로 다른 링크를 고른 뒤 <kbd>Enter</kbd>로 따라갑니다. <kbd>Esc</kbd>로 본문에 돌아옵니다.'] },
      { t: '논문 안에서 찾기', k: ['검색', 'Ctrl+F', '찾기', '단어'], b: [
        '<kbd>Ctrl</kbd>+<kbd>F</kbd>나 상단의 <b>찾기</b>를 누르고 찾을 말을 입력하세요. 원문과 번역에서 찾은 곳이 페이지에 표시됩니다.',
        '<kbd>Enter</kbd>로 다음, <kbd>Shift</kbd>+<kbd>Enter</kbd>로 이전 결과로 이동합니다. <b>결과 목록</b>에서 쪽별로 볼 수 있습니다.'] },
      { t: '하이라이트와 메모', k: ['강조', '형광펜', '색', '노트', '저장'], b: [
        '본문을 선택하고 색을 고르세요. 바로 메모를 쓰려면 <b>메모</b>(<kbd>N</kbd>)를 누르세요. <b>논문 도구 → 메모</b>에서 표시한 곳을 다시 열거나 메모를 쓸 수 있습니다.',
        '페이지의 하이라이트를 누르면 색 바꾸기, 메모, 삭제를 고를 수 있습니다.',
        '메모는 자동으로 저장됩니다. 저장하지 못하면 메모 옆의 <b>다시 저장</b>을 누르세요.'] },
    ],
  },
  {
    cat: '번역과 질문', items: [
      { t: '문장 번역과 단어 뜻', k: ['T', '사전', '원문', '문맥'], b: [
        '원문을 선택하고 <b>번역</b>을 누르세요. 단어 하나를 고르면 그 문장에서 쓰인 뜻을 설명합니다.',
        '번역본에서는 <b>원문</b>을 눌러 해당 문단을 확인할 수 있습니다. 두 동작의 단축키는 <kbd>T</kbd>입니다.'] },
      { t: '문장이나 그림에 설명 띄우기', k: ['설명', '팝업', '영역', '그림', '표', '수식', 'E', 'R', '캡처'], b: [
        '문장을 선택하거나 그림·표·수식을 클릭한 뒤 <b>설명</b>을 누르세요. 읽던 위치에 설명창이 열립니다. 그림을 직접 지정하려면 <b>영역 선택</b>을 누르고 범위를 드래그하세요.',
        '선택한 글이나 잘라낸 이미지와 해당 쪽 본문이 연결한 AI로 전송됩니다. 남기려면 <b>메모에 추가</b>나 <b>대화에 저장</b>을 누르세요.',
        '페이지를 넘겨도 설명창은 그대로 남습니다. 창 오른쪽 아래를 끌어 크기를 바꾸고, <b>×</b>나 <kbd>Esc</kbd>로 닫으세요.'] },
      { t: '논문에 질문하기', k: ['대화', '채팅', 'Q&A', '첨부', 'Q', '쪽수'], b: [
        '대화 탭에 질문을 쓰세요. 특정 문장이나 그림에 관해 물으려면 먼저 선택한 뒤 <b>질문</b>을 누르세요.',
        '질문과 논문 본문이 연결한 AI에 전송됩니다. 번역본에서 선택한 글에는 대응하는 원문도 함께 첨부됩니다.',
        '<kbd>Enter</kbd>로 보내고 <kbd>Shift</kbd>와 <kbd>Enter</kbd>로 줄을 바꿉니다. 대화 기록은 논문별로 저장됩니다.'] },
      { t: '요약에서 근거 찾기', k: ['3줄', '키워드', '인용', '연구', '한계', '중지'], b: [
        '<b>요약</b> 탭에서 요약을 시작하세요. 새 요약은 핵심 문장과 인용문을 대조한 뒤 저장합니다.',
        '핵심 문장 아래 쪽수를 누르면 인용한 페이지가 열립니다. 요약을 다시 만들다 실패해도 이전에 저장한 요약은 볼 수 있습니다.'] },
    ],
  },
  {
    cat: '설정과 내보내기', items: [
      { t: '내 계정 연결', k: ['Codex', 'Claude', 'Gemini', 'ChatGPT', 'Google', '로그인', '설치', '구독'], b: [
        '오른쪽 위 <b>⋯ → 설정</b>에서 사용할 AI 서비스(Codex, Claude, Gemini)를 고르세요. <b>연결하기</b>를 누르고 열린 창에서 본인 계정으로 로그인하세요.',
        '설치가 필요한 경우 <b>설치하고 연결</b>을 누르세요. 설정에 <b>연결됨</b>이 표시되면 번역·요약·질문을 사용할 수 있습니다.'] },
      { t: '모델과 번역 언어 바꾸기', k: ['GPT', 'Sonnet', '속도', '추론 강도', '동시 번역', '글꼴'], b: [
        '설정에서 모델과 번역 언어를 고르세요. <b>고급</b>에서 추론 강도를 번역과 요약·대화에 각각 지정할 수 있습니다. Gemini에는 추론 강도 설정이 없습니다.',
        '<b>고급</b>에서 동시에 번역할 쪽 수를 줄이면 한꺼번에 보내는 요청도 줄어듭니다. 이미 번역한 논문에 새 언어를 적용하려면 독서 화면의 <b>⋯</b>에서 <b>전체 다시 번역</b>을 선택하세요.'] },
      { t: 'PDF와 메모 내보내기', k: ['다운로드', 'PDF', '저장', 'Markdown', 'md', '인쇄'], b: [
        '독서 화면 오른쪽 위 <b>⋯ → 내보내기</b>에서 원문 PDF나 번역 PDF를 고르세요. <b>원문+번역 PDF</b>는 원문과 번역을 한 쪽씩 번갈아 담습니다.',
        '<b>요약·메모 .md</b>는 요약과 하이라이트, 메모를 Markdown 파일로 저장합니다. <b>⋯ → 폴더에서 보기</b>로 논문 파일이 있는 폴더를 열 수 있습니다.'] },
    ],
  },
  {
    cat: '문제 해결', items: [
      { t: '글자가 선택되지 않을 때', k: ['스캔', '텍스트', 'OCR', '이미지'], b: [
        '스캔한 PDF에는 선택할 글자가 없을 수 있습니다. 그림으로 읽으려면 <b>영역 선택</b>을 누르세요. 문장 선택이나 전체 번역이 필요하면 OCR로 글자를 인식한 사본을 추가하세요.'] },
      { t: '번역을 멈추거나 이어서 하기', k: ['중지', '이어서', '중단', '연결', '느림', '오류', '재번역', '한도'], b: [
        '번역·요약 중에는 상단 진행 표시줄의 <b>중지</b>로 멈출 수 있습니다. 끝난 쪽은 남습니다. Sunlight를 다시 열면 멈춘 작업에 <b>이어서 하기</b>가 표시됩니다.',
        '실패한 쪽이 표시되면 <b>실패한 쪽 다시 번역</b>을 누르세요. 로그인이나 사용 한도 오류가 표시되면 AI 계정의 연결 상태를 확인하세요.',
        '반복되는 오류는 홈의 <b>⋯ → Windows 앱 관리 → 진단 정보 저장</b>으로 기록할 수 있습니다.'] },
      { t: '원본 PDF가 사라졌을 때', k: ['누락', '복구', '하이라이트', '백업'], b: [
        '라이브러리에 같은 원본 PDF를 다시 추가하라는 안내가 보이면 해당 파일을 고르세요. 기존 폴더와 메모가 다시 연결됩니다.',
        '백업에서 복구하라는 안내가 보이면 홈의 <b>⋯ → Windows 앱 관리 → 백업 및 복원 → 백업에서 복원</b>을 누르고 백업 ZIP을 고르세요. 복원 뒤 Sunlight가 다시 시작됩니다.'] },
    ],
  },
  {
    cat: '단축키', items: [
      { t: '문서를 읽을 때 쓰는 키', k: ['키보드', 'shortcut', '단축키'], b: [
        '<kbd>T</kbd> 번역 또는 원문 보기　<kbd>E</kbd> 설명　<kbd>Q</kbd> 질문　<kbd>N</kbd> 메모',
        '<kbd>Ctrl</kbd>+<kbd>+</kbd> / <kbd>Ctrl</kbd>+<kbd>−</kbd> 확대·축소　<kbd>Ctrl</kbd>+<kbd>0</kbd> 폭 맞춤　<kbd>Alt</kbd>+<kbd>←</kbd> 링크를 누르기 전 위치로',
        '<kbd>R</kbd> 영역 선택　<kbd>+</kbd> 확대　<kbd>−</kbd> 축소　<kbd>Ctrl</kbd>+<kbd>F</kbd> 찾기',
        '<kbd>Esc</kbd> 닫기 또는 선택 취소　<kbd>?</kbd> 사용법',
        '한 글자 단축키는 논문 화면에 초점이 있을 때만 동작합니다. <b>설정 → 고급</b>에서 끌 수 있습니다.'] },
    ],
  },
];

const strip = h => h.replace(/<[^>]+>/g, '');
const mark = (html, q) => !q ? html : html.replace(/(>|^)([^<]+)/g, (m, a, txt) =>
  a + txt.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), s => `<mark>${s}</mark>`));

function renderGuide(q = '') {
  q = q.trim();
  const ql = q.toLowerCase();
  const body = document.getElementById('guideBody');
  const nav = document.getElementById('guideNav');
  let html = '', count = 0;
  for (const sec of GUIDE) {
    const items = sec.items.filter(it => !ql || [it.t, sec.cat, ...it.k, ...it.b.map(strip)].join(' ').toLowerCase().includes(ql));
    if (!items.length) continue;
    count += items.length;
    html += `<section class="g-sec" id="g-${sec.cat}"><h3>${sec.cat}</h3>${items.map(it => `
      <details class="g-item"${q ? ' open' : ''}><summary class="g-t">${mark(it.t, q)}</summary>
        <ul>${it.b.map(x => `<li>${mark(x, q)}</li>`).join('')}</ul></details>`).join('')}</section>`;
  }
  body.innerHTML = html || '<p class="empty" role="status">검색 결과가 없습니다. 다른 단어로 검색해 보세요.</p>';
  body.scrollTop = 0;
  nav.innerHTML = GUIDE.map(s => `<button type="button" data-sec="${s.cat}">${s.cat}</button>`).join('');
  nav.classList.toggle('hidden', !!q);
  nav.querySelectorAll('button').forEach(b => b.onclick = () => {
    const section = document.getElementById(`g-${b.dataset.sec}`);
    section?.querySelector('summary')?.focus({ preventScroll: true });
    section?.scrollIntoView({ block: 'start' });
  });
  document.getElementById('guideCount').textContent = q ? `${count}개` : '';
}

const guide = document.getElementById('guideModal');
let guideTrigger;
export function openGuide() {
  if (guide.open) return;
  guideTrigger = document.activeElement;
  const inp = document.getElementById('guideSearch');
  inp.value = '';
  renderGuide();
  guide.classList.remove('hidden');
  guide.showModal();
  inp.focus();
}
export function closeGuide() {
  if (!guide.open) return;
  guide.close();
  guide.classList.add('hidden');
  if (guideTrigger?.isConnected) guideTrigger.focus({ preventScroll: true });
}

document.getElementById('guideSearch').addEventListener('input', e => renderGuide(e.target.value));
let downOnBackdrop = false;
guide.addEventListener('pointerdown', e => { downOnBackdrop = e.target === guide; });
guide.addEventListener('click', e => {
  const backdrop = downOnBackdrop && e.target === guide;
  downOnBackdrop = false;
  if (backdrop || e.target.closest('[data-gclose]')) closeGuide();
});
guide.addEventListener('cancel', e => {
  e.preventDefault();
  closeGuide();
});
document.querySelectorAll('[data-guide]').forEach(b => b.onclick = openGuide);
document.addEventListener('keydown', e => {
  if (e.key !== '?' || e.ctrlKey || e.altKey || e.metaKey || e.isComposing) return;
  try { if (localStorage.getItem('sl.shortcuts') === 'off') return; } catch { /* default on */ }
  if (document.querySelector('dialog[open]') || e.target.matches?.('input, textarea, select, [contenteditable="true"]')) return;
  e.preventDefault();
  openGuide();
}, true);
