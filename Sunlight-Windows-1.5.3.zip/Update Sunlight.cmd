@echo off
rem Update or roll back Sunlight without opening the app. The signed Sunlight maintenance tool does
rem the work (no PowerShell). Usage:
rem   "Update Sunlight.cmd"                  choose a Sunlight Windows ZIP
rem   "Update Sunlight.cmd" -RestorePrevious  go back to the version in app.previous
setlocal
set "SUNLIGHT_TOOL=%~dp0app\tools\Sunlight.Maintenance.exe"
if not exist "%SUNLIGHT_TOOL%" set "SUNLIGHT_TOOL=%~dp0app.previous\tools\Sunlight.Maintenance.exe"
if not exist "%SUNLIGHT_TOOL%" goto missing
if /i "%~1"=="-RestorePrevious" (
  start "" "%SUNLIGHT_TOOL%" --restore-previous --install "%~dp0." --restart
  exit /b 0
)
if "%~1"=="" (
  start "" "%SUNLIGHT_TOOL%" --pick-zip --install "%~dp0." --restart
  exit /b 0
)
start "" "%SUNLIGHT_TOOL%" %* --install "%~dp0."
exit /b 0

:missing
chcp 65001 >nul
echo Sunlight 관리 도구를 찾지 못했습니다. Sunlight 설치 파일로 다시 설치하세요. 논문과 메모는 그대로입니다.
pause
exit /b 1
