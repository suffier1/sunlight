// Entry point: pdf.js setup, module wiring, routing and boot. Each feature lives in its own module:
//   ui-kit.js (api, errors, toast, dialogs, server events) · settings.js · home.js (library glue)
//   reader/paper.js (open/close, jobs) · layout.js (pages, zoom) · navigation.js · selection.js
//   notes.js · explain.js · chat.js · summary.js · search.js · panel.js · pointer.js · keys.js
import * as pdfjsLib from './vendor/pdfjs/pdf.min.mjs?v=2';
import './guide.js?v=9';
import { $, S } from './reader/state.js';
import { NO_SERVER, loadSettings, warmSettings, onEngineChange, onSettingsSaved, chatScopeText, engineReady } from './settings.js';
import { showLibrary, leaveLibrary } from './home.js';
import { openPaper, syncPaper } from './reader/paper.js';
import { refreshScopes } from './reader/selection.js';
import { refreshSummaryScopes } from './reader/summary.js';
import './reader/pointer.js';
import './reader/keys.js';
import './reader/zoom-controls.js';

pdfjsLib.GlobalWorkerOptions.workerSrc = './vendor/pdfjs/pdf.worker.min.mjs';
if (navigator.platform.startsWith('Win')) {
  // Edge can resolve a generic family differently in the PDF.js measuring canvas
  // and the selectable text under the Korean UI. Use the same faces in both.
  const families = pdfjsLib.TextLayer.fontFamilyMap;
  families.set('serif', '"Times New Roman", "Malgun Gothic", serif');
  families.set('sans-serif', 'Arial, "Malgun Gothic", sans-serif');
  families.set('monospace', 'Consolas, "Malgun Gothic", monospace');
}

onEngineChange(() => {
  $('#chatScope').textContent = chatScopeText();
  // "AI 연결 필요" in the 대화 tab once discovery says the chosen service is not connected
  $('#chatAiHint').hidden = !S.backends || S.statusPending || engineReady();
  refreshScopes();
  refreshSummaryScopes();
});

// a new PDF font rebuilds the open paper's translated PDF in the background
onSettingsSaved(({ refont }) => { if (refont && S.paper) setTimeout(() => syncPaper(S.sess), 1000); });

window.addEventListener('hashchange', route);
function route() {
  const m = location.hash.match(/^#\/paper\/([\w-]+)/);
  if (m) { leaveLibrary(); openPaper(decodeURIComponent(m[1])); } else showLibrary();
}

async function boot() {
  try { await loadSettings(true); } catch (e) {
    if (e?.code === 'session') return;  // ui-kit shows "Sunlight 앱에서 열어 주세요"
    $('#library').classList.remove('hidden'); $('#reader').classList.add('hidden');
    const li = document.createElement('li');
    li.className = 'empty';
    li.textContent = NO_SERVER;
    const acts = document.createElement('div'); acts.className = 'err-acts';
    const retry = document.createElement('button'); retry.type = 'button'; retry.className = 'btn sm'; retry.textContent = '다시 시도';
    retry.onclick = () => { retry.disabled = true; boot(); };
    acts.append(retry); li.append(acts);
    $('#paperList').replaceChildren(li);
    return;
  }
  route();
  warmSettings();
}
boot();
