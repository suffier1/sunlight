// App commands shared by the home ⋯ menu and the reader ⋯ menu. Both menus carry the same items
// (논문 비교표, 설정, 휴대폰 연결, 전체 화면, 사용법, Windows actions, then Sunlight 종료 set apart),
// so each command is bound by attribute rather than by id.
//   kit: ui-kit ({confirmDialog, toast, errorText}); openSettings(); openMobile(); exitApp(button) → Promise.
export function bindAppCommands({ kit, openSettings, openMobile, exitApp }) {
  document.addEventListener('click', async event => {
    const button = event.target.closest?.('[data-open-settings], [data-open-mobile], [data-exit-sunlight]');
    if (!button || button.disabled) return;
    if (button.matches('[data-open-settings]')) { openSettings(); return; }
    if (button.matches('[data-open-mobile]')) { openMobile(); return; }
    const ok = await kit.confirmDialog({
      title: 'Sunlight를 종료할까요?',
      body: '진행 중인 번역·요약·비교표는 중지됩니다. 끝난 부분은 보관되고, 다음에 실행하면 이어서 할 수 있습니다.',
      confirm: '종료', danger: true,
    });
    if (!ok) return;
    button.disabled = true;
    try { await exitApp(button); }
    catch (error) { button.disabled = false; kit.toast(`종료하지 못했습니다 · ${kit.errorText(error)}`, { kind: 'error' }); }
  });
}

// Enable Windows actions only after the local desktop host confirms support.
const host = window.chrome?.webview;
if (host) {
  const groups = document.querySelectorAll('[data-desktop-actions]');
  const folder = document.querySelector('#connectPdfFolder');
  const template = document.querySelector('#desktopActions');
  const triggers = document.querySelectorAll('[data-app-menu-trigger], #moreBtn');
  for (const group of groups) {
    group.append(template.content.cloneNode(true));
    group.querySelector('[data-desktop-update]').onclick = () => host.postMessage('sunlight-check-update');
    group.querySelector('[data-desktop-manage]').onclick = () => host.postMessage('sunlight-desktop-menu');
  }
  if (folder) folder.onclick = () => host.postMessage('sunlight-select-pdf-folder');
  document.addEventListener('keydown', event => {
    if (!folder || folder.hidden || !event.altKey || event.ctrlKey || event.metaKey || event.shiftKey ||
        event.key.toLowerCase() !== 'f' || document.querySelector('dialog[open]') ||
        event.target.closest?.('input, textarea, select, [contenteditable="true"]')) return;
    event.preventDefault();
    host.postMessage('sunlight-desktop-menu');
  });
  host.addEventListener('message', ({ data }) => {
    if (data?.type !== 'sunlight-desktop-status') return;
    const version = typeof data.updateVersion === 'string' && /^\d+\.\d+\.\d+$/.test(data.updateVersion)
      ? data.updateVersion : '';
    for (const group of groups) {
      group.hidden = false;
      group.querySelector('[data-desktop-update]').textContent = version ? `${version} 업데이트…` : '업데이트 확인…';
    }
    if (folder) folder.hidden = false;
    for (const trigger of triggers) {
      trigger.toggleAttribute('data-update-available', Boolean(version));
      if (version) trigger.setAttribute('aria-description', `${version} 업데이트가 있습니다.`);
      else trigger.removeAttribute('aria-description');
    }
  });
  host.postMessage('sunlight-desktop-ready');
}
