// Glue between the shell modules (library-ui, upload-ui, review-ui, desktop-menu: E2) and the reader.
// The shell modules receive the shared ui-kit by injection; library-ui owns its refresh/polling.
import * as uiKit from './ui-kit.js';
import { $, S } from './reader/state.js';
import { createLibraryUI } from './library-ui.js';
import { bindPdfImport, sendPdf } from './upload-ui.js';
import { bindAppCommands } from './desktop-menu.js';
import { requireEngine, engineName, engineReady, openSettings, onEngineChange, exitApp } from './settings.js';
import { closeReader, openPaperAt } from './reader/paper.js';

const libShown = () => !$('#library').classList.contains('hidden');
// openPaperAt(pid, {page (1-based), hid}): opens a paper at a page or at a highlight's note (memo search hits)
export const libraryUI = createLibraryUI({
  kit: uiKit, isShown: libShown, openSettings: () => openSettings(), openPaperAt,
  aiStatus: () => ({ pending: S.statusPending, ready: engineReady(), name: engineName() }),
});
const refreshLibrary = () => libraryUI.refresh();

export async function showLibrary() {
  const paperId = S.paper?.id;
  const heading = $('#libFolderTitle');
  closeReader();
  $('#library').classList.remove('hidden');
  $('#reader').classList.add('hidden');
  document.title = 'Sunlight';
  if (paperId) heading.focus({ preventScroll: true });
  else if (document.activeElement === document.body && matchMedia('(pointer: fine)').matches) $('#libSearch').focus({ preventScroll: true });
  await refreshLibrary();
  if (paperId && libShown() && (document.activeElement === heading || document.activeElement === document.body))
    libraryUI.focusPaper(paperId) || $('#libSearch').focus({ preventScroll: true });
}
// The reader is taking over the window: the library stops its timers.
export function leaveLibrary() { libraryUI.stop(); }

// Menus in the library header close on Escape / outside click; a dialog opened from one returns focus to it.
const libraryMenus = [$('#libMenu'), $('#libImportOptions')];
for (const menu of libraryMenus) {
  menu.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !menu.open) return;
    event.preventDefault();
    event.stopPropagation();
    menu.open = false;
    menu.querySelector('summary').focus();
  });
}
document.addEventListener('click', event => {
  for (const menu of libraryMenus) {
    if (!menu.open) continue;
    if (!menu.contains(event.target)) menu.open = false;
    else if (event.target.closest('button')) {
      menu.open = false;
      menu.querySelector('summary').focus({ preventScroll: true });
    }
  }
}, true);

let reviewDialog;
async function openReview(trigger, opts) {
  const menu = trigger?.closest('details');
  if (menu) menu.open = false;
  try {
    const { createReviewUI } = await import('./review-ui.js');
    reviewDialog ??= createReviewUI({
      kit: uiKit, sendPdf, requireEngine, engineName, onImport: refreshLibrary,
      titleOf: id => libraryUI.titleOf(id), context: () => libraryUI.reviewContext(),
    });
    await reviewDialog.open(libraryUI.reviewContext(), menu?.querySelector('summary') || trigger, opts);
  } catch (error) { uiKit.toast(`논문 비교표를 열지 못했습니다. ${uiKit.errorText(error)}`, { kind: 'error' }); }
}
document.addEventListener('click', e => {
  const trigger = e.target.closest?.('[data-open-review]');
  if (trigger) openReview(trigger);
});
onEngineChange(() => { reviewDialog?.providerChanged(); libraryUI.aiChanged(); });
window.sunlightLibraryChanged = () => { if (libShown()) void refreshLibrary(); };

bindPdfImport({
  kit: uiKit, requireEngine, inLibrary: libShown, onAdded: refreshLibrary,
  context: () => ({ scope: S.sess, ...libraryUI.uploadContext() }),
  onOpen: id => { location.hash = `#/paper/${encodeURIComponent(id)}`; },
});

// phone-control.js opens from #openMobile (home ⋯ menu); when opened from the reader ⋯ menu,
// focus goes back to that menu's button after phone-control has moved it to the home menu.
let mobileOpener = null;
$('#phoneControl').addEventListener('close', () => {
  const back = mobileOpener; mobileOpener = null;
  if (back?.isConnected && back.getClientRects().length) back.focus({ preventScroll: true });
  else if ($('#library').classList.contains('hidden')) $('#moreBtn').focus({ preventScroll: true });
});
bindAppCommands({
  kit: uiKit,
  openSettings: () => openSettings(),
  openMobile: () => { mobileOpener = document.activeElement; $('#openMobile').click(); },
  exitApp: async () => { libraryUI.stop(); await exitApp(); },
});
