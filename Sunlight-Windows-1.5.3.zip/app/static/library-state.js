// Pure library helpers (no DOM globals) so they can be checked with plain Node.
export const UNFILED = '__unfiled';

export function visiblePapers(papers, assignments, folder, query = '', sort = 'newest') {
  const term = query.trim().toLocaleLowerCase();
  return papers.filter(p => (!folder || (folder === UNFILED ? !assignments[p.id] : assignments[p.id] === folder))
    && (!term || `${p.title || ''} ${p.filename || ''}`.toLocaleLowerCase().includes(term)))
    .sort((a, b) => sort === 'title' ? (a.title || '').localeCompare(b.title || '', 'ko') : (b.created || 0) - (a.created || 0));
}

export function folderCounts(papers, assignments) {
  const counts = { '': papers.length, [UNFILED]: 0 };
  for (const p of papers) { const key = assignments[p.id] || UNFILED; counts[key] = (counts[key] || 0) + 1; }
  return counts;
}

export const paperName = p => p?.title || p?.filename || '';
const titleKey = p => paperName(p).replace(/\.pdf$/i, '').trim().toLocaleLowerCase();
// Titles shared by more than one paper: those rows also show the file name so they can be told apart.
export function duplicateTitles(papers) {
  const seen = new Set(), dup = new Set();
  for (const p of papers) { const k = titleKey(p); if (seen.has(k)) dup.add(k); else seen.add(k); }
  return { has: p => dup.has(titleKey(p)) };
}

// Job words follow the shared contract: 분석 중, 대기, 번역 중 n/m, 요약 중, 완료, 일부 실패, 오류, 중지됨, 중단됨.
// `tone` drives colour, `action` an inline button (resume / stop), `detail` the tooltip and accessible description.
export function statusInfo(p) {
  if (p.storage_issue) return { label: '복구 필요', tone: 'err', detail: p.storage_error || '' };
  const tr = p.status, sm = p.summary_status;
  if (tr === 'analyzing') return { label: '분석 중', tone: 'run', active: true };
  if (tr === 'translating') {
    const total = Number(p.progress?.total) || 0;
    const done = Math.min(Number(p.progress?.done) || 0, total);
    return { label: total ? `번역 중 ${done}/${total}` : '번역 중', tone: 'run', active: true, action: 'stop' };
  }
  if (sm === 'running') return { label: '요약 중', tone: 'run', active: true, action: 'stop' };
  if (tr === 'queued' || sm === 'queued') return { label: '대기', tone: 'run', waiting: true, action: 'stop' };
  if (tr === 'interrupted' || sm === 'interrupted') {
    return { label: '중단됨', tone: 'stop', action: 'resume', detail: '앱이 닫히면서 멈춘 작업입니다. 끝난 쪽은 보관했습니다.' };
  }
  if (tr === 'stopped' || sm === 'stopped') return { label: '중지됨', tone: 'stop', action: 'resume', detail: '끝난 쪽은 보관했습니다.' };
  if (tr === 'error') return { label: '오류', tone: 'err', action: 'detail', detail: p.error || (p.pages ? '번역하지 못했습니다. 논문을 열어 다시 시도하세요.' : 'PDF를 읽지 못했습니다.') };
  if (tr === 'partial') return { label: '일부 실패', tone: 'err', action: 'detail', detail: p.error || '일부 쪽을 번역하지 못했습니다. 논문을 열어 다시 시도하세요.' };
  if (sm === 'error') return { label: '오류', tone: 'err', action: 'detail', detail: p.summary_error || '요약을 만들지 못했습니다. 논문을 열어 다시 시도하세요.' };
  if (tr === 'done') return { label: '완료', tone: 'ok' };
  if (tr === 'original') return { label: '번역 전', tone: '' };
  return { label: '대기', tone: '' };
}

// Home only shows states that ask for attention; 완료 and 번역 전 are the quiet defaults.
export const statusWorthShowing = info => info.tone !== 'ok' && info.label !== '번역 전';

export const ACTION_LABEL = { resume: '이어서 하기', stop: '중지', detail: '자세히' };

// Changes arrive over the server event stream. A timer runs only to retry a failed load, or as
// the slow fallback while the stream is down and some paper is still working.
export const FALLBACK_POLL = 15000;
export function pollDelay(papers, { retry = false, streaming = false, hidden = false } = {}) {
  let delay = null;
  if (retry) delay = 5000;
  else if (!streaming && papers.some(p => { const i = statusInfo(p); return i.active || i.waiting; })) delay = FALLBACK_POLL;
  return delay && hidden ? delay * 4 : delay;
}

// Apply one `paper` push event to the list; returns the new array, or null when nothing changed.
const PUSHED = ['status', 'summary_status', 'summary_stage', 'progress', 'translated_version', 'notice', 'error',
  'summary_error', 'failed_pages', 'storage_write_error', 'title'];
export function applyPaperEvent(papers, event) {
  const i = papers.findIndex(p => p.id === event?.id);
  if (i < 0) return null;
  const next = { ...papers[i] };
  let changed = false;
  for (const key of PUSHED) {
    if (!(key in event)) continue;
    if (JSON.stringify(next[key]) !== JSON.stringify(event[key])) { next[key] = event[key]; changed = true; }
  }
  if (!changed) return null;
  const copy = papers.slice(); copy[i] = next;
  return copy;
}

export function recentReads(papers, limit = 5) {
  return papers.filter(p => Number(p.last_read?.page) > 0 && Number(p.last_read?.at) > 0)
    .sort((a, b) => b.last_read.at - a.last_read.at).slice(0, limit);
}

const DAY = 86400;
export function relativeDay(at, now = Date.now() / 1000) {
  const start = new Date(now * 1000); start.setHours(0, 0, 0, 0);
  const today = start.valueOf() / 1000;
  if (at >= today) return '오늘';
  if (at >= today - DAY) return '어제';
  const days = Math.ceil((today - at) / DAY);
  if (days < 7) return `${days}일 전`;
  return new Intl.DateTimeFormat('ko-KR', { month: 'numeric', day: 'numeric' }).format(new Date(at * 1000));
}

export function readLabel(p, now) {
  const page = Number(p.last_read?.page);
  if (!(page > 0)) return '';
  return `${page}쪽 읽는 중` + (p.last_read.at ? ` · ${relativeDay(p.last_read.at, now)}` : '');
}

// Keyed list update: rows keep their element (and focus, drag state, open menus) across refreshes.
// `update` should return quickly when its row's data did not change.
export function reconcile(container, items, keyOf, create, update) {
  const wanted = new Set(items.map(keyOf));
  const existing = new Map();
  for (const el of [...container.children]) {
    const key = el.dataset?.id;
    if (key != null && wanted.has(key) && !existing.has(key)) existing.set(key, el);
    else el.remove();
  }
  let cursor = container.firstElementChild;
  for (const item of items) {
    const key = keyOf(item);
    let el = existing.get(key);
    if (!el) { el = create(item); el.dataset.id = key; }
    update(el, item);
    if (el === cursor) cursor = cursor.nextElementSibling;
    else container.insertBefore(el, cursor);
  }
}
