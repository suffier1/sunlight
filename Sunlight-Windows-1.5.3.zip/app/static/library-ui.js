import {
  UNFILED, visiblePapers, folderCounts, paperName, statusInfo, statusWorthShowing, ACTION_LABEL,
  pollDelay, applyPaperEvent, recentReads, readLabel, reconcile, duplicateTitles,
} from './library-state.js';

export { visiblePapers, folderCounts } from './library-state.js';

const DRAG_TYPE = 'application/x-sunlight-papers';
const HOME_PAPERS = 5;
const NOTE_HITS = 8;
const HIT_KIND = { highlight: '하이라이트', note: '메모' };
const FOLDER_KEY = 'sunlight.library.folder';
const paperDate = new Intl.DateTimeFormat('ko-KR', { year: 'numeric', month: 'numeric', day: 'numeric' });
const DELETE_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M10 7V5h4v2M7 7l1 13h8l1-13"/></svg>';
const remember = (key, value) => { try { localStorage.setItem(key, value); } catch { /* preference only */ } };

// kit: the shared ui-kit module ({api, toast, confirmDialog, errorText, onServerEvent, serverEventsLive, onServerEventsState}).
// isShown(): the library view is on screen. aiStatus(): {pending, ready, name}. openSettings(): opens 설정.
// openPaperAt(pid, {page, hid}): opens a paper at a page / note (E1); defaults to the plain paper link.
export function createLibraryUI({ kit, isShown, aiStatus = () => ({}), openSettings = () => {},
  openPaperAt = pid => { location.hash = `#/paper/${encodeURIComponent(pid)}`; } }) {
  const { api, toast, confirmDialog, errorText } = kit;
  const $ = s => document.querySelector(s);
  const library = $('#library');
  const search = $('#libSearch');
  const list = $('#paperList');
  const continueList = $('#libContinueList');
  const dialog = $('#libraryDialog');
  const folderSelect = $('#libFolderSelect');
  let folder = '';
  try { folder = localStorage.getItem(FOLDER_KEY) || ''; } catch { /* private browsing */ }
  let papers = [], folders = [], assignments = {}, visible = [], request = 0, dialogAction = null, snapshot = '';
  let loaded = false, folderReady = false, folderSnapshot = false, paperIssue = false, managing = false, viewRevision = 0;
  let dragging = false, renderLater = false, dirty = false, timer = 0, refreshSoon = 0, libraryRevision = null;
  let inflight = null, inflightAt = 0, again = false, dupTitles = duplicateTitles([]);
  let hitSeq = 0, hitTimer = 0, hitQuery = '', hits = [], searchAvailable = true;
  const expanded = new Set();  // rows whose error detail is open
  let streaming = kit.serverEventsLive?.() ?? false;
  const queries = { home: '', collection: '' };
  const selected = new Set();
  const nameOf = id => folders.find(f => f.id === id)?.name || '미분류';
  const atHome = () => library.dataset.view === 'home';
  const currentFolder = () => !atHome() && folderSnapshot ? folder : '';
  const activeName = () => currentFolder() ? nameOf(currentFolder()) : '전체 논문';
  const currentTarget = () => folderReady && currentFolder() && folder !== UNFILED ? folder : null;
  const titleOf = id => paperName(papers.find(p => p.id === id));
  const write = (el, text) => { if (el && el.textContent !== text) el.textContent = text; };
  const notice = text => { const el = $('#libNotice'); write(el, text); el.classList.toggle('hidden', !text); };
  const fail = (prefix, err) => toast(`${prefix} · ${errorText(err)}`, { kind: 'error' });

  /* ------------------------------------------------------------ rows */
  function buildRow(el, manage) {
    el.replaceChildren();
    el._structure = manage;
    if (manage) {
      const box = document.createElement('input');
      box.type = 'checkbox'; box.className = 'paper-select';
      el.append(box);
    }
    const open = document.createElement('a');
    open.className = 'paper-open';
    for (const cls of ['t', 'm', 'paper-storage-warning']) {
      const div = document.createElement('div'); div.className = cls; open.append(div);
    }
    const status = document.createElement('span');
    status.className = 'paper-status';
    const pill = document.createElement('span'); pill.className = 'pill';
    const action = document.createElement('button'); action.type = 'button'; action.className = 'pill-action';
    status.append(pill, action);
    const detail = document.createElement('div');
    detail.className = 'paper-error'; detail.hidden = true;
    const detailText = document.createElement('p');
    const retry = document.createElement('button');
    retry.type = 'button'; retry.className = 'pill-action paper-retry'; retry.textContent = '열어서 다시 시도';
    detail.append(detailText, retry);
    el.append(open, status, detail);
    if (manage) {
      const actions = document.createElement('div');
      actions.className = 'paper-actions';
      actions.innerHTML = `<button type="button" class="paper-move">이동</button><button type="button" class="icon-btn sm del" title="삭제">${DELETE_ICON}</button>`;
      el.append(actions);
    }
  }

  function rowModel(p, kind) {
    const filename = p.filename || '';
    const title = paperName(p);
    const sameName = filename.replace(/\.pdf$/i, '').trim().toLocaleLowerCase() === title.replace(/\.pdf$/i, '').trim().toLocaleLowerCase();
    const meta = [];
    const showFile = !sameName && filename && (!atHome() || dupTitles.has(p));
    if (kind === 'continue') { meta.push(readLabel(p)); if (showFile) meta.push(filename); }
    else {
      if (showFile) meta.push(filename);
      if (folderSnapshot && !currentFolder() && assignments[p.id]) meta.push(nameOf(assignments[p.id]));
      if (p.pages) meta.push(`${p.pages}쪽`);
      const date = new Date(p.created * 1000);
      if (p.created && Number.isFinite(date.valueOf())) meta.push(paperDate.format(date));
    }
    const info = statusInfo(p);
    const manage = managing && kind === 'main';
    return {
      id: p.id, title, meta: meta.filter(Boolean).join(' · '), warn: p.storage_issue && p.storage_error || '',
      status: !atHome() || statusWorthShowing(info) ? info : null, manage, chosen: manage && selected.has(p.id),
      drag: !atHome() && folderReady, folderReady, open: expanded.has(p.id) && info.action === 'detail',
    };
  }

  // Patch one row in place; unchanged rows return at the signature check.
  function updateRow(el, p, kind) {
    const m = rowModel(p, kind);
    const sig = JSON.stringify(m);
    if (el._sig === sig) return;
    el._sig = sig;
    if (el._structure !== m.manage) buildRow(el, m.manage);
    el.className = 'paper' + (m.chosen ? ' selected' : '');
    el.draggable = m.drag;
    const open = el.querySelector('.paper-open');
    open.href = `#/paper/${encodeURIComponent(p.id)}`;
    write(open.querySelector('.t'), m.title);
    write(open.querySelector('.m'), m.meta);
    open.querySelector('.m').hidden = !m.meta;
    write(open.querySelector('.paper-storage-warning'), m.warn);
    open.querySelector('.paper-storage-warning').hidden = !m.warn;
    const status = el.querySelector('.paper-status'), pill = status.querySelector('.pill'), action = status.querySelector('.pill-action');
    status.hidden = !m.status;
    if (m.status) {
      write(pill, m.status.label);
      pill.className = 'pill' + (m.status.tone ? ' ' + m.status.tone : '');
      if (m.status.detail) pill.title = m.status.detail; else pill.removeAttribute('title');
      const verb = ACTION_LABEL[m.status.action] || '';
      action.hidden = !verb;
      action.dataset.action = m.status.action || '';
      write(action, verb);
      if (verb) action.setAttribute('aria-label', `${m.title} ${m.status.label} ${verb}`);
      if (m.status.action === 'detail') {
        action.setAttribute('aria-expanded', String(m.open));
        action.setAttribute('aria-controls', `paper-error-${p.id}`);
      } else { action.removeAttribute('aria-expanded'); action.removeAttribute('aria-controls'); }
    }
    const detail = el.querySelector('.paper-error');
    detail.id = `paper-error-${p.id}`;
    detail.hidden = !m.open;
    if (m.open) {
      write(detail.querySelector('p'), m.status.detail || '논문을 열어 원인을 확인하세요.');
      detail.querySelector('.paper-retry').setAttribute('aria-label', `${m.title} 열어서 다시 시도`);
    }
    if (m.manage) {
      const box = el.querySelector('.paper-select');
      box.checked = m.chosen;
      box.setAttribute('aria-label', `${m.title} 선택`);
      const moveButton = el.querySelector('.paper-move');
      moveButton.disabled = !m.folderReady;
      moveButton.setAttribute('aria-label', `${m.title} 폴더 이동`);
      el.querySelector('.del').setAttribute('aria-label', `${m.title} 삭제`);
    }
  }
  const createRow = () => { const li = document.createElement('li'); li.className = 'paper'; return li; };

  /* ------------------------------------------------------------ view */
  function selectionChanged() {
    const chosen = visible.filter(p => selected.has(p.id)).length;
    const all = $('#libSelectAll');
    all.checked = !!visible.length && chosen === visible.length;
    all.indeterminate = chosen > 0 && chosen < visible.length;
    all.disabled = !visible.length;
    write($('#libSelectedCount'), selected.size ? `${selected.size}편 선택됨` : '선택한 논문 없음');
    $('#libMoveSelected').disabled = !selected.size || !folderReady;
    $('#libDeleteSelected').disabled = !selected.size;
    write($('#libDeleteSelected'), selected.size ? `${selected.size}편 삭제` : '삭제');
    $('#libClearSelection').classList.toggle('hidden', !selected.size);
    if (!managing) return;
    for (const p of visible) {
      const row = list.querySelector(`[data-id="${CSS.escape(p.id)}"]`);
      if (row) updateRow(row, p, 'main');
    }
  }

  function renderFolders(shownFolder, counts) {
    const choices = [{ id: '', name: '전체 논문' }];
    if (folderSnapshot) choices.push({ id: UNFILED, name: '미분류' }, ...folders);
    const box = $('#libFolders');
    const sig = JSON.stringify([shownFolder, choices.map(c => [c.id, c.name, counts[c.id] || 0])]);
    if (box._sig !== sig) {
      box._sig = sig;
      const focused = document.activeElement?.closest?.('#libFolders [data-folder]')?.dataset.folder;
      box.replaceChildren(...choices.flatMap(({ id, name }) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'folder-item' + (shownFolder === id ? ' active' : '');
        b.dataset.folder = id;
        b.title = name;
        if (shownFolder === id) b.setAttribute('aria-current', 'page');
        const label = document.createElement('span'); label.className = 'folder-name'; label.textContent = name;
        // The hidden separator and unit make the accessible name "폴더, 3편" instead of "폴더3".
        const count = document.createElement('span'); count.className = 'folder-count';
        count.innerHTML = '<span class="sr-only">, </span><span></span><span class="sr-only">편</span>';
        count.children[1].textContent = String(counts[id] || 0);
        b.append(label, count);
        if (id !== UNFILED) return [b];
        const divider = document.createElement('div'); divider.className = 'folder-divider';
        return [b, divider];
      }));
      if (focused != null) box.querySelector(`[data-folder="${CSS.escape(focused)}"]`)?.focus({ preventScroll: true });
    }
    // Keep the native picker open during background refreshes when its choices have not changed.
    const optionsChanged = folderSelect.length !== choices.length || choices.some(({ id, name }, i) =>
      folderSelect.options[i].value !== id || folderSelect.options[i].text !== `${name} · ${counts[id] || 0}편`);
    if (optionsChanged) folderSelect.replaceChildren(...choices.map(({ id, name }) => new Option(`${name} · ${counts[id] || 0}편`, id)));
    if (folderSelect.value !== shownFolder) folderSelect.value = shownFolder;
    $('#libNewFolder').disabled = !folderReady;
  }

  function renderAi() {
    const el = $('#libAiState');
    if (!el) return;
    const ai = aiStatus() || {};
    write(el, ai.pending ? 'AI 연결을 확인하는 중입니다.' : ai.ready ? `AI: ${ai.name} 연결됨` : 'AI가 연결되어 있지 않습니다.');
    write($('#libAiSettings'), ai.ready || ai.pending ? '설정' : 'AI 연결하기');
  }

  function render() {
    if (dragging) { renderLater = true; return; }
    const home = atHome(), query = search.value.trim(), shownFolder = currentFolder();
    const counts = folderCounts(papers, assignments);
    if (!home) renderFolders(shownFolder, counts);
    const matches = visiblePapers(papers, assignments, shownFolder, query, home ? 'newest' : $('#libSort').value);
    dupTitles = duplicateTitles(papers);
    let reads = [], rest = matches;
    if (home && !query) {
      reads = recentReads(papers, HOME_PAPERS);
      const readIds = new Set(reads.map(p => p.id));
      rest = matches.filter(p => !readIds.has(p.id));
      visible = rest.slice(0, HOME_PAPERS);
    } else visible = matches;
    const firstRun = loaded && !papers.length && !paperIssue;
    library.classList.toggle('has-papers', !!papers.length);
    library.classList.toggle('has-results', !!visible.length);
    library.classList.toggle('has-query', !!query);
    library.classList.toggle('is-managing', managing);
    library.classList.toggle('is-first-run', firstRun);
    $('#libStart').classList.toggle('hidden', !firstRun);
    if (firstRun) renderAi();
    for (const b of document.querySelectorAll('#libNav [data-lib-view]')) {
      if (b.dataset.libView === library.dataset.view) b.setAttribute('aria-current', 'page');
      else b.removeAttribute('aria-current');
    }
    $('#libFolderTools').classList.toggle('hidden', !managing || !currentTarget());
    write($('#libManage'), managing ? '완료' : '정리');
    $('#libManage').setAttribute('aria-pressed', String(managing));
    $('#libSeeAll').classList.toggle('hidden', !home || !!query || rest.length <= HOME_PAPERS);
    write($('#libSeeAll'), `라이브러리에서 ${papers.length}편 모두 보기`);
    $('#libSearchClear').classList.toggle('hidden', !search.value);
    write($('#libFolderTitle'), home ? (query ? '검색 결과' : '최근 추가한 논문') : activeName());
    write($('#libUploadHint'), currentTarget() ? `PDF를 이 창에 끌어다 놓으면 ‘${activeName()}’에 추가됩니다.` : 'PDF를 이 창 어디에나 끌어다 놓아도 추가됩니다.');
    const visibleIds = new Set(visible.map(p => p.id));
    for (const id of selected) if (!visibleIds.has(id)) selected.delete(id);
    write($('#libCount'), home && !query ? '' : `${matches.length}편`);
    $('#libContinue').classList.toggle('hidden', !reads.length);
    reconcile(continueList, reads, p => p.id, createRow, (el, p) => updateRow(el, p, 'continue'));
    reconcile(list, visible, p => p.id, createRow, (el, p) => updateRow(el, p, 'main'));
    $('#libEmpty').classList.toggle('hidden', !!visible.length || paperIssue || !loaded || (home && !query));
    write($('#libEmpty'), query ? '검색 결과가 없습니다. 제목이나 파일명의 다른 단어로 찾아보세요.'
      : shownFolder ? '이 폴더에는 아직 논문이 없습니다. 정리에서 논문을 골라 이 폴더로 옮기세요.' : '아직 추가한 논문이 없습니다.');
    renderHits();
    selectionChanged();
  }

  /* ------------------------------------------------------------ 메모 일치 (GET /api/search) */
  // Highlights and notes that match the query, below the paper list. Title hits are already rows above.
  const hitBox = document.createElement('section');
  hitBox.className = 'lib-hits hidden';
  hitBox.setAttribute('aria-labelledby', 'libHitsTitle');
  hitBox.innerHTML = '<h2 id="libHitsTitle" class="lib-section-title">메모 일치</h2><ul class="hit-list"></ul>';
  list.after(hitBox);
  const hitList = hitBox.querySelector('ul');
  function renderHits() {
    const query = search.value.trim();
    const shown = query && query === hitQuery ? hits : [];
    hitBox.classList.toggle('hidden', !shown.length);
    // "검색 결과 0편" never stands alone: say why the list is empty and point to the note matches.
    if (query && !visible.length && loaded && !paperIssue) {
      const empty = $('#libEmpty');
      empty.classList.remove('hidden');
      write(empty, shown.length ? '제목이나 파일명이 맞는 논문은 없습니다. 메모 일치에서 찾은 곳을 확인하세요.'
        : '검색 결과가 없습니다. 제목이나 파일명의 다른 단어로 찾아보세요.');
    }
    reconcile(hitList, shown, h => `${h.paper}:${h.hid || h.page}`, () => {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.className = 'hit-open';
      a.innerHTML = '<span class="t"></span><span class="m"></span><span class="hit-snippet"></span>';
      li.append(a);
      return li;
    }, (li, h) => {
      const a = li.firstElementChild;
      a.href = `#/paper/${encodeURIComponent(h.paper)}`;
      a.dataset.paper = h.paper; a.dataset.page = h.page ?? ''; a.dataset.hid = h.hid ?? '';
      write(a.querySelector('.t'), h.title || titleOf(h.paper) || '이름 없는 논문');
      write(a.querySelector('.m'), [HIT_KIND[h.kind], h.page ? `${h.page}쪽` : ''].filter(Boolean).join(' · '));
      write(a.querySelector('.hit-snippet'), h.snippet || '');
    });
  }
  function searchNotes() {
    clearTimeout(hitTimer);
    const query = search.value.trim();
    if (!searchAvailable || query.length < 2) { hits = []; hitQuery = ''; renderHits(); return; }
    hitTimer = setTimeout(async () => {
      const seq = ++hitSeq;
      try {
        const result = await api(`/api/search?q=${encodeURIComponent(query)}&limit=${NOTE_HITS * 2}`, { timeout: 8000 });
        if (seq !== hitSeq) return;
        hits = (Array.isArray(result?.hits) ? result.hits : [])
          .filter(h => h && typeof h.paper === 'string' && h.kind !== 'title').slice(0, NOTE_HITS);
        hitQuery = query;
      } catch (err) {
        if (seq !== hitSeq) return;
        if (err.status === 404 || err.status === 405) searchAvailable = false;  // older server: no note search
        hits = []; hitQuery = '';
      }
      renderHits();
    }, 220);
  }
  hitList.addEventListener('click', e => {
    const a = e.target.closest('.hit-open');
    if (!a || e.ctrlKey || e.metaKey || e.shiftKey) return;
    e.preventDefault();
    openPaperAt(a.dataset.paper, { page: Number(a.dataset.page) || undefined, hid: a.dataset.hid || undefined });
  });

  /* ------------------------------------------------------------ data */
  function schedule() {
    clearTimeout(timer);
    if (!isShown()) return;
    const delay = pollDelay(papers, { retry: paperIssue || (loaded && !folderReady), streaming, hidden: document.hidden });
    if (delay) timer = setTimeout(refresh, delay);
  }

  // Calls made while a load is in flight join it (boot asks from several places); a later change asks once more.
  function refresh() {
    if (inflight) {
      if (Date.now() - inflightAt > 400) again = true;
      return inflight;
    }
    inflightAt = Date.now();
    inflight = load().finally(() => {
      inflight = null;
      if (again) { again = false; void refresh(); }
    });
    return inflight;
  }
  async function load() {
    clearTimeout(timer); clearTimeout(refreshSoon);
    const seq = ++request;
    const [paperList, folderList] = await Promise.allSettled([
      api('/api/papers', { timeout: 12000 }),
      api('/api/library', { timeout: 12000 }),
    ]);
    if (seq !== request) return null;
    const next = JSON.stringify([paperList.status === 'fulfilled' && paperList.value, folderList.status === 'fulfilled' && folderList.value]);
    const changed = next !== snapshot || !loaded;
    if (paperList.status === 'fulfilled' && Array.isArray(paperList.value)) papers = paperList.value;
    folderReady = folderList.status === 'fulfilled';
    if (folderReady) {
      folderSnapshot = true;
      ({ folders, assignments } = folderList.value);
      if (folder && folder !== UNFILED && !folders.some(f => f.id === folder)) folder = UNFILED;
    }
    const existing = new Set(papers.map(p => p.id));
    for (const id of selected) if (!existing.has(id)) selected.delete(id);
    paperIssue = paperList.status === 'rejected';
    loaded = loaded || !paperIssue;
    notice(paperIssue ? `논문 목록을 불러오지 못했습니다. ${errorText(paperList.reason)} 잠시 후 다시 시도합니다.`
      : !folderReady ? '폴더 정보를 불러오지 못했습니다. 논문은 열 수 있습니다. 폴더 연결을 다시 시도합니다.' : '');
    if (changed || dirty) { snapshot = next; dirty = false; render(); }
    schedule();
    return { papers, retry: paperIssue || !folderReady };
  }
  const refreshLater = (ms = 250) => { clearTimeout(refreshSoon); if (isShown()) refreshSoon = setTimeout(refresh, ms); };

  // Push updates (contract §9): `paper` patches one row in place; `library` refetches only on a new revision.
  kit.onServerEvent?.('paper', event => {
    const next = applyPaperEvent(papers, event);
    if (next) { papers = next; if (isShown()) render(); else dirty = true; }
    else if (event?.id && !papers.some(p => p.id === event.id)) refreshLater();
  });
  kit.onServerEvent?.('library', event => {
    if (event?.revision != null && event.revision === libraryRevision) return;
    libraryRevision = event?.revision ?? null;
    refreshLater();
  });
  // The stream's first message carries the current revision: remember it instead of reloading what boot just loaded.
  kit.onServerEvent?.('hello', event => {
    const revision = event?.revision ?? null;
    if (libraryRevision !== null && revision !== libraryRevision) refreshLater();
    libraryRevision = revision;
  });
  kit.onServerEvent?.('resync', () => refreshLater(0));
  kit.onServerEventsState?.(live => { streaming = live; schedule(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && !streaming && isShown()) refreshLater(0); else schedule(); });

  /* ------------------------------------------------------------ actions */
  function chooseFolder(id) {
    if (id !== folder) viewRevision++;
    folder = id; selected.clear(); search.value = '';
    remember(FOLDER_KEY, folder);
    render();
    searchNotes();
  }
  function switchView(view) {
    if (view === library.dataset.view) return;
    queries[library.dataset.view] = search.value;
    library.dataset.view = view;
    search.value = queries[view];
    viewRevision++;
    selected.clear();
    managing = false;
    render();
    searchNotes();
    (atHome() ? search : $('#libFolderTitle')).focus({ preventScroll: true });
  }
  async function move(ids, target) {
    if (!folderReady) throw new Error('폴더 정보를 불러온 뒤 다시 시도하세요.');
    await api('/api/library/move', { method: 'POST', body: { paper_ids: ids, folder_id: target || null } });
    selected.clear(); await refresh(); toast(`${ids.length}편을 ‘${nameOf(target)}’로 옮겼습니다.`, { kind: 'success' });
  }
  const consequence = '저장한 PDF, 번역, 메모, 대화가 함께 삭제되며 되돌릴 수 없습니다.';
  async function removePapers(ids) {
    const names = ids.map(id => titleOf(id) || '이름 없는 논문');
    const shown = names.slice(0, 5).map(n => `· ${n}`);
    if (names.length > 5) shown.push(`외 ${names.length - 5}편`);
    const ok = await confirmDialog({
      title: ids.length === 1 ? '이 논문을 삭제할까요?' : `논문 ${ids.length}편을 삭제할까요?`,
      body: [...shown, consequence].join('\n'), confirm: ids.length === 1 ? '삭제' : `${ids.length}편 삭제`, danger: true,
    });
    if (!ok) return;
    let removed = 0, lastError = null;
    for (const id of ids) {
      try { await api(`/api/papers/${encodeURIComponent(id)}`, { method: 'DELETE' }); removed++; selected.delete(id); }
      catch (err) { lastError = err; }
    }
    await refresh();
    if (lastError) toast(`${ids.length - removed}편을 삭제하지 못했습니다 · ${errorText(lastError)}`, { kind: 'error' });
    else toast(ids.length === 1 ? '논문을 삭제했습니다.' : `${removed}편을 삭제했습니다.`, { kind: 'success' });
  }
  async function runJobAction(id, action, button) {
    button.disabled = true;
    try {
      if (action === 'resume') await api(`/api/papers/${encodeURIComponent(id)}/resume`, { method: 'POST', body: {} });
      else await api(`/api/papers/${encodeURIComponent(id)}/cancel`, { method: 'POST', body: { what: 'all' } });
      toast(action === 'resume' ? '이어서 진행합니다.' : '중지했습니다. 끝난 쪽은 보관했습니다.');
      await refresh();
    } catch (err) { fail(action === 'resume' ? '이어서 하지 못했습니다' : '중지하지 못했습니다', err); }
    finally { if (button.isConnected) button.disabled = false; }
  }
  function openDialog(kind, ids = []) {
    if (!folderReady) return;
    dialogAction = { kind, ids, folder: currentTarget() };
    const moving = kind === 'move';
    write($('#libraryDialogTitle'), moving ? '폴더로 이동' : kind === 'rename' ? '폴더 이름 변경' : '새 폴더');
    write($('#libraryDialogHint'), moving ? (ids.length > 1 ? `선택한 논문 ${ids.length}편` : titleOf(ids[0])) : '');
    $('#libraryDialogHint').classList.toggle('hidden', !$('#libraryDialogHint').textContent);
    $('#libraryNameField').classList.toggle('hidden', moving); $('#libraryMoveField').classList.toggle('hidden', !moving);
    $('#libraryFolderName').value = kind === 'rename' ? activeName() : '';
    $('#libraryFolderName').required = !moving;
    $('#libraryFolderTarget').replaceChildren(new Option('미분류', ''), ...folders.map(f => new Option(f.name, f.id)));
    $('#libraryFolderTarget').value = ids.length === 1 ? (assignments[ids[0]] || '') : (currentTarget() || '');
    write($('#libraryDialogError'), ''); write($('#libraryDialogSave'), moving ? '이동' : '저장');
    $('#libraryDialogSave').disabled = false;
    dialog.showModal(); (moving ? $('#libraryFolderTarget') : $('#libraryFolderName')).focus();
  }

  for (const b of document.querySelectorAll('#libNav [data-lib-view]')) b.onclick = () => switchView(b.dataset.libView);
  $('#libSeeAll').onclick = () => {
    queries.collection = '';
    folder = ''; $('#libSort').value = 'newest';
    remember(FOLDER_KEY, folder);
    switchView('collection');
  };
  $('#libManage').onclick = () => { managing = !managing; selected.clear(); render(); };
  $('#libSearchClear').onclick = () => { search.value = ''; search.dispatchEvent(new Event('input')); search.focus(); };
  $('#libAiSettings')?.addEventListener('click', () => openSettings());
  $('#libRevealFolder')?.addEventListener('click', async event => {
    const button = event.currentTarget;
    try { await api('/api/library/reveal', { method: 'POST', body: {} }); }
    catch (err) {
      // 404/405: this server or window cannot open Explorer (not the desktop app, or an older server).
      if (err.status === 404 || err.status === 405) { button.hidden = true; toast('이 창에서는 보관 폴더를 열 수 없습니다. Sunlight 앱에서 다시 시도하세요.'); }
      else fail('폴더를 열지 못했습니다', err);
    }
  });
  $('#libFolders').addEventListener('click', e => { const b = e.target.closest('[data-folder]'); if (b) chooseFolder(b.dataset.folder); });
  folderSelect.addEventListener('change', () => chooseFolder(folderSelect.value));
  $('#libFolders').addEventListener('dragover', e => {
    const b = e.target.closest('[data-folder]');
    if (folderReady && b && b.dataset.folder && e.dataTransfer.types.includes(DRAG_TYPE)) { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; b.classList.add('drop-target'); }
  });
  $('#libFolders').addEventListener('dragleave', e => e.target.closest('[data-folder]')?.classList.remove('drop-target'));
  $('#libFolders').addEventListener('drop', e => {
    const b = e.target.closest('[data-folder]');
    if (!folderReady || !b || !b.dataset.folder || !e.dataTransfer.types.includes(DRAG_TYPE)) return;
    e.preventDefault(); e.stopPropagation(); b.classList.remove('drop-target');
    try {
      const ids = JSON.parse(e.dataTransfer.getData(DRAG_TYPE));
      if (!Array.isArray(ids) || !ids.length || ids.some(id => !papers.some(p => p.id === id))) return;
      move(ids, b.dataset.folder === UNFILED ? null : b.dataset.folder).catch(err => fail('이동하지 못했습니다', err));
    } catch { /* ignore other applications' drag payloads */ }
  });
  list.addEventListener('dragstart', e => {
    if (atHome() || !folderReady) return;
    const row = e.target.closest('[data-id]'); if (!row) return;
    const ids = selected.has(row.dataset.id) ? [...selected] : [row.dataset.id];
    e.dataTransfer.setData(DRAG_TYPE, JSON.stringify(ids)); e.dataTransfer.effectAllowed = 'move';
    dragging = true;
  });
  list.addEventListener('dragend', () => {
    dragging = false;
    if (renderLater) { renderLater = false; render(); }
  });
  list.addEventListener('change', e => {
    if (!e.target.matches('.paper-select')) return;
    const id = e.target.closest('[data-id]').dataset.id;
    if (e.target.checked) selected.add(id); else selected.delete(id);
    selectionChanged();
  });
  // In 정리 mode Space on a title toggles its checkbox; Enter still opens the paper.
  list.addEventListener('keydown', e => {
    if (!managing || e.key !== ' ' || !e.target.matches('.paper-open')) return;
    e.preventDefault();
    const box = e.target.closest('[data-id]').querySelector('.paper-select');
    box.checked = !box.checked;
    box.dispatchEvent(new Event('change', { bubbles: true }));
  });
  for (const container of [list, continueList]) container.addEventListener('click', e => {
    const row = e.target.closest('[data-id]'); if (!row) return;
    const action = e.target.closest('.pill-action');
    if (e.target.closest('.paper-retry')) { location.hash = `#/paper/${encodeURIComponent(row.dataset.id)}`; return; }
    if (action?.dataset.action === 'detail') {
      if (expanded.has(row.dataset.id)) expanded.delete(row.dataset.id); else expanded.add(row.dataset.id);
      const paper = papers.find(p => p.id === row.dataset.id);
      if (paper) updateRow(row, paper, container === list ? 'main' : 'continue');
      return;
    }
    if (action) { if (action.dataset.action) void runJobAction(row.dataset.id, action.dataset.action, action); return; }
    if (e.target.closest('.paper-move')) { openDialog('move', [row.dataset.id]); return; }
    if (e.target.closest('.del')) void removePapers([row.dataset.id]);
  });
  search.addEventListener('input', () => { viewRevision++; selected.clear(); render(); searchNotes(); });
  search.addEventListener('keydown', e => {
    if (e.key !== 'ArrowDown' || e.isComposing || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
    const first = [...library.querySelectorAll('.paper-list .paper-open')].find(a => a.getClientRects().length);
    if (first) { e.preventDefault(); first.focus(); }
  });
  $('#libSort').addEventListener('change', render);
  $('#libSelectAll').addEventListener('change', e => { selected.clear(); if (e.target.checked) visible.forEach(p => selected.add(p.id)); selectionChanged(); });
  $('#libClearSelection').onclick = () => { selected.clear(); selectionChanged(); };
  $('#libMoveSelected').onclick = () => openDialog('move', [...selected]);
  $('#libDeleteSelected').onclick = () => { if (selected.size) void removePapers([...selected]); };
  $('#libNewFolder').onclick = () => openDialog('create');
  $('#libRenameFolder').onclick = () => { if (currentTarget()) openDialog('rename'); };
  $('#libDeleteFolder').onclick = async () => {
    const id = currentTarget(); if (!id) return;
    const name = activeName(), count = folderCounts(papers, assignments)[id] || 0;
    const ok = await confirmDialog({
      title: `‘${name}’ 폴더를 삭제할까요?`,
      body: count ? `담긴 논문 ${count}편은 미분류로 옮겨집니다. 논문은 삭제되지 않습니다.` : '빈 폴더입니다.',
      confirm: '폴더 삭제', danger: true,
    });
    if (!ok) return;
    try { await api(`/api/library/folders/${encodeURIComponent(id)}`, { method: 'DELETE' }); chooseFolder(UNFILED); await refresh(); toast('폴더를 삭제했습니다.', { kind: 'success' }); }
    catch (err) { fail('폴더를 삭제하지 못했습니다', err); }
  };
  $('#libraryDialogClose').onclick = $('#libraryDialogCancel').onclick = () => dialog.close();
  dialog.addEventListener('close', () => { if (!dialog.open) dialogAction = null; });
  $('#libraryForm').addEventListener('submit', async e => {
    e.preventDefault(); if ($('#libraryDialogSave').disabled || !dialogAction) return;
    const action = dialogAction; $('#libraryDialogSave').disabled = true; write($('#libraryDialogError'), '');
    const ownsDialog = () => dialog.open && dialogAction === action;
    try {
      if (!folderReady) throw new Error('폴더 정보를 불러온 뒤 다시 시도하세요.');
      if (action.kind === 'move') await move(action.ids, $('#libraryFolderTarget').value);
      else {
        const name = $('#libraryFolderName').value.trim(); if (!name) throw new Error('폴더 이름을 입력하세요.');
        const result = await api(action.kind === 'rename' ? `/api/library/folders/${encodeURIComponent(action.folder)}` : '/api/library/folders',
          { method: action.kind === 'rename' ? 'PATCH' : 'POST', body: { name } });
        if (ownsDialog()) {
          if (folder !== result.id) viewRevision++;
          folder = result.id; selected.clear(); search.value = '';
          remember(FOLDER_KEY, folder);
        }
        await refresh();
        toast(action.kind === 'rename' ? '폴더 이름을 바꿨습니다.' : '새 폴더를 만들었습니다.', { kind: 'success' });
      }
      if (ownsDialog()) dialog.close();
    } catch (err) { if (ownsDialog()) write($('#libraryDialogError'), errorText(err)); else fail('폴더를 바꾸지 못했습니다', err); }
    finally { if (ownsDialog()) $('#libraryDialogSave').disabled = false; }
  });

  function reviewContext() {
    const matches = visiblePapers(papers, assignments, currentFolder(), search.value, atHome() ? 'newest' : $('#libSort').value);
    return { papers: matches, selected: [...selected], name: search.value.trim() ? '검색 결과' : activeName() };
  }
  // After returning from the reader, put the keyboard back on that paper (either home list).
  function focusPaper(id) {
    const link = library.querySelector(`.paper-list [data-id="${CSS.escape(id)}"] .paper-open`);
    link?.focus({ preventScroll: false });
    return !!link;
  }
  return {
    refresh, reviewContext, titleOf, focusPaper, aiChanged: renderAi,
    stop: () => { clearTimeout(timer); clearTimeout(refreshSoon); },
    uploadContext: () => ({ folder: currentTarget(), targetName: activeName(), viewFolder: currentFolder(), viewRevision }),
  };
}
