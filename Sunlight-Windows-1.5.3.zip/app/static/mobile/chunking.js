// Upload chunk sizing. Chunks grow while each finishes quickly and shrink when one is slow or fails.
// A chunk never crosses a stored 4 MiB part, so after a reload it can be read from IndexedDB in one piece.
export const MIN_CHUNK = 256 * 1024;
export const START_CHUNK = 512 * 1024;
export const MAX_CHUNK = 4 * 1024 * 1024; // the PC's per-request limit
export const PART_BYTES = 4 * 1024 * 1024;
export const MIN_RATE = 46250; // bytes per second, about 370 kbps; slower links pause instead of retrying forever
const FAST_MS = 3000, SLOW_MS = 12000, JUDGE_MS = 20000;

export function createChunkPlanner(start = START_CHUNK) {
  let size = start, windowBytes = 0, windowMs = 0;
  return {
    get size() { return size; },
    end(offset, total) {
      const boundary = (Math.floor(offset / PART_BYTES) + 1) * PART_BYTES;
      return Math.min(total, offset + size, boundary);
    },
    // A chunk that cannot finish at the minimum rate counts as a too-slow link.
    timeout(bytes) { return 15000 + Math.ceil(bytes / MIN_RATE * 1000); },
    record(bytes, ms) {
      ms = Math.max(1, ms);
      if (ms < FAST_MS) size = Math.min(MAX_CHUNK, size * 2);
      else if (ms > SLOW_MS) size = Math.max(MIN_CHUNK, size / 2);
      windowBytes += bytes; windowMs += ms;
      const rate = windowBytes / windowMs * 1000;
      const slow = windowMs >= JUDGE_MS && rate < MIN_RATE;
      if (windowMs >= 2 * JUDGE_MS) { windowBytes = bytes; windowMs = ms; } // judge recent speed only
      return { rate, slow };
    },
    failed() { size = Math.max(MIN_CHUNK, size / 2); },
  };
}

export const kbps = rate => Math.max(1, Math.round(rate * 8 / 1000));
