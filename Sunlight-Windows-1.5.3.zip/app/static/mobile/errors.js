// Maps a failed request to one short Korean message. Pure so it can be checked without a browser.
export const MESSAGES = {
  offline: 'PC에 연결할 수 없습니다. 네트워크를 확인해 주세요.',
  pc_off: 'PC가 꺼져 있거나 절전 중입니다. PC에서 Sunlight가 켜져 있는지 확인해 주세요.',
  auth_expired: '팀 로그인 시간이 지났습니다. 화면을 새로 고쳐 다시 로그인해 주세요.',
  timeout: '응답이 늦어지고 있습니다. 다시 시도해 주세요.',
  failed: '요청을 마치지 못했습니다. 다시 시도해 주세요.',
};

// Gateway errors come from the tunnel (Cloudflare 52x/530, a proxy's 502-504) when the PC does not answer.
export function pcUnreachable(status) {
  return status === 502 || status === 503 || status === 504 || (status >= 520 && status <= 527) || status === 530;
}

// `type` is the fetch Response type: 'opaqueredirect' means a login page (e.g. Cloudflare Access) intercepted the call.
// `foreign` marks an XHR that ended on another origin for the same reason.
export function describeFailure({ status = 0, type = '', timedOut = false, foreign = false, data = null } = {}) {
  if (type === 'opaqueredirect' || foreign) return { code: 'auth_expired', status, message: MESSAGES.auth_expired, reload: true };
  if (timedOut) return { code: 'timeout', status, message: MESSAGES.timeout };
  if (!status) return { code: 'offline', status, message: MESSAGES.offline };
  if (pcUnreachable(status)) return { code: 'pc_off', status, message: MESSAGES.pc_off };
  const detail = data && (typeof data.detail === 'string' ? data.detail : typeof data.error === 'string' ? data.error : null);
  return { code: data && typeof data.code === 'string' ? data.code : 'failed', status, message: detail || MESSAGES.failed };
}

export function failure(details) {
  const info = describeFailure(details);
  return Object.assign(new Error(info.message), info);
}
