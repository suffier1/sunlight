// A Home Screen app keeps its own cookies. A target=_blank link would open Safari without this
// device's session, so inside the app the PDF is fetched here and handed to the system viewer.
const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;

export function pdfLink(href, label) {
  const link = document.createElement('a');
  link.href = href;
  link.textContent = label;
  if (!standalone()) { link.target = '_blank'; link.rel = 'noopener noreferrer'; return link; }
  link.onclick = async event => {
    event.preventDefault();
    if (link.dataset.busy) return;
    link.dataset.busy = '1';
    link.textContent = 'PDF 받는 중';
    try {
      const response = await fetch(href, { credentials: 'same-origin', redirect: 'manual' });
      if (!response.ok) throw new Error('download');
      const url = URL.createObjectURL(await response.blob());
      const save = document.createElement('a');
      save.href = url;
      save.download = (document.title.split(' · ')[0] || 'paper').replace(/[\\/:*?"<>|]/g, ' ').slice(0, 80) + '.pdf';
      document.body.append(save); save.click(); save.remove();
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      link.textContent = label;
    } catch { link.textContent = 'PDF를 받지 못했습니다. 다시 누르세요'; }
    finally { delete link.dataset.busy; }
  };
  return link;
}
