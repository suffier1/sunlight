import * as pdfjs from '/vendor/pdfjs/pdf.min.mjs';
import { pdfLink } from './links.js';

pdfjs.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.min.mjs';
const $ = id => document.getElementById(id);
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const MAX_ZOOM = 3;
const FLOW_KEY = 'sunlight.mobile.flow';
const KEEP_RENDERED = 8; // continuous scroll keeps this many page bitmaps

function button(label, action) {
  const element = document.createElement('button');
  element.type = 'button';
  element.className = 'action-link';
  element.textContent = label;
  element.onclick = action;
  return element;
}
function readFlow() { try { return localStorage.getItem(FLOW_KEY) === 'scroll' ? 'scroll' : 'page'; } catch { return 'page'; } }
function storeFlow(value) { try { localStorage.setItem(FLOW_KEY, value); } catch { /* the choice lasts for this page */ } }
const who = remote => remote.device === 'PC' ? 'PC' : remote.device || '다른 기기';

// Draw one PDF page at a CSS width, capping the bitmap so phones keep enough memory.
function draw(item, canvas, cssWidth, budget) {
  const base = item.getViewport({ scale: 1 });
  const cssHeight = cssWidth * base.height / base.width;
  const ratio = Math.min(devicePixelRatio || 1, 2, Math.sqrt(budget / Math.max(1, cssWidth * cssHeight)));
  const view = item.getViewport({ scale: Math.max(.05, cssWidth * ratio / base.width) });
  canvas.width = Math.max(1, Math.floor(view.width));
  canvas.height = Math.max(1, Math.floor(view.height));
  return item.render({ canvasContext: canvas.getContext('2d', { alpha: false }), viewport: view });
}

export function openReader({ paper, api, saveLocal, onBack }) {
  const base = '/m/api/papers/' + encodeURIComponent(paper.id);
  const lifetime = new AbortController();
  const events = { signal: lifetime.signal };
  const viewport = $('viewport'), reader = $('reader');
  let docTask, pdf, renderTask, currentPage, renderGeneration = 0, fileGeneration = 0;
  let page = Math.max(1, paper.position?.page || 1);
  let fraction = clamp(paper.position?.fraction || 0, 0, 1);
  let revision = paper.position?.revision || 0;
  let mode = bestMode(), isReady = false, alive = true, dirty = false, saving = false, conflict = false;
  let saveTimer, summaryTimer, renderWidth = -1, scrollFrame;
  let userInteracted = false, zoom = 1, flow = readFlow();
  let slots = [], slotObserver = null, layoutGeneration = 0, pageAspect = 1.3;
  const slotTasks = new Map();

  function bestMode() {
    if (paper.original !== false) return 'original';
    return paper.translated ? 'translated' : 'summary';
  }
  function updateModes() {
    const original = $('mode').querySelector('[value="original"]');
    const translated = $('mode').querySelector('[value="translated"]');
    original.hidden = original.disabled = paper.original === false;
    translated.hidden = translated.disabled = !paper.translated;
    $('source-note').hidden = paper.original !== false;
    $('mode').value = mode;
  }
  updateModes();
  $('paper-title').textContent = paper.title;
  $('summary').replaceChildren();
  $('position-note').hidden = true;
  $('text-details').open = false;
  $('view-panel').hidden = true;
  $('view-toggle').setAttribute('aria-expanded', 'false');
  $('sheet').hidden = $('pages').hidden = $('summary').hidden = $('text-details').hidden = true;
  document.title = paper.title + ' · Sunlight';

  function message(text, retry, nativeLink = false) {
    const notice = $('read-notice');
    notice.replaceChildren(text);
    if (retry) notice.append(button('다시 열기', retry));
    if (nativeLink) notice.append(pdfLink(base + '/file/' + mode, 'PDF 직접 열기'));
    notice.hidden = !text;
  }

  // ----- reading position: only real movement is written; newer positions from elsewhere are offered.
  async function writePosition() {
    clearTimeout(saveTimer);
    if (!dirty || saving || conflict) return;
    dirty = false;
    saving = true;
    const snapshot = { page, fraction, revision };
    try {
      // A small keepalive request can outlive pagehide or navigation back to the library.
      const stored = await api(base + '/position', { method: 'PUT', json: snapshot, keepalive: true });
      revision = stored.revision;
      saveLocal(paper.id, stored);
      if (alive && !conflict) $('position-note').hidden = true;
    } catch (error) {
      if (!alive) return;
      dirty = true;
      if (error.status === 409) { await reconcile(); return; }
      const note = $('position-note');
      note.replaceChildren('읽은 위치를 저장하지 못했습니다.', button('재시도', writePosition));
      note.hidden = false;
      return;
    } finally { saving = false; }
    if (dirty) void writePosition();
  }
  async function reconcile() {
    try {
      const remote = await api(base + '/position', { signal: lifetime.signal });
      if (!alive) return;
      if (remote.page === page) { revision = remote.revision; void writePosition(); return; }
      conflict = true;
      offer(remote);
    } catch { if (alive) { conflict = false; $('position-note').hidden = true; } }
  }
  function offer(remote) {
    const note = $('position-note');
    note.replaceChildren(who(remote) + '에서 읽던 ' + remote.page + '쪽으로 이동할까요?',
      button('이동', () => adopt(remote, true)), button(conflict ? '여기서 계속' : '무시', () => adopt(remote, false)));
    note.hidden = false;
  }
  async function adopt(remote, go) {
    revision = Math.max(revision, remote.revision);
    conflict = false;
    $('position-note').hidden = true;
    if (go) {
      dirty = false; clearTimeout(saveTimer);
      saveLocal(paper.id, remote);
      if (mode === 'summary') { page = remote.page; fraction = remote.fraction; }
      else await goTo(remote.page, remote.fraction, false);
    } else if (dirty) await writePosition();
  }
  function changed() {
    dirty = true;
    clearTimeout(saveTimer);
    if (!conflict) saveTimer = setTimeout(writePosition, 550);
  }

  // ----- layout helpers
  function baseWidth() {
    const style = getComputedStyle(viewport);
    const inner = viewport.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
    return Math.max(120, Math.min(inner, 832));
  }
  function updateNavigation() {
    $('nav-pages').hidden = mode === 'summary';
    if (document.activeElement !== $('page')) $('page').value = page;
    $('go-page').hidden = true;
    const pages = pdf?.numPages || paper.pages || 0;
    $('total').textContent = pages ? ' / ' + pages : '';
    $('prev').disabled = !pdf || page <= 1;
    $('next').disabled = !pdf || page >= pages;
    $('page').disabled = !pdf;
    reader.dataset.flow = flow;
    reader.dataset.zoom = String(zoom);
    for (const b of document.querySelectorAll('#view-panel [data-zoom]')) b.setAttribute('aria-pressed', String(Number(b.dataset.zoom) === zoom));
    for (const b of document.querySelectorAll('#view-panel [data-flow]')) b.setAttribute('aria-pressed', String(b.dataset.flow === flow));
  }
  function readFraction() {
    const sheet = $('sheet');
    return sheet.offsetHeight ? clamp((viewport.getBoundingClientRect().top - sheet.getBoundingClientRect().top) / sheet.offsetHeight, 0, 1) : 0;
  }
  async function extractText() {
    if (!currentPage || !$('text-details').open) return;
    const which = renderGeneration;
    $('page-text').textContent = '텍스트 불러오는 중';
    try {
      const text = await currentPage.getTextContent();
      if (alive && which === renderGeneration) $('page-text').textContent = text.items.map(item => (item.str || '') + (item.hasEOL ? '\n' : ' ')).join('').trim() || '이 쪽에 추출할 수 있는 텍스트가 없습니다.';
    } catch { if (alive && which === renderGeneration) $('page-text').textContent = '텍스트를 불러오지 못했습니다.'; }
  }
  // Keep the point under `anchor` (client coordinates) in place across a size change of `element`.
  function anchorOf(element, anchor) {
    const rect = element.getBoundingClientRect();
    const point = anchor || { x: viewport.getBoundingClientRect().left + viewport.clientWidth / 2, y: viewport.getBoundingClientRect().top + viewport.clientHeight / 3 };
    return { ...point, rx: (point.x - rect.left) / Math.max(1, rect.width), ry: (point.y - rect.top) / Math.max(1, rect.height) };
  }
  function restoreAnchor(element, a) {
    const rect = element.getBoundingClientRect();
    viewport.scrollLeft += rect.left + a.rx * rect.width - a.x;
    viewport.scrollTop += rect.top + a.ry * rect.height - a.y;
  }

  // ----- one page at a time
  async function displayPage(target, targetFraction = 0, record = true, anchor = null) {
    if (!pdf || !alive) return;
    const which = ++renderGeneration;
    const book = pdf;
    const oldRender = renderTask;
    oldRender?.cancel();
    target = clamp(target, 1, book.numPages);
    const samePage = target === page && !$('sheet').hidden && currentPage;
    isReady = false;
    userInteracted = false;
    if (target !== page) $('text-details').open = false;
    page = target;
    fraction = targetFraction;
    updateNavigation();
    const sheet = $('sheet');
    const kept = samePage ? anchorOf(sheet, anchor) : null;
    if (!samePage) { currentPage = null; sheet.hidden = $('text-details').hidden = true; message('쪽 여는 중'); }
    try {
      if (oldRender) await oldRender.promise.catch(() => {});
      if (which !== renderGeneration) return;
      const item = await book.getPage(target);
      if (!alive || which !== renderGeneration) return;
      sheet.hidden = false;
      sheet.classList.toggle('zoomed', zoom !== 1);
      sheet.style.width = zoom === 1 ? '' : Math.round(baseWidth() * zoom) + 'px';
      const width = sheet.clientWidth;
      renderWidth = width;
      const fresh = document.createElement('canvas');
      fresh.setAttribute('role', 'img');
      renderTask = draw(item, fresh, width, 5000000);
      await renderTask.promise;
      if (!alive || which !== renderGeneration) return;
      // Swap only a finished bitmap so re-rendering at a new zoom never flashes blank.
      const old = $('canvas');
      fresh.id = 'canvas';
      fresh.setAttribute('aria-label', target + '쪽 PDF');
      old.replaceWith(fresh);
      old.width = old.height = 0;
      currentPage = item;
      message('');
      $('text-details').hidden = false;
      if (kept) restoreAnchor(sheet, kept);
      else viewport.scrollTop += sheet.getBoundingClientRect().top - viewport.getBoundingClientRect().top + targetFraction * sheet.offsetHeight;
      isReady = true;
      if ($('text-details').open) void extractText();
      if (record) changed();
    } catch (error) {
      if (!alive || which !== renderGeneration || error?.name === 'RenderingCancelledException') return;
      $('sheet').hidden = true;
      message('이 쪽을 표시하지 못했습니다.', () => displayPage(target, targetFraction, record), true);
    }
  }

  // ----- continuous scroll: placeholders for every page, bitmaps only near the viewport
  function teardownSlots() {
    slotObserver?.disconnect(); slotObserver = null;
    ++layoutGeneration;
    for (const task of slotTasks.values()) task.cancel();
    slotTasks.clear();
    for (const slot of slots) for (const canvas of slot.querySelectorAll('canvas')) canvas.width = canvas.height = 0;
    slots = [];
    $('pages').replaceChildren();
    $('pages').hidden = true;
  }
  function layoutSlots() {
    const width = Math.round(baseWidth() * zoom);
    $('pages').classList.toggle('zoomed', zoom !== 1);
    for (const slot of slots) {
      slot.style.width = zoom === 1 ? '' : width + 'px';
      if (!slot.dataset.ratio) slot.style.aspectRatio = '1 / ' + pageAspect;
    }
  }
  function observeSlots() {
    slotObserver?.disconnect();
    const generation = ++layoutGeneration;
    for (const slot of slots) delete slot.dataset.drawn;
    // Observing again reports every slot once, so visible pages redraw at the new size.
    slotObserver = new IntersectionObserver(entries => {
      for (const entry of entries) if (entry.isIntersecting) void drawSlot(Number(entry.target.dataset.page), generation);
    }, { root: viewport, rootMargin: '120% 0px' });
    for (const slot of slots) slotObserver.observe(slot);
  }
  async function drawSlot(number, generation) {
    const slot = slots[number - 1];
    if (!slot || !pdf || slot.dataset.drawn === String(generation)) return;
    slot.dataset.drawn = String(generation);
    try {
      const item = await pdf.getPage(number);
      if (!alive || generation !== layoutGeneration) return;
      const size = item.getViewport({ scale: 1 });
      slot.dataset.ratio = '1';
      slot.style.aspectRatio = size.width + ' / ' + size.height;
      const canvas = document.createElement('canvas');
      const task = draw(item, canvas, slot.clientWidth, 3000000);
      slotTasks.get(number)?.cancel();
      slotTasks.set(number, task);
      await task.promise;
      if (slotTasks.get(number) === task) slotTasks.delete(number);
      if (!alive || generation !== layoutGeneration) { canvas.width = canvas.height = 0; return; }
      for (const old of slot.querySelectorAll('canvas')) old.width = old.height = 0;
      slot.replaceChildren(canvas);
      releaseFarSlots();
    } catch (error) {
      if (slot.dataset.drawn === String(generation)) delete slot.dataset.drawn;
      if (error?.name !== 'RenderingCancelledException' && alive) slot.textContent = number + '쪽을 표시하지 못했습니다.';
    }
  }
  function releaseFarSlots() {
    const drawn = slots.filter(slot => slot.querySelector('canvas'));
    if (drawn.length <= KEEP_RENDERED) return;
    drawn.sort((a, b) => Math.abs(b.dataset.page - page) - Math.abs(a.dataset.page - page));
    for (const slot of drawn.slice(0, drawn.length - KEEP_RENDERED)) {
      for (const canvas of slot.querySelectorAll('canvas')) canvas.width = canvas.height = 0;
      slot.replaceChildren();
      delete slot.dataset.drawn;
    }
  }
  function slotAt(y) {
    let low = 0, high = slots.length - 1;
    while (low < high) {
      const middle = (low + high + 1) >> 1;
      if (slots[middle].getBoundingClientRect().top <= y) low = middle; else high = middle - 1;
    }
    return slots[low];
  }
  function scrollToSlot(number, offset) {
    const slot = slots[clamp(number, 1, slots.length) - 1];
    if (slot) viewport.scrollTop += slot.getBoundingClientRect().top - viewport.getBoundingClientRect().top + offset * slot.offsetHeight;
  }
  async function showContinuous(target, targetFraction) {
    const which = ++renderGeneration;
    const book = pdf;
    renderTask?.cancel();
    teardownSlots();
    isReady = false; userInteracted = false;
    $('sheet').hidden = $('text-details').hidden = true;
    try {
      const first = await book.getPage(1);
      if (!alive || which !== renderGeneration) return;
      const size = first.getViewport({ scale: 1 });
      pageAspect = size.height / size.width;
      slots = Array.from({ length: book.numPages }, (_, index) => {
        const slot = document.createElement('div');
        slot.className = 'page-slot';
        slot.dataset.page = String(index + 1);
        slot.setAttribute('role', 'img');
        slot.setAttribute('aria-label', (index + 1) + '쪽 PDF');
        return slot;
      });
      $('pages').append(...slots);
      $('pages').hidden = false;
      layoutSlots();
      message('');
      page = clamp(target, 1, book.numPages); fraction = targetFraction;
      scrollToSlot(page, fraction);
      updateNavigation();
      observeSlots();
      renderWidth = baseWidth();
      isReady = true;
    } catch {
      if (alive && which === renderGeneration) message('PDF를 표시하지 못했습니다.', () => showContinuous(target, targetFraction), true);
    }
  }
  function trackContinuous() {
    const top = viewport.getBoundingClientRect().top + 8;
    const slot = slotAt(top);
    const rect = slot.getBoundingClientRect();
    const next = Number(slot.dataset.page);
    fraction = clamp((top - rect.top) / Math.max(1, rect.height), 0, 1);
    if (next !== page) { page = next; updateNavigation(); }
  }

  // ----- shared navigation
  async function goTo(target, targetFraction = 0, record = true) {
    if (!pdf) return;
    if (flow === 'scroll') {
      page = clamp(target, 1, pdf.numPages); fraction = targetFraction;
      scrollToSlot(page, fraction);
      updateNavigation();
      if (record) changed();
    } else await displayPage(target, targetFraction, record);
  }
  function turn(delta) {
    if (pdf && page + delta >= 1 && page + delta <= pdf.numPages) void goTo(page + delta);
  }
  function setZoom(next, anchor = null) {
    next = clamp(Math.round(next * 4) / 4, 1, MAX_ZOOM);
    if (next === zoom || !pdf || mode === 'summary') { updateNavigation(); return; }
    zoom = next;
    if (flow === 'scroll') {
      const kept = anchorOf($('pages'), anchor);
      layoutSlots();
      restoreAnchor($('pages'), kept);
      observeSlots();
      updateNavigation();
    } else void displayPage(page, fraction, false, anchor);
  }
  function setFlow(next) {
    if (next === flow) return;
    flow = next;
    storeFlow(flow);
    if (!pdf || mode === 'summary') { updateNavigation(); return; }
    if (flow === 'scroll') void showContinuous(page, fraction);
    else { teardownSlots(); void displayPage(page, fraction, false); }
  }

  function resetDocument() {
    ++renderGeneration;
    renderTask?.cancel();
    renderTask = null; currentPage = null; pdf = null; isReady = false;
    teardownSlots();
    const old = docTask;
    docTask = null;
    if (old) void old.destroy().catch(() => {});
    const canvas = $('canvas');
    canvas.width = canvas.height = 1;
    $('sheet').hidden = $('text-details').hidden = true;
  }
  async function showPdf() {
    const which = ++fileGeneration;
    resetDocument();
    clearTimeout(summaryTimer);
    $('summary').hidden = true;
    $('text-details').open = false;
    message('PDF 여는 중');
    updateNavigation();
    let deadline;
    try {
      const loading = pdfjs.getDocument({ url: base + '/file/' + mode, cMapUrl: '/vendor/pdfjs/cmaps/', cMapPacked: true, standardFontDataUrl: '/vendor/pdfjs/standard_fonts/', withCredentials: true, isEvalSupported: false, disableAutoFetch: true, disableStream: true });
      docTask = loading;
      let timedOut = false;
      deadline = setTimeout(() => { timedOut = true; void loading.destroy().catch(() => {}); if (alive && which === fileGeneration) message('응답이 늦어지고 있습니다. PC 연결을 확인해 주세요.', showPdf, true); }, 45000);
      const loaded = await loading.promise;
      if (!alive || which !== fileGeneration || timedOut) return;
      pdf = loaded;
      // Opening a paper is not a reading movement and is never written.
      if (flow === 'scroll') await showContinuous(page, fraction);
      else await displayPage(page, fraction, false);
    } catch {
      if (alive && which === fileGeneration) message('PDF를 열지 못했습니다. PC 연결을 확인해 주세요.', showPdf, true);
    } finally { clearTimeout(deadline); }
  }
  function drawSummary(data) {
    const article = $('summary');
    article.replaceChildren();
    const heading = document.createElement('h2'); heading.textContent = '요약'; article.append(heading);
    const claims = Array.isArray(data.tldr) ? data.tldr : [data.tldr];
    const ol = document.createElement('ol');
    claims.forEach((claim, index) => {
      if (typeof claim !== 'string' || !claim.trim()) return;
      const li = document.createElement('li'); li.append(claim);
      const evidence = Array.isArray(data.sources) ? data.sources.filter(s => s.claim === index && Number.isInteger(s.page) && s.page > 0 && (!paper.pages || s.page <= paper.pages)) : [];
      for (const p of new Set(evidence.map(s => s.page))) {
        if (paper.original === false) li.append(' (' + p + '쪽)');
        else li.append(' ', button(p + '쪽 원문', () => { mode = $('mode').value = 'original'; page = p; fraction = 0; changed(); void showPdf(); }));
      }
      ol.append(li);
    });
    if (ol.children.length) article.append(ol);
    if (typeof data.overview === 'string' && data.overview.trim()) {
      const p = document.createElement('p'); p.textContent = data.overview; article.append(p);
    }
    return article.children.length > 1;
  }
  async function showSummary() {
    const which = ++fileGeneration;
    resetDocument();
    clearTimeout(summaryTimer);
    updateNavigation();
    $('summary').hidden = true;
    message('요약 불러오는 중');
    try {
      const data = await api(base + '/summary', { signal: lifetime.signal });
      if (!alive || which !== fileGeneration) return;
      if (drawSummary(data)) {
        $('summary').hidden = false; message(''); viewport.scrollTop = 0;
      } else if (['queued', 'running'].includes(paper.summary_status)) {
        message('PC에서 요약하는 중입니다.');
        summaryTimer = setTimeout(showSummary, 4500);
      } else if (paper.scanned) message('스캔 PDF의 요약에는 OCR로 인식한 텍스트가 필요합니다.');
      else message(paper.summary_status === 'error' ? 'PC에서 요약을 완료하지 못했습니다. PC에서 작업 상태를 확인해 주세요.' : '이 논문에는 저장된 요약이 없습니다.');
      if (paper.original === false && !paper.translated && paper.bilingual) {
        $('read-notice').hidden = false; $('read-notice').append(pdfLink(base + '/file/bilingual', '원문·번역 PDF 열기'));
      }
    } catch { if (alive && which === fileGeneration) message('요약을 불러오지 못했습니다.', showSummary); }
  }

  // ----- controls
  $('mode').addEventListener('change', () => {
    mode = $('mode').value;
    void (mode === 'summary' ? showSummary() : showPdf());
  }, events);
  $('prev').addEventListener('click', () => turn(-1), events);
  $('next').addEventListener('click', () => turn(1), events);
  $('view-toggle').addEventListener('click', () => {
    const open = $('view-panel').hidden;
    $('view-panel').hidden = !open;
    $('view-toggle').setAttribute('aria-expanded', String(open));
  }, events);
  for (const b of document.querySelectorAll('#view-panel [data-zoom]')) b.addEventListener('click', () => setZoom(Number(b.dataset.zoom)), events);
  for (const b of document.querySelectorAll('#view-panel [data-flow]')) b.addEventListener('click', () => setFlow(b.dataset.flow), events);
  $('page').addEventListener('input', () => { $('go-page').hidden = $('page').value === String(page); }, events);
  $('page-form').addEventListener('submit', event => {
    event.preventDefault();
    $('go-page').hidden = true;
    const value = Number($('page').value);
    if (Number.isSafeInteger(value) && pdf && value >= 1 && value <= pdf.numPages) { $('page').blur(); void goTo(value); }
    else { $('page').value = page; message('1부터 ' + (pdf?.numPages || 1) + ' 사이의 쪽을 입력해 주세요.'); }
  }, events);
  $('text-details').addEventListener('toggle', () => { void extractText(); }, events);
  for (const input of ['pointerdown', 'touchstart', 'wheel', 'keydown']) viewport.addEventListener(input, () => { userInteracted = true; }, { ...events, passive: true });
  viewport.addEventListener('scroll', () => {
    if (!isReady || !userInteracted) return;
    cancelAnimationFrame(scrollFrame);
    scrollFrame = requestAnimationFrame(() => {
      if (!alive || !isReady || !userInteracted) return;
      if (flow === 'scroll' && slots.length) trackContinuous(); else fraction = readFraction();
      changed();
    });
  }, { ...events, passive: true });
  viewport.addEventListener('keydown', event => {
    if (flow !== 'page' || zoom !== 1 || mode === 'summary' || event.target !== viewport) return;
    if (event.key === 'ArrowRight') { event.preventDefault(); turn(1); }
    else if (event.key === 'ArrowLeft') { event.preventDefault(); turn(-1); }
  }, events);

  // Edge taps and horizontal swipes turn pages at fit width, one page at a time.
  let press = null;
  viewport.addEventListener('pointerdown', event => {
    press = event.isPrimary ? { x: event.clientX, y: event.clientY, at: performance.now(), id: event.pointerId, target: event.target } : null;
  }, events);
  viewport.addEventListener('pointercancel', () => { press = null; }, events);
  viewport.addEventListener('pointerup', event => {
    const start = press; press = null;
    if (!start || start.id !== event.pointerId || pinch || flow !== 'page' || zoom !== 1 || !pdf || mode === 'summary' || !$('sheet').contains(start.target)) return;
    const dx = event.clientX - start.x, dy = event.clientY - start.y, elapsed = performance.now() - start.at;
    if (Math.abs(dx) > 60 && Math.abs(dx) > 2 * Math.abs(dy) && elapsed < 700) { turn(dx < 0 ? 1 : -1); return; }
    if (Math.abs(dx) < 10 && Math.abs(dy) < 10 && elapsed < 350) {
      const box = viewport.getBoundingClientRect();
      const x = (event.clientX - box.left) / box.width;
      if (x < .28) turn(-1); else if (x > .72) turn(1);
    }
  }, events);

  // Two-finger pinch scales the bitmap live and re-renders it sharply when the fingers lift.
  let pinch = null;
  const spread = touches => Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
  const middle = touches => ({ x: (touches[0].clientX + touches[1].clientX) / 2, y: (touches[0].clientY + touches[1].clientY) / 2 });
  viewport.addEventListener('touchstart', event => {
    if (event.touches.length !== 2 || !pdf || mode === 'summary' || !isReady) return;
    const target = flow === 'scroll' ? $('pages') : $('sheet');
    const rect = target.getBoundingClientRect(), center = middle(event.touches);
    pinch = { target, distance: Math.max(1, spread(event.touches)), center, ox: center.x - rect.left, oy: center.y - rect.top, scale: 1 };
  }, { ...events, passive: true });
  viewport.addEventListener('touchmove', event => {
    if (!pinch || event.touches.length !== 2) return;
    event.preventDefault();
    pinch.scale = clamp(spread(event.touches) / pinch.distance, 1 / zoom, MAX_ZOOM / zoom);
    pinch.target.style.transform = `translate(${pinch.ox}px, ${pinch.oy}px) scale(${pinch.scale}) translate(${-pinch.ox}px, ${-pinch.oy}px)`;
  }, { ...events, passive: false });
  const endPinch = event => {
    if (!pinch || event.touches.length >= 2) return;
    const { target, scale, center } = pinch;
    pinch = null;
    target.style.transform = '';
    if (Math.abs(scale - 1) > .05) setZoom(zoom * scale, center);
  };
  viewport.addEventListener('touchend', endPinch, events);
  viewport.addEventListener('touchcancel', endPinch, events);
  // Safari's own page zoom would fight the reader's zoom.
  document.addEventListener('gesturestart', event => { if (!reader.hidden) event.preventDefault(); }, events);

  const observer = new ResizeObserver(() => {
    if (!alive || !isReady) return;
    if (flow === 'scroll' && slots.length) {
      if (Math.abs(baseWidth() - renderWidth) > 1) { renderWidth = baseWidth(); const kept = { page, fraction }; layoutSlots(); scrollToSlot(kept.page, kept.fraction); observeSlots(); }
    } else if (!$('sheet').hidden && zoom === 1 && Math.abs($('sheet').clientWidth - renderWidth) > 1) void displayPage(page, fraction, false);
  });
  observer.observe(viewport);
  $('back').addEventListener('click', onBack, events);
  updateNavigation();
  if (mode === 'summary') void showSummary(); else void showPdf();
  return {
    flush: writePosition,
    changed() { return dirty || saving; },
    update(next) {
      const previousSummary = paper.summary_status;
      const lostSource = paper.original !== false && next.original === false;
      Object.assign(paper, next);
      const previousMode = mode;
      if (mode === 'original' && paper.original === false || mode === 'translated' && !paper.translated) mode = bestMode();
      updateModes();
      if (mode !== previousMode) void (mode === 'summary' ? showSummary() : showPdf());
      else if (mode === 'summary' && (lostSource || paper.summary_status !== previousSummary)) void showSummary();
      // Another device (usually the PC) moved on in this paper: offer its place, never jump unasked.
      const remote = next.position;
      if (remote && remote.revision > revision && !conflict && !saving) {
        if (remote.page === page) revision = remote.revision;
        else offer(remote);
      }
    },
    close(save = true) {
      if (save) void writePosition(); else dirty = false;
      alive = false; ++fileGeneration;
      lifetime.abort(); clearTimeout(saveTimer); clearTimeout(summaryTimer); cancelAnimationFrame(scrollFrame);
      observer.disconnect(); resetDocument(); $('summary').replaceChildren(); $('page-text').replaceChildren(); $('paper-title').replaceChildren();
      $('position-note').hidden = true;
    }
  };
}
