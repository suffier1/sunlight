// Shows a small offline page when the PC cannot be reached. Papers, API answers and app code are never cached here.
const CACHE = 'sunlight-shell-v1';
const OFFLINE = '/mobile/offline.html';
const GATEWAY = new Set([502, 503, 504, 520, 521, 522, 523, 524, 525, 526, 527, 530]);

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll([OFFLINE, '/mobile/icon-192.png'])).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (event.request.mode !== 'navigate') return;
  event.respondWith(fetch(event.request).then(response => GATEWAY.has(response.status) ? offline(response) : response, () => offline()));
});
async function offline(fallback) {
  return (await caches.match(OFFLINE)) || fallback || Response.error();
}
