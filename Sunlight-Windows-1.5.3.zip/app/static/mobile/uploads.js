import { createChunkPlanner, kbps, PART_BYTES } from './chunking.js';
import { failure } from './errors.js';

const MAX_BYTES = 300 * 1024 * 1024;
const RETRY_DELAYS = [1000, 3000, 6000];
const databaseName = 'sunlight-mobile-transfers';

async function withStore(mode, operation, names = ['files']) {
  const db = await new Promise((resolve, reject) => {
    const request = indexedDB.open(databaseName, 2);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains('files')) database.createObjectStore('files', { keyPath: 'id' });
      if (!database.objectStoreNames.contains('parts')) database.createObjectStore('parts');
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(names, mode);
      const request = operation(...names.map(name => tx.objectStore(name)));
      tx.oncomplete = () => resolve(request?.result);
      tx.onabort = () => reject(tx.error);
      tx.onerror = () => reject(tx.error);
    });
  } finally { db.close(); }
}

function deleteFile(id) {
  return withStore('readwrite', (files, parts) => {
    files.delete(id);
    parts.delete(IDBKeyRange.bound([id, 0], [id, Number.MAX_SAFE_INTEGER]));
  }, ['files', 'parts']);
}

// The selected File disappears when iOS reloads or discards the page, so a copy lets the transfer
// resume without choosing the file again. It runs beside the transfer instead of delaying it.
async function rememberFile(record, signal, onProgress) {
  try {
    await withStore('readwrite', files => files.put(record));
    return;
  } catch {
    // Some WebKit storage contexts accept binary buffers but reject cloned Files.
    // Copy in bounded pieces and mark the request resumable only after every piece commits.
  }
  const { file, ...metadata } = record;
  const staged = { ...metadata, size:file.size, buffered:false };
  await withStore('readwrite', files => files.put(staged));
  try {
    for (let offset = 0; offset < file.size; offset += PART_BYTES) {
      if (signal.aborted) throw new Error('전송 준비가 중단됐습니다.');
      const bytes = await file.slice(offset, offset + PART_BYTES).arrayBuffer();
      await withStore('readwrite', parts => parts.put(bytes, [record.id, offset]), ['parts']);
      onProgress(Math.min(1, (offset + PART_BYTES) / file.size));
    }
    await withStore('readwrite', files => files.put({ ...staged, buffered:true }));
  } catch (error) {
    await deleteFile(record.id);
    throw error;
  }
}

async function readPart(task, offset, end) {
  if (task.file) return task.file.slice(offset, end, 'application/octet-stream');
  const start = Math.floor(offset / PART_BYTES) * PART_BYTES;
  const bytes = await withStore('readonly', parts => parts.get([task.id, start]), ['parts']);
  if (!(bytes instanceof ArrayBuffer) || bytes.byteLength < end - start) {
    const error = new Error('저장한 전송 파일을 읽을 수 없습니다. PDF를 다시 선택해 주세요.');
    error.status = 422;
    throw error;
  }
  return new Uint8Array(bytes, offset - start, end - offset);
}

// One chunk per request with byte progress. XHR is used because fetch cannot report upload progress.
function sendChunk(url, body, { timeout, signal, onProgress }) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const abort = () => xhr.abort();
    const settle = () => signal.removeEventListener('abort', abort);
    signal.addEventListener('abort', abort, { once: true });
    xhr.open('PUT', url);
    xhr.timeout = timeout;
    xhr.upload.onprogress = event => onProgress(event.loaded);
    xhr.onload = () => {
      settle();
      // A login page in front of the tunnel ends the request on another origin.
      const foreign = Boolean(xhr.responseURL) && new URL(xhr.responseURL).origin !== location.origin;
      let data = null;
      try { data = JSON.parse(xhr.responseText); } catch { /* not ours */ }
      if (!foreign && data && xhr.status >= 200 && xhr.status < 300) resolve(data);
      else reject(failure({ status: xhr.status, data, foreign }));
    };
    xhr.onerror = () => { settle(); reject(failure({})); };
    xhr.onabort = () => { settle(); reject(failure({})); };
    xhr.ontimeout = () => { settle(); reject(Object.assign(failure({ timedOut: true }), { slow: true })); };
    xhr.send(body);
  });
}

function wait(ms, signal) {
  return new Promise(resolve => {
    const timer = setTimeout(resolve, ms);
    signal.addEventListener('abort', () => { clearTimeout(timer); resolve(); }, { once: true });
  });
}

export async function forgetTransfers() {
  try { await withStore('readwrite', (files, parts) => { files.clear(); parts.clear(); }, ['files','parts']); }
  catch { /* Private storage can be disabled. */ }
}

export function createUploads({ device, api, onSaved, onOpen, onActivity }) {
  const list = document.querySelector('#transfer-list');
  const panel = document.querySelector('#transfers');
  const clearButton = document.querySelector('#clear-finished');
  const help = document.querySelector('#transfer-help');
  const announcement = document.querySelector('#transfer-status');
  const tasks = new Map();
  const lifetime = new AbortController();
  let draining = false;
  const pending = task => ['preparing', 'queued', 'sending'].includes(task.state);
  const active = () => [...tasks.values()].some(pending);
  const unfinished = () => [...tasks.values()].some(task => pending(task) || task.state === 'paused');

  function draw(task) {
    if (lifetime.signal.aborted) return;
    if (!task.element) {
      task.element = document.createElement('li');
      list.append(task.element);
    }
    const detail = document.createElement('div');
    detail.className = 'transfer-detail';
    const title = document.createElement('strong');
    title.textContent = task.file?.name || task.filename;
    const status = document.createElement('span');
    const preparing = task.copying !== undefined && pending(task) ? ' · 이어받기 준비 ' + Math.round(task.copying * 100) + '%' : '';
    status.textContent = task.message + preparing + (task.volatile && task.state === 'paused' ? ' 이 화면을 닫으면 파일을 다시 선택해야 합니다.' : '');
    detail.append(title, status);
    if (task.announced !== task.state && ['done', 'paused', 'failed'].includes(task.state)) {
      announcement.textContent = task.filename + ' · ' + status.textContent;
      task.announced = task.state;
    }
    task.element.replaceChildren(detail);
    function action(label, fn) {
      const button = document.createElement('button');
      button.className = 'action-link';
      button.textContent = label;
      button.onclick = fn;
      task.element.append(button);
    }
    if (task.state === 'paused') action('재시도', () => { task.slow = false; enqueue(task); });
    if (task.state === 'done') action('열기', () => onOpen(task.paperId));
    if (task.state === 'failed' || task.state === 'paused') action('지우기', async () => {
      if (task.state === 'paused') {
        try { await api('/m/api/uploads/' + encodeURIComponent(task.id), { method: 'DELETE', signal: lifetime.signal }); }
        catch (error) { if (error.status !== 404) { task.message = 'PC의 임시 전송을 지우지 못했습니다. 다시 시도해 주세요.'; draw(task); return; } }
      }
      await discard(task);
      task.element.remove();
      tasks.delete(task.id);
      updatePanel();
    });
    updatePanel();
  }

  function updatePanel() {
    panel.hidden = !tasks.size;
    help.hidden = !active();
    clearButton.hidden = ![...tasks.values()].some(task => task.state === 'done' || task.state === 'failed');
    onActivity(active());
  }

  clearButton.onclick = async () => {
    for (const task of tasks.values()) {
      if (!['done', 'failed'].includes(task.state)) continue;
      if (task.state === 'failed') await discard(task);
      task.element.remove();
      tasks.delete(task.id);
    }
    updatePanel();
  };

  // Stop a running copy first so a late write cannot recreate the stored record.
  async function discard(task) {
    task.copy?.abort();
    await task.prepared?.catch(() => {});
    try { await deleteFile(task.id); } catch { /* Receipt on the PC makes a replay safe. */ }
    task.file = null;
  }

  function enqueue(task) {
    task.state = 'queued';
    task.message = '전송 대기';
    draw(task);
    void drain();
  }

  async function transfer(task) {
    const url = '/m/api/uploads/' + encodeURIComponent(task.id);
    const size = task.file?.size ?? task.size;
    const state = await api(url, { signal: lifetime.signal, timeout: 30000, method: 'POST', json: { filename: task.filename, size, summary: task.summary } });
    if (state.receipt) return state.receipt;
    let offset = state.offset;
    if (!Number.isSafeInteger(offset) || offset < 0 || offset > size) throw new Error('PC에서 전송 위치를 확인할 수 없습니다.');
    const planner = task.planner ??= createChunkPlanner();
    const progress = sent => {
      task.message = '전송 중 · ' + Math.floor(Math.min(size, offset + sent) / size * 100) + '%';
      draw(task);
    };
    while (offset < size) {
      const end = planner.end(offset, size);
      progress(0);
      const started = performance.now();
      let next;
      try {
        next = await sendChunk(url + '?offset=' + offset, await readPart(task, offset, end),
          { timeout: planner.timeout(end - offset), signal: lifetime.signal, onProgress: progress });
      } catch (error) {
        planner.failed();
        // The PC may have stored the chunk before the reply was lost; the next attempt asks for the offset again.
        if (error.status === 409) error.resync = true;
        throw error;
      }
      if (next.receipt) return next.receipt;
      if (next.offset !== end) throw Object.assign(new Error('전송 위치가 바뀌었습니다. 다시 시도해 주세요.'), { resync: true });
      const speed = planner.record(end - offset, performance.now() - started);
      offset = end;
      if (speed.slow && offset < size) {
        throw Object.assign(new Error('연결이 너무 느립니다(약 ' + kbps(speed.rate) + ' kbps). Wi-Fi 등 더 빠른 연결에서 재시도해 주세요.'), { slow: true });
      }
    }
    task.message = 'PC 저장 확인 중';
    draw(task);
    const final = await api(url + '/finish', { signal: lifetime.signal, timeout: 90000, method: 'POST' });
    if (!final.receipt?.id) throw new Error('PC에서 저장 결과를 받지 못했습니다.');
    return final.receipt;
  }

  // Short outages are retried a few times; a slow link, a login prompt or a refusal waits for the user.
  async function transferWithRetries(task) {
    for (let attempt = 0; ; attempt++) {
      try { return await transfer(task); }
      catch (error) {
        const transient = error.resync || ['offline', 'pc_off', 'timeout'].includes(error.code) || error.status >= 500;
        if (lifetime.signal.aborted || error.slow || !transient || attempt >= RETRY_DELAYS.length) throw error;
        task.message = (error.code === 'pc_off' ? 'PC 응답을 기다리는 중' : '연결이 끊겨 다시 시도하는 중') + ' (' + (attempt + 1) + '/' + RETRY_DELAYS.length + ')';
        draw(task);
        await wait(RETRY_DELAYS[attempt], lifetime.signal);
      }
    }
  }

  async function drain() {
    if (draining || lifetime.signal.aborted) return;
    draining = true;
    try {
      let task;
      while (!lifetime.signal.aborted && (task = [...tasks.values()].find(entry => entry.state === 'queued'))) {
        task.state = 'sending';
        try {
          const receipt = await transferWithRetries(task);
          if (lifetime.signal.aborted) break;
          task.state = 'done';
          task.paperId = receipt.id;
          task.message = receipt.duplicate ? 'PC 라이브러리에 있는 PDF' : 'PC에 저장됨';
          void discard(task);
          onSaved();
        } catch (error) {
          if (lifetime.signal.aborted) break;
          const permanent = [400, 413, 415, 422].includes(error.status);
          task.state = permanent ? 'failed' : 'paused';
          task.slow = Boolean(error.slow);
          task.message = error.message;
          if (permanent) await discard(task);
        }
        draw(task);
      }
    } finally { draining = false; }
  }

  async function add(files, summary) {
    for (const file of files) {
      if (lifetime.signal.aborted) return;
      const id = crypto.randomUUID();
      const task = { id, device, filename: file.name, file, summary, state: 'preparing', message: '전송 준비 중' };
      tasks.set(id, task);
      const invalid = !file.size || file.size > MAX_BYTES || !/\.pdf$/i.test(file.name);
      if (invalid) {
        task.state = 'failed';
        task.message = file.size > MAX_BYTES ? '300 MiB 이하의 PDF를 선택해 주세요.' : '내용이 있는 PDF 파일을 선택해 주세요.';
        task.file = null;
        draw(task);
        continue;
      }
      // Keep only pending files so that a reload uses the same bytes and request ID.
      task.volatile = true;
      task.copy = new AbortController();
      task.copying = 0;
      task.prepared = rememberFile({ id, device, filename: file.name, file, summary }, task.copy.signal, part => { task.copying = part; draw(task); })
        .then(() => { task.volatile = false; }, () => { /* the transfer still runs from the selected file */ })
        .finally(() => { task.copying = undefined; if (!lifetime.signal.aborted && tasks.has(id)) draw(task); });
      enqueue(task);
    }
  }

  async function restore() {
    let records = [];
    try { records = await withStore('readonly', store => store.getAll()); } catch { return; }
    if (lifetime.signal.aborted) return;
    for (const entry of records) {
      if (entry.device !== device) {
        await discard(entry);
        continue;
      }
      if (tasks.has(entry.id)) continue;
      const complete = entry.file instanceof Blob || entry.buffered === true && Number.isSafeInteger(entry.size) && entry.size > 0;
      const task = { ...entry, state: complete ? 'queued' : 'failed', message: complete ? '전송 재개 중' : '파일 준비가 중단됐습니다. PDF를 다시 선택해 주세요.' };
      tasks.set(task.id, task);
      draw(task);
    }
    void drain();
  }

  // Coming back online resumes interrupted transfers, but not ones paused for a too-slow link.
  function reconnect() {
    for (const task of tasks.values()) if (task.state === 'paused' && !task.slow) enqueue(task);
  }
  return {
    add, restore, reconnect, active, unfinished,
    close() {
      lifetime.abort(); clearButton.onclick = null;
      for (const task of tasks.values()) task.copy?.abort();
      tasks.clear(); list.replaceChildren(); announcement.textContent = ''; panel.hidden = true;
    }
  };
}
