import { errorText, toast, confirmDialog } from './ui-kit.js';

const field = id => document.getElementById(id);
const dialog = field('phoneControl');
const open = field('openMobile');
let host, transport, invite, awaiting, timer, generation = 0, busy = false;
let deviceListKey, choiceKey, setupLayout, message = '', renaming = null;

// Errors carry .code/.status/.detail like ui-kit's api(); the PC's mobile routes answer {detail, code}.
async function request(suffix = '', method = 'GET', data) {
  let response;
  try {
    response = await fetch('/api/mobile' + suffix, {
      method, cache: 'no-store', credentials: 'same-origin', signal: AbortSignal.timeout(10000),
      headers: data ? { 'Content-Type': 'application/json' } : {},
      body: data ? JSON.stringify(data) : undefined,
    });
  } catch {
    throw Object.assign(new Error('Sunlight 서버에 연결하지 못했습니다.'), { code: 'timeout', status: 0, detail: 'Sunlight 서버에 연결하지 못했습니다. 잠시 뒤 다시 시도해 주세요.' });
  }
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = result.detail || result.error || 'PC 연결 상태를 확인한 뒤 다시 시도해 주세요.';
    throw Object.assign(new Error(detail), { code: result.code, origin: result.origin, status: response.status, detail });
  }
  return result;
}
function show(id, visible) { field(id).hidden = !visible; }
function tell(text) {
  const el = field('phoneMessage');
  if (el.textContent !== text) el.textContent = text;
}
function ago(seconds) {
  const minutes = Math.max(0, Math.floor(Date.now() / 60000 - seconds / 60));
  if (minutes < 60) return minutes < 2 ? '방금' : minutes + '분 전';
  if (minutes < 48 * 60) return Math.floor(minutes / 60) + '시간 전';
  return Math.floor(minutes / 1440) + '일 전';
}
const shortDate = seconds => new Date(seconds * 1000).toLocaleDateString('ko-KR', { dateStyle: 'short' });

// Created here so the request panel works with the 1.4 markup as well.
function element(id, tag, after, className) {
  let node = field(id);
  if (!node) {
    node = document.createElement(tag);
    node.id = id;
    if (className) node.className = className;
    after.after(node);
  }
  return node;
}
function choiceBox() {
  const legacy = field('phoneCode');
  const box = element('phoneChoices', 'div', legacy || field('phoneName'), 'phone-buttons phone-choices');
  box.setAttribute('role', 'group');
  box.setAttribute('aria-label', '휴대폰에 보이는 번호');
  if (legacy) legacy.hidden = true;
  if (field('phoneAllow')) field('phoneAllow').hidden = true;
  const question = field('phoneRequest').querySelector('p');
  if (question) question.textContent = '휴대폰 화면에 보이는 번호를 누르세요. 내 휴대폰이 아니면 거절하세요.';
  return box;
}

function deviceRow(d) {
  const row = document.createElement('li'), name = document.createElement('span');
  const detail = document.createElement('small');
  detail.textContent = [d.agent, '마지막 사용 ' + ago(d.last_seen || d.created), shortDate(d.created) + ' 등록', d.id.slice(-4)].filter(Boolean).join(' · ');
  if (renaming === d.id) {
    const form = document.createElement('form'), input = document.createElement('input'), save = document.createElement('button'), cancel = document.createElement('button');
    form.className = 'phone-rename';
    input.value = d.name; input.maxLength = 48; input.required = true; input.setAttribute('aria-label', '기기 이름');
    save.type = 'submit'; save.className = 'btn sm primary'; save.textContent = '저장';
    cancel.type = 'button'; cancel.className = 'btn sm'; cancel.textContent = '취소';
    cancel.onclick = () => { renaming = null; deviceListKey = null; render(); };
    form.onsubmit = event => {
      event.preventDefault();
      void act(async () => {
        host = await request('/devices/' + encodeURIComponent(d.id), 'PUT', { name: input.value.trim() });
        renaming = null; deviceListKey = null;
        toast('기기 이름을 바꿨습니다.', { kind: 'success' });
      });
    };
    form.append(input, save, cancel);
    row.append(form);
    queueMicrotask(() => input.focus());
    return row;
  }
  name.textContent = d.name;
  name.append(detail);
  const actions = document.createElement('span');
  actions.className = 'phone-device-actions';
  const rename = document.createElement('button'), remove = document.createElement('button');
  rename.type = 'button'; rename.className = 'btn sm'; rename.textContent = '이름 바꾸기';
  rename.setAttribute('aria-label', d.name + ' 이름 바꾸기');
  rename.onclick = () => { renaming = d.id; deviceListKey = null; render(); };
  remove.type = 'button'; remove.className = 'btn sm'; remove.textContent = '해제';
  remove.setAttribute('aria-label', d.name + ' ' + detail.textContent + ' 연결 해제');
  remove.onclick = () => act(async () => {
    const yes = await confirmDialog({ title: '기기 연결 해제', body: d.name + ' (' + detail.textContent + ')에서 더 이상 이 라이브러리를 열 수 없습니다. 다시 쓰려면 새 QR로 연결해야 합니다.', confirm: '연결 해제', danger: true });
    if (!yes) return;
    await request('/devices/' + encodeURIComponent(d.id), 'DELETE');
    host = await request();
    toast('기기 연결을 해제했습니다.', { kind: 'success' });
  });
  actions.append(rename, remove);
  row.append(name, actions);
  return row;
}
function devices() {
  const rows = host.devices || [];
  // Relative times change slowly; rebuild at most once a minute unless the list itself changed.
  const key = JSON.stringify(rows) + renaming + Math.floor(Date.now() / 60000);
  if (key !== deviceListKey) {
    field('phoneDevices').querySelector('ul').replaceChildren(...rows.map(deviceRow));
    deviceListKey = key;
  }
  const note = element('phoneDevicesNote', 'p', field('phoneDevices').querySelector('ul'), 'hint');
  note.textContent = (host.idle_days || 30) + '일 동안 쓰지 않은 기기는 자동으로 해제됩니다.';
  show('phoneDevices', rows.length > 0);
}
function pendingRequest(pending) {
  field('phoneName').textContent = pending.agent ? pending.name + ' · ' + pending.agent : pending.name;
  const box = choiceBox();
  const key = pending.id + pending.choices.join();
  if (key === choiceKey) return;
  choiceKey = key;
  box.replaceChildren(...pending.choices.map(code => {
    const choice = document.createElement('button');
    choice.type = 'button'; choice.className = 'btn phone-choice'; choice.textContent = code;
    choice.setAttribute('aria-label', code + ' 선택해 연결 승인');
    choice.onclick = () => decide(pending, true, code);
    return choice;
  }));
}
function decide(pending, allow, code) {
  return act(async () => {
    try {
      host = await request('/approve', 'POST', allow ? { id: pending.id, allow, code } : { id: pending.id, allow });
    } catch (e) {
      host = await request().catch(() => host);
      invite = null;
      throw e;
    }
    invite = null;
    if (allow) awaiting = { ...pending, until: Date.now() + 300000 };
    else message = '연결 요청을 거절했습니다.';
  });
}
function inviteText() {
  const text = field('phoneInviteText');
  if (!invite) return;
  const label = '휴대폰 카메라로 QR을 여세요. 홈 화면 앱에서는 연결 코드 ';
  if (text.dataset.code === invite.code) return;
  const code = document.createElement('strong');
  code.className = 'phone-pair-code'; code.textContent = invite.code;
  text.replaceChildren(label, code, '를 입력하세요.');
  text.dataset.code = invite.code;
}
const HELP_URL = 'https://suffier1.github.io/sunlight/#phone-title';
// What the HTTPS address is, next to the field that asks for it. Built here so 1.4-style markup works too.
function addressHelp() {
  const label = field('phoneAddressForm').querySelector('label');
  const hint = element('phoneAddressHint', 'p', label, 'hint');
  const port = host?.port || 8771;
  const text = '휴대폰이 밖에서 이 PC에 들어오는 고정 HTTPS 주소입니다. Cloudflare Tunnel 같은 터널을 이 PC의 휴대폰 연결 포트(' + port + ')에 연결한 뒤 그 주소를 적으세요.';
  if (hint.textContent !== text) hint.textContent = text;
  let more = field('phoneAddressMore');
  if (!more) {
    more = document.createElement('details');
    const summary = document.createElement('summary'), link = document.createElement('a');
    more.id = 'phoneAddressMore'; more.className = 'hint';
    summary.textContent = '자세히';
    link.href = HELP_URL; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '휴대폰 연결 안내 열기';
    more.append(summary, document.createElement('ul'), link);
    hint.after(more);
  }
  // Mention the Tailscale button only when it is actually offered on this PC.
  const tailscale = transport?.tailscale
    ? '같은 Tailscale 네트워크의 휴대폰만 쓴다면 주소 없이 위의 ‘내 Tailscale로 연결’을 누르면 됩니다.'
    : '같은 Tailscale 네트워크의 휴대폰만 쓴다면 이 PC에 Tailscale을 설치하고 로그인한 뒤 이 창을 다시 열면, 주소 없이 연결할 수 있습니다.';
  const lines = [
    '터널의 원본 서비스는 http://127.0.0.1:' + port + ' 로 정합니다. 데스크톱 화면의 포트가 아닙니다.',
    '주소는 PC마다 달라야 하고, Cloudflare Access 같은 로그인으로 본인 계정만 들어오게 해야 합니다.',
    ...(transport ? [tailscale] : []),
  ];
  const list = more.querySelector('ul');
  if (list.dataset.text !== lines.join('\n')) {
    list.replaceChildren(...lines.map(line => { const li = document.createElement('li'); li.textContent = line; return li; }));
    list.dataset.text = lines.join('\n');
  }
}
function ready() { return host?.running && (transport?.mode !== 'tailscale' || transport.ready); }
function render() {
  if (!dialog.open) return;
  addressHelp();
  const pending = host?.pending;
  if (awaiting && host?.devices?.some(d => d.id === awaiting.id)) {
    message = awaiting.name + '에서 라이브러리를 열 수 있습니다.';
    awaiting = null;
  }
  const active = Boolean(invite && invite.until > Date.now());
  if (invite && !active) { invite = null; message = 'QR 사용 시간이 지났습니다. 새 QR을 열어 주세요.'; }
  if (awaiting && awaiting.until < Date.now()) { awaiting = null; message = '휴대폰 연결 시간이 지났습니다. 새 QR로 다시 연결해 주세요.'; }
  show('phoneStart', host && !host.running);
  show('phoneTeam', transport?.team_origin);
  show('phoneTail', transport?.tailscale);
  const portSettings = field('phonePortSettings');
  const activeTail = host?.running && transport?.mode === 'tailscale';
  if (activeTail && portSettings.parentElement === field('phoneTail')) field('phoneOff').before(portSettings);
  if (!activeTail && portSettings.parentElement !== field('phoneTail')) field('phoneTail').append(portSettings);
  show('phoneApplyPort', activeTail);
  field('phonePortHint').textContent = activeTail
    ? '현재 주소 ' + host.origin + ' · 비워 두면 사용 가능한 포트를 찾습니다.'
    : '비워 두면 사용 가능한 포트를 찾습니다.';
  if (transport && !host?.running) {
    const layout = transport.team_origin ? 'team' : transport.tailscale ? 'tailscale' : 'manual';
    if (setupLayout !== layout) {
      const alternatives = field('phoneAlternatives'), tail = field('phoneTail');
      if (layout === 'tailscale') alternatives.before(tail);
      else field('phoneAddressForm').before(tail);
      alternatives.open = layout === 'manual';
      alternatives.querySelector('summary').hidden = layout === 'manual';
      field('phoneUseTail').classList.toggle('primary', layout === 'tailscale');
      setupLayout = layout;
    }
  }
  show('phoneNew', ready() && !pending && !awaiting && !active);
  show('phoneRequest', Boolean(pending));
  show('phoneInvite', ready() && active && !pending);
  show('phoneOff', Boolean(host?.enabled));
  show('phoneRetry', !host || (host?.enabled && (!host.running || transport?.error)));
  if (pending) pendingRequest(pending); else choiceKey = null;
  if (active) inviteText();
  const shared = element('phoneTailNote', 'p', field('phoneMessage'), 'hint');
  shared.textContent = '주의: Tailscale 주소는 이 PC에서 Serve로 연 다른 포트와 이름을 함께 씁니다. 믿을 수 없는 서비스를 같은 PC에서 Tailscale Serve로 열지 마세요.';
  shared.hidden = !(host?.running && host.tailnet);
  if (host) devices(); else show('phoneDevices', false);
  const failure = host?.error ? host.error + (host.port ? ' (포트 ' + host.port + ')' : '') : transport?.error;
  tell(message || failure || (pending || active ? '' : awaiting ? '휴대폰이 연결을 마치는 중입니다.'
    : !host ? '연결 정보를 읽는 중입니다.' : !host.running ? '휴대폰에서 이 PC의 라이브러리를 열고 PDF를 보낼 수 있습니다.'
    : ready() ? '' : 'Tailscale 연결을 준비하는 중입니다.'));
  clearTimeout(timer);
  if (host?.running) timer = setTimeout(poll, pending || invite || awaiting || !ready() ? 1400 : 4500);
}
async function refresh() {
  const gen = generation;
  const [current, connection] = await Promise.all([request(), request('/transport')]);
  if (gen !== generation || !dialog.open) return;
  host = current; transport = connection;
}
async function poll() {
  if (busy || !dialog.open || renaming) { if (dialog.open && renaming) timer = setTimeout(poll, 4500); return; }
  await act(async () => {
    await refresh();
    if (!host?.running) { invite = null; awaiting = null; }
    if (startWhenReady && ready()) { startWhenReady = false; await makeInvite(); }
  }, false);
}
async function act(action, clear = true) {
  if (busy || !dialog.open) return;
  const gen = generation;
  busy = true; clearTimeout(timer);
  if (clear) message = '';
  try { await action(); }
  catch (e) { if (gen === generation) message = errorText(e) || e.message || '다시 시도해 주세요.'; }
  finally { if (gen === generation) { busy = false; render(); } }
}
async function makeInvite() {
  const gen = generation;
  const [data, qr] = await Promise.all([request('/invite', 'POST', {}), import('./vendor/qr/qrcode.mjs')]);
  if (gen !== generation || !dialog.open) return;
  const symbol = new qr.QRCode(0, qr.QRErrorCorrectLevel.M);
  symbol.addData(data.url); symbol.make();
  const canvas = field('phoneQr'), cells = symbol.getModuleCount(), scale = 6, margin = 4;
  canvas.width = canvas.height = (cells + 2 * margin) * scale;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#111';
  for (let y = 0; y < cells; y++) for (let x = 0; x < cells; x++) {
    if (symbol.isDark(y, x)) ctx.fillRect((x + margin) * scale, (y + margin) * scale, scale, scale);
  }
  awaiting = null;
  invite = { url: data.url, code: data.code, until: Date.now() + data.expires_in * 1000 };
}
let startWhenReady = false;
async function start(mode, supplied) {
  const data = { mode };
  if (mode === 'tailscale') {
    const input = field('phonePort');
    if (!input.validity.valid) {
      field('phonePortSettings').open = true;
      input.reportValidity();
      return;
    }
    data.port = input.value === '' ? null : input.valueAsNumber;
    if (host?.devices?.length) data.keep_origin = host.origin;
  }
  let choice;
  try { choice = await request('/transport', 'POST', data); }
  catch (e) {
    if (e.code !== 'origin_changed' || !e.origin) throw e;
    const yes = await confirmDialog({ title: '휴대폰 연결 주소 변경', body: '새 주소는 ' + e.origin + '입니다. 등록한 휴대폰은 새 QR로 다시 연결해야 합니다.', confirm: '주소 변경' });
    if (!yes) return;
    choice = await request('/transport', 'POST', { ...data, keep_origin: e.origin });
  }
  host = await request('', 'PUT', { enabled: true, origin: supplied || choice.origin });
  invite = awaiting = null;
  await refresh();
  if (ready()) await makeInvite(); else startWhenReady = true;
}
open.onclick = () => {
  if (dialog.open) return;
  generation++; busy = false; message = ''; setupLayout = null; host = transport = invite = awaiting = null; startWhenReady = false;
  renaming = null; deviceListKey = choiceKey = null;
  field('phoneAddress').value = '';
  field('phonePort').value = ''; field('phonePortSettings').open = false;
  dialog.classList.remove('hidden'); dialog.showModal(); field('phoneClose').focus();
  render();
  void act(async () => {
    await refresh();
    if (!host) return;
    field('phoneAddress').value = host.origin || '';
    field('phonePort').value = transport?.requested_port ?? '';
    if (ready() && !host.devices.length && !host.pending) await makeInvite();
  });
};
field('phoneClose').onclick = () => dialog.close();
dialog.addEventListener('close', () => {
  generation++; clearTimeout(timer); dialog.classList.add('hidden');
  invite = awaiting = null; startWhenReady = false; renaming = null;
  field('phoneQr').width = 1;
  document.querySelector('#libMenu summary')?.focus();
});
field('phoneNew').onclick = () => act(makeInvite);
field('phoneCopy').onclick = () => act(async () => {
  if (!invite || invite.until <= Date.now()) return;
  await navigator.clipboard.writeText(invite.url);
  toast('연결 링크를 복사했습니다. 휴대폰으로 보낼 때는 본인만 볼 수 있는 곳에 붙여 넣으세요.');
});
field('phoneAddressForm').onsubmit = event => {
  event.preventDefault();
  void act(() => start('external', field('phoneAddress').value.trim()));
};
field('phoneUseTeam').onclick = () => act(() => start('external', transport.team_origin));
field('phoneUseTail').onclick = () => act(() => start('tailscale'));
field('phonePortForm').onsubmit = event => { event.preventDefault(); void act(() => start('tailscale')); };
field('phoneDeny').onclick = () => { if (host?.pending) void decide(host.pending, false); };
field('phoneOff').onclick = () => act(async () => {
  const yes = await confirmDialog({ title: '휴대폰 연결 끄기', body: '휴대폰에서 이 라이브러리를 열 수 없게 되고, 등록한 기기를 모두 해제합니다. 다시 켜면 기기마다 새로 연결해야 합니다.', confirm: '연결 끄기', danger: true });
  if (!yes) return;
  host = await request('', 'PUT', { enabled: false, origin: host.origin });
  invite = awaiting = null; startWhenReady = false;
  toast('휴대폰 연결을 껐습니다.', { kind: 'success' });
});
field('phoneRetry').onclick = () => act(async () => {
  await refresh();
  if (host?.enabled && !host.running) host = await request('', 'PUT', { enabled: true, origin: host.origin });
  if (transport?.error && transport.mode === 'tailscale') await start('tailscale');
});
