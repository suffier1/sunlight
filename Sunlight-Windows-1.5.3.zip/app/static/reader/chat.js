// The 대화 tab: history, streamed answers (stoppable), attachments. Owns S.chatCtx, S.chatDrafts,
// S.streams (paper id → AbortController), S.chatLoading. An answer belongs to the paper it was asked
// on: it keeps streaming (and is saved by the server) while another paper is open.
import { api, toast, errorText, errorDetail, confirmDialog } from '../ui-kit.js';
import { S, $, live, isAbort } from './state.js';
import { mdFragment, linkPages, streamRenderer } from './markdown.js';
import { readEvents } from './sse.js';
import { requireEngine, isAuthExpired, openSettings, loadSettings } from '../settings.js';
import { showPanelRetry } from './panel.js';

const ta = $('#chatText'), log = $('#chatLog'), sendBtn = $('#chatSend');
const numPages = () => S.docs.original?.numPages || 0;

export async function loadChat(sess = S.sess) {
  if (!live(sess) || !S.paper) return;
  const seq = S.chatLoad = (S.chatLoad || 0) + 1;
  const current = () => live(sess) && seq === S.chatLoad;
  S.chatLoading = true;
  syncSendBtn();
  try {
    const h = await api(`/api/papers/${S.paper.id}/chat`, { signal: sess.signal, timeout: 12000 });
    if (!current()) return;
    log.replaceChildren();
    if (!h.length) log.innerHTML = '<div class="empty" id="chatEmpty">문장이나 그림을 선택하고 <b>질문</b>을 눌러 첨부할 수 있습니다.</div>';
    h.forEach(m => addMsg(m));
  } catch (e) {
    if (current()) showPanelRetry(log, e, () => loadChat(sess));
  } finally {
    if (current()) { S.chatLoading = false; syncSendBtn(); }
  }
}
function addMsg(m) {
  $('#chatEmpty')?.remove();
  const d = document.createElement('div');
  if (m.role === 'user') {
    d.className = 'msg user';
    const img = m.thumb || (m.image ? `/api/papers/${S.paper.id}/region/${encodeURIComponent(m.image)}` : null);
    if (img) { const i = document.createElement('img'); i.src = img; i.alt = '첨부한 영역'; d.append(i); }
    if (m.selection) { const c = document.createElement('div'); c.className = 'ctx'; c.textContent = m.selection; d.append(c); }
    d.append(m.content || '');
  } else {
    d.className = 'msg ai md';
    d.append(mdFragment(m.content));
    linkPages(d, numPages());
    if (m.stopped) {  // an answer stopped mid-way is saved as far as it got
      const tag = document.createElement('p'); tag.className = 'msg-stopped'; tag.textContent = '(중지됨)';
      d.append(tag);
    }
    if (m.content) addCopy(d, m.content);
  }
  log.appendChild(d);
  log.scrollTop = log.scrollHeight;
  return d;
}
// "복사" under an answer: the Markdown source with its LaTeX, ready to paste into notes
function addCopy(d, src) {
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'msg-copy'; b.textContent = '복사'; b.title = 'Markdown으로 복사 (수식은 LaTeX 그대로)';
  b.onclick = () => navigator.clipboard.writeText(src).then(() => toast('Markdown으로 복사했습니다.'), () => toast('답변을 선택하고 Ctrl+C를 누르세요.', { kind: 'error' }));
  d.append(b);
}
const chatBusy = () => S.streams.has(S.paper?.id);
export function syncSendBtn() {
  const streaming = chatBusy();
  sendBtn.classList.toggle('stop', streaming);
  sendBtn.setAttribute('aria-label', streaming ? '답변 중지' : '질문 보내기');
  sendBtn.title = streaming ? '답변 중지' : '보내기 (Enter)';
  sendBtn.disabled = !streaming && (!S.docs.original || !!S.paper?.storage_issue || S.chatLoading);
}
export function setChatCtx(ctx) {
  S.chatCtx = ctx;
  const el = $('#chatCtx');
  if (!ctx) { el.classList.add('hidden'); el.replaceChildren(); return; }
  el.replaceChildren();
  if (ctx.thumb) { const i = document.createElement('img'); i.src = ctx.thumb; i.alt = '첨부할 영역'; el.append(i); }
  else el.append(ctx.selection || '');
  const x = document.createElement('button');
  x.type = 'button'; x.className = 'x'; x.textContent = '×'; x.setAttribute('aria-label', '첨부 빼기');
  x.onclick = () => { setChatCtx(null); ta.focus(); };
  el.append(x);
  el.classList.remove('hidden');
}
export async function sendChat(text, ctx = S.chatCtx, onSend) {
  text = text.trim();
  if (!text) return;
  if (S.paper?.storage_issue) { toast('논문을 복구한 뒤 새 질문을 보낼 수 있습니다.'); return; }
  if (!S.docs.original || S.chatLoading) { toast('불러오는 중입니다. 잠시 후 보내세요.'); return; }
  if (chatBusy()) { toast('지금 답변이 끝나면 다음 질문을 보낼 수 있습니다.'); return; }
  const sess = S.sess;
  if (!await requireEngine(() => live(sess)) || chatBusy() || S.chatLoading) return;
  onSend?.();
  const pid = S.paper.id;
  setChatCtx(null);
  const controller = new AbortController();
  S.streams.set(pid, controller);
  syncSendBtn();
  const q = addMsg({ role: 'user', content: text, selection: ctx?.selection, thumb: ctx?.thumb });
  const out = addMsg({ role: 'assistant', content: '' });
  out.innerHTML = '<div class="typing" aria-label="답변 작성 중"><span></span><span></span><span></span></div>';
  out.setAttribute('aria-busy', 'true');
  let acc = '', pending = null, saved = false, renderer = null;
  // paint at most ~8×/s, re-rendering only the last block; follow the bottom only if the reader is there
  const paint = () => {
    clearTimeout(pending); pending = null;
    if (!out.isConnected) return;  // another paper is open; the answer still finishes and is saved
    const stick = log.scrollHeight - log.scrollTop - log.clientHeight < 60;
    renderer ??= streamRenderer(out, numPages());
    renderer.update(acc);
    if (stick) log.scrollTop = log.scrollHeight;
  };
  const final = () => { if (out.isConnected) { out.replaceChildren(mdFragment(acc)); linkPages(out, numPages()); } };
  try {
    const r = await api(`/api/papers/${pid}/chat`, {
      method: 'POST', raw: true, signal: AbortSignal.any([controller.signal, AbortSignal.timeout(360000)]),
      body: { message: text, selection: ctx?.selection || null, region: ctx?.region || null },
    });
    await readEvents(r, ev => {
      if (ev.done) { saved = true; return true; }
      if (typeof ev.d === 'string') { acc += ev.d; pending ??= setTimeout(paint, 120); }
    });
    // the server sends "done" only after saving; a stream that just stops was cut off
    if (!saved) throw new Error('연결이 끊겨 답변이 저장되지 않았습니다. 다시 시도하세요.');
    clearTimeout(pending);
    final();
    if (acc && out.isConnected) addCopy(out, acc);
  } catch (e) {
    clearTimeout(pending);
    if (acc) final(); else out.replaceChildren();  // keep what already arrived; the error goes underneath
    const stopped = isAbort(e) && controller.signal.aborted;
    out.classList.toggle('err', !acc && !stopped);
    const err = document.createElement('div');
    err.className = 'msg-err';
    err.setAttribute('role', stopped ? 'status' : 'alert');
    err.textContent = stopped ? `답변을 중지했습니다 (중지됨).${acc ? ' 받은 부분은 대화 기록에 남습니다.' : ''}` : errorText(e);
    const retry = document.createElement('button');
    retry.type = 'button'; retry.className = 'btn sm'; retry.textContent = '다시 시도';
    retry.onclick = () => { if (chatBusy()) return toast('지금 답변이 끝나면 다시 시도할 수 있습니다.'); q.remove(); out.remove(); sendChat(text, ctx); };
    err.append(' ', retry);
    if (isAuthExpired(e)) {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'btn sm'; b.textContent = '다시 연결'; b.onclick = () => openSettings();
      err.append(' ', b);
      loadSettings().catch(() => {});
    }
    const detail = !stopped && errorDetail(e);
    if (detail) {
      const more = document.createElement('details'); more.className = 'error-detail';
      more.innerHTML = '<summary>자세히</summary><code></code>'; more.querySelector('code').textContent = detail;
      err.append(more);
    }
    if (acc) addCopy(out, acc);
    out.append(err);
  } finally {
    out.removeAttribute('aria-busy');
    if (S.streams.get(pid) === controller) S.streams.delete(pid);
    syncSendBtn();
    // finished in the background: show the saved answer if its paper is open again
    if (saved && S.paper?.id === pid && !out.isConnected) loadChat().catch(() => {});
  }
}
ta.addEventListener('input', () => { ta.style.height = 'auto'; ta.style.height = `${Math.min(ta.scrollHeight, 160)}px`; });
ta.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submitChat(); }
});
// the box is emptied only when the message is actually sent (not while an answer is still coming)
function submitChat() {
  if (chatBusy() || !ta.value.trim()) return;
  const v = ta.value;
  sendChat(v, S.chatCtx, () => { if (ta.value === v) { ta.value = ''; ta.style.height = 'auto'; } });
}
sendBtn.onclick = () => {
  if (chatBusy()) { S.streams.get(S.paper.id)?.abort(new DOMException('중지', 'AbortError')); return; }
  submitChat();
};
$('#chatClear').onclick = async () => {
  if (!S.paper || S.chatLoading) return;
  // the server appends the running answer when it finishes, so clearing now would not stick
  if (chatBusy()) { toast('답변이 끝나면 대화를 지울 수 있습니다.'); return; }
  if (!await confirmDialog({ title: '대화 기록을 지울까요?', body: '이 논문의 질문과 답변이 모두 삭제되며 되돌릴 수 없습니다.', confirm: '대화 지우기', danger: true })) return;
  const sess = S.sess;
  try { await api(`/api/papers/${S.paper.id}/chat`, { method: 'DELETE', signal: sess.signal }); }
  catch (e) { if (live(sess)) toast(`대화를 지우지 못했습니다. ${errorText(e)}`, { kind: 'error' }); return; }
  if (live(sess)) loadChat(sess);
};
// per-paper draft: kept while the reader moves between papers
export function stashChatDraft() {
  if (!S.paper) return;
  if (ta.value || S.chatCtx) S.chatDrafts.set(S.paper.id, { text: ta.value, ctx: S.chatCtx });
  else S.chatDrafts.delete(S.paper.id);
}
export function resetChat() {
  log.replaceChildren();
  setChatCtx(null);
  ta.value = ''; ta.style.height = 'auto';
}
export function restoreChatDraft(id) {
  const draft = S.chatDrafts.get(id);
  if (draft) { ta.value = draft.text; setChatCtx(draft.ctx); }
}
