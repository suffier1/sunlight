// The explanation card (streamed, resizable, pinned when its source scrolls away) and the quick
// translation card. Neither is closed by scrolling or by clicking elsewhere: only × / Esc / closing the paper.
import { api, toast, errorText, errorDetail } from '../ui-kit.js';
import { S, $, live, isAbort, modalOpen } from './state.js';
import { slotOf, rectOf } from './layout.js';
import { requireEngine, engineName, isAuthExpired, openSettings } from '../settings.js';
import { mdFragment, linkPages, streamRenderer } from './markdown.js';
import { readEvents } from './sse.js';
import { hidePops, resetHover, showSelPop } from './selection.js';
import { attachNote, focusNote } from './notes.js';
import { loadChat } from './chat.js';

let explanation = null;
export const explanationOpen = () => !!explanation;
const EXPLAIN_SIZE_KEY = 'sl.explainSize';
function savedExplanationSize() {
  try {
    const size = JSON.parse(localStorage.getItem(EXPLAIN_SIZE_KEY));
    if (size && Number.isFinite(size.width) && Number.isFinite(size.height))
      return { width: Math.max(300, Math.min(960, size.width)), height: Math.max(280, Math.min(900, size.height)) };
  } catch { /* preferences may be unavailable; reading still works */ }
  return null;
}
function resizeExplanation(x, width, height, persist = true) {
  if (explanation !== x) return;
  const maxW = Math.max(1, Math.min(960, innerWidth - 24));
  const maxH = Math.max(1, Math.min(900, innerHeight - 24));
  x.size = { width: Math.round(Math.max(Math.min(300, maxW), Math.min(maxW, width))),
    height: Math.round(Math.max(Math.min(280, maxH), Math.min(maxH, height))) };
  positionExplanation();
  if (persist) {
    try { localStorage.setItem(EXPLAIN_SIZE_KEY, JSON.stringify(x.size)); } catch { /* session-only sizing */ }
    $('.explain-size-status', x.card).textContent = `설명창 ${Math.round(x.card.offsetWidth)} × ${Math.round(x.card.offsetHeight)}`;
  }
}
function resetExplanationSize(x) {
  if (explanation !== x) return;
  x.size = null;
  try { localStorage.removeItem(EXPLAIN_SIZE_KEY); } catch { /* session-only sizing */ }
  positionExplanation();
  $('.explain-size-status', x.card).textContent = '설명창을 기본 크기로 되돌렸습니다';
}
function bindExplanationSizing(x) {
  const adjust = amount => { const r = x.card.getBoundingClientRect(); resizeExplanation(x, r.width + amount, r.height + amount); };
  $('.explain-smaller', x.card).onclick = () => adjust(-40);
  $('.explain-larger', x.card).onclick = () => adjust(40);
  $('.explain-size-reset', x.card).onclick = () => resetExplanationSize(x);
  const handle = $('.explain-resize', x.card);
  handle.onkeydown = event => {
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    const steps = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    if (event.key === 'Home') { event.preventDefault(); resetExplanationSize(x); }
    else if (steps[event.key]) {
      event.preventDefault();
      const r = x.card.getBoundingClientRect(), [dw, dh] = steps[event.key], step = event.shiftKey ? 40 : 10;
      resizeExplanation(x, r.width + dw * step, r.height + dh * step);
    }
  };
  handle.onpointerdown = event => {
    if (event.button !== 0) return;
    event.preventDefault(); handle.focus({ preventScroll: true });
    const r = x.card.getBoundingClientRect();
    x.drag = { id: event.pointerId, x: event.clientX, y: event.clientY, left: r.left, top: r.top, width: r.width, height: r.height };
    x.card.classList.add('is-resizing');
    handle.setPointerCapture(event.pointerId);
  };
  handle.onpointermove = event => {
    const d = x.drag;
    if (!d || d.id !== event.pointerId) return;
    resizeExplanation(x, Math.min(d.width + event.clientX - d.x, innerWidth - 12 - d.left),
      Math.min(d.height + event.clientY - d.y, innerHeight - 12 - d.top), false);
  };
  const finish = event => {
    if (!x.drag || x.drag.id !== event.pointerId) return;
    const changed = x.size;
    x.drag = null; x.card.classList.remove('is-resizing');
    if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
    if (changed) resizeExplanation(x, changed.width, changed.height);
  };
  handle.onpointerup = handle.onpointercancel = handle.onlostpointercapture = finish;
}
function anchorRect(source) {
  const slot = S.slots.find(s => s.i === source.anchor.page && s.docKind === source.kind);
  if (!slot?.el.isConnected) return null;
  const p = rectOf(slot), b = source.anchor.bbox;
  return { left: p.left + b[0] * S.scale, right: p.left + b[2] * S.scale, top: p.top + b[1] * S.scale, bottom: p.top + b[3] * S.scale };
}
export function positionExplanation() {
  const x = explanation;
  if (!x) return;
  if (S.paper?.id !== x.pid) { closeExplanation(false); return; }
  const r = anchorRect(x.source), v = $('#viewer').getBoundingClientRect();
  const away = !r || r.bottom < Math.max(0, v.top) || r.top > Math.min(innerHeight, v.bottom) || r.right < v.left || r.left > v.right;
  // The source scrolled away: keep the card where it is (pinned) and say where it came from.
  x.card.classList.toggle('detached', away);
  $('.explain-back', x.card).hidden = !away;
  const edge = 12, gap = 12, w = Math.max(1, Math.min(x.size?.width || 390, innerWidth - edge * 2));
  const maxH = Math.max(1, Math.min(x.size?.height || 480, innerHeight - edge * 2));
  x.card.style.width = `${w}px`;
  x.card.style.height = x.size ? `${maxH}px` : '';
  x.card.style.minHeight = `${Math.min(280, maxH)}px`;
  x.card.style.maxHeight = `${maxH}px`;
  const clamp = (left, top) => {
    x.card.style.left = `${Math.max(edge, Math.min(left, innerWidth - w - edge))}px`;
    x.card.style.top = `${Math.max(edge, Math.min(top, innerHeight - x.card.offsetHeight - edge))}px`;
  };
  if (x.drag) { clamp(x.drag.left, x.drag.top); return; }
  if (away) {
    if (!x.pinned) x.pinned = { left: x.card.offsetLeft || v.right - w - edge, top: x.card.offsetTop || v.top + edge };
    clamp(x.pinned.left, x.pinned.top);
    return;
  }
  x.pinned = null;
  const h = Math.min(x.card.offsetHeight, maxH);
  let left, top;
  if (r.right + gap + w <= innerWidth - edge) { left = r.right + gap; top = r.top; }
  else if (r.left - gap - w >= edge) { left = r.left - gap - w; top = r.top; }
  else {
    left = r.left;
    const below = innerHeight - edge - r.bottom - gap, above = r.top - edge - gap;
    const useBelow = below >= h || (above < h && below >= above);
    const room = useBelow ? below : above;
    const limit = !x.size && room >= 280 ? Math.min(maxH, room) : maxH;
    x.card.style.maxHeight = `${limit}px`;
    top = useBelow ? r.bottom + gap : r.top - gap - Math.min(h, limit);
  }
  clamp(left, top);
}
export function closeExplanation(restoreFocus = true) {
  const x = explanation;
  if (!x) return;
  explanation = null;
  x.controller?.abort(new DOMException('설명 닫기', 'AbortError'));
  clearTimeout(x.paintTimer);
  x.resize?.disconnect();
  const hadFocus = x.card.contains(document.activeElement);
  x.card.remove();
  if (restoreFocus && hadFocus && S.paper?.id === x.pid) {
    showSelPop();
    const target = x.returnFocus?.isConnected && x.returnFocus.getClientRects().length ? x.returnFocus : $('#viewer');
    target.focus({ preventScroll: true });
  }
}
// source: {anchor, kind, label, isRegion, thumb, sel, prepare: async () => request body}
export function showExplanation(source) {
  closeExplanation(false);
  hidePops(); resetHover();
  closeQuick(false);
  const card = document.createElement('section');
  card.className = 'explain-pop'; card.tabIndex = -1;
  card.setAttribute('role', 'dialog'); card.setAttribute('aria-modal', 'false');
  card.setAttribute('aria-labelledby', 'explainTitle');
  card.innerHTML = `<header class="explain-head"><h2 id="explainTitle"></h2><button type="button" class="explain-back link" hidden>원래 위치로</button><button type="button" class="explain-close" aria-label="설명 닫기" title="닫기 (Esc)">×</button></header>
    <div class="explain-source"></div><p class="explain-scope"></p><div class="explain-body md" tabindex="0" aria-label="설명 내용"></div>
    <footer class="explain-foot"><span class="explain-status" role="status" aria-live="polite"></span>
      <button type="button" class="btn sm explain-stop hidden">중지</button><button type="button" class="btn sm explain-retry hidden">다시 시도</button>
      <button type="button" class="btn sm explain-note" disabled>메모에 추가</button><button type="button" class="btn sm explain-save" disabled>대화에 저장</button><button type="button" class="btn sm explain-copy" disabled>복사</button>
      <div class="explain-size-tools" role="group" aria-label="설명창 크기"><button type="button" class="explain-smaller" aria-label="설명창 축소" title="설명창 축소">−</button><button type="button" class="explain-larger" aria-label="설명창 확대" title="설명창 확대">+</button><button type="button" class="explain-size-reset" aria-label="설명창 기본 크기" title="기본 크기">↺</button><button type="button" class="explain-resize" aria-label="설명창 크기 조절: 방향키, Shift로 크게 조절, Home으로 기본 크기" title="드래그 또는 방향키로 크기 조절 · Home: 기본 크기">↘</button></div><span class="explain-size-status" role="status" aria-live="polite"></span></footer>`;
  $('#explainTitle', card).textContent = `${source.label} 설명 · ${source.anchor.page + 1}쪽`;
  $('.explain-scope', card).textContent = `해당 쪽의 본문과 ${source.isRegion ? '영역 이미지를' : '선택한 글을'} ${engineName()}에 보냅니다.`;
  const origin = $('.explain-source', card);
  origin.textContent = source.kind === 'translated' ? '번역본에서 선택' : '원문에서 선택';
  if (source.thumb) {
    const img = document.createElement('img'); img.src = source.thumb; img.alt = '선택 영역 미리보기'; origin.prepend(img);
  }
  const x = explanation = { card, source, sess: S.sess, pid: S.paper.id, returnFocus: document.activeElement, text: '', size: savedExplanationSize() };
  bindExplanationSizing(x);
  $('.explain-close', card).onclick = () => closeExplanation();
  $('.explain-retry', card).onclick = () => runExplanation(x);
  $('.explain-stop', card).onclick = () => x.controller?.abort(new DOMException('중지', 'AbortError'));
  $('.explain-back', card).onclick = () => {
    const slot = slotOf(source.anchor.page, source.kind);
    if (!slot) return;
    const v = $('#viewer');
    v.scrollTop += slot.el.getBoundingClientRect().top + source.anchor.bbox[1] * S.scale - v.getBoundingClientRect().top - 80;
  };
  $('.explain-copy', card).onclick = async () => {
    try { await navigator.clipboard.writeText(x.text); if (explanation === x) setStatus(x, '복사했습니다.'); }
    catch { if (explanation === x) setStatus(x, '내용을 선택하고 Ctrl+C를 누르세요.'); }
  };
  $('.explain-note', card).onclick = async e => {
    const b = e.currentTarget;
    if (!source.sel) return;
    b.disabled = true;
    try {
      const h = await attachNote(source.sel, `설명 (${engineName()})${x.partial ? ' (중지됨)' : ''}:\n${x.text.trim()}`);
      if (explanation === x) { setStatus(x, '메모에 추가했습니다.'); b.textContent = '메모 보기'; b.onclick = () => focusNote(h.id); }
    } catch (err) { if (explanation === x) setStatus(x, `메모에 추가하지 못했습니다. ${errorText(err)}`); }
    finally { b.disabled = false; }
  };
  $('.explain-save', card).onclick = e => saveToChat(x, e.currentTarget);
  document.body.append(card);
  x.resize = new ResizeObserver(() => positionExplanation()); x.resize.observe(card);
  positionExplanation();
  if (explanation !== x) return;
  card.focus({ preventScroll: true });
  runExplanation(x);
}
const setStatus = (x, text) => { $('.explain-status', x.card).textContent = text; };
let chatAppendMissing = false;
async function saveToChat(x, button) {
  button.disabled = true;
  const question = `[${x.source.label} 설명 · ${x.source.anchor.page + 1}쪽]`;
  try {
    const selection = x.request?.selection?.split('\n\n[원문]')[0] || null;
    await api(`/api/papers/${x.pid}/chat/append`, {
      method: 'POST', body: { messages: [{ role: 'user', content: question, selection }, { role: 'assistant', content: x.text, ...(x.partial ? { stopped: true } : {}) }] },
    });
    if (explanation === x) { setStatus(x, '대화에 저장했습니다.'); button.textContent = '저장됨'; }
    if (S.paper?.id === x.pid) loadChat();
  } catch (err) {
    if (err.status === 404 || err.status === 405) {
      chatAppendMissing = true; button.hidden = true;
      toast('이 버전의 서버에서는 설명을 대화에 저장할 수 없습니다.');
    } else { button.disabled = false; if (explanation === x) setStatus(x, `대화에 저장하지 못했습니다. ${errorText(err)}`); }
  }
}
async function runExplanation(x) {
  if (explanation !== x) return;
  x.controller?.abort(); clearTimeout(x.paintTimer);
  const controller = x.controller = new AbortController();
  const signal = AbortSignal.any([controller.signal, x.sess.signal, AbortSignal.timeout(300000)]);
  const current = () => explanation === x && x.controller === controller && live(x.sess);
  const body = $('.explain-body', x.card), retry = $('.explain-retry', x.card), stop = $('.explain-stop', x.card);
  const actions = ['.explain-copy', '.explain-note', '.explain-save'].map(s => $(s, x.card));
  let complete = false;
  x.text = ''; x.partial = false; actions.forEach(b => { b.disabled = true; }); retry.classList.add('hidden');
  $('.explain-save', x.card).hidden = chatAppendMissing;
  $('.explain-note', x.card).hidden = !x.source.sel;
  body.innerHTML = '<div class="explain-loading" aria-hidden="true"><span class="spinner"></span></div>';
  body.setAttribute('aria-busy', 'true'); setStatus(x, '설명 준비 중');
  const renderer = { r: null };
  const paint = () => {
    clearTimeout(x.paintTimer); x.paintTimer = null;
    if (!current()) return;
    if (!renderer.r) renderer.r = streamRenderer(body, S.docs.original?.numPages || 0);
    const top = body.scrollTop;
    renderer.r.update(x.text); body.scrollTop = top;
    positionExplanation();
  };
  try {
    if (!await requireEngine(current)) {
      if (current()) throw new Error('AI를 연결한 뒤 다시 시도하세요.');
      return;
    }
    stop.classList.remove('hidden');
    const request = await Promise.race([x.source.prepare(), new Promise((_, reject) => signal.addEventListener('abort', () => reject(signal.reason), { once: true }))]);
    if (!current()) return;
    if (request.selection) {
      request.page = x.source.anchor.page;
      const snippet = request.selection.split('\n\n[원문]')[0].replace(/\s+/g, ' ').trim();
      $('.explain-source', x.card).textContent = `${x.source.kind === 'translated' ? '번역본' : '원문'} · ${snippet.slice(0, 180)}${snippet.length > 180 ? '…' : ''}`;
    }
    x.request = request;
    const response = await api(`/api/papers/${x.pid}/explain`, { method: 'POST', body: request, signal, raw: true });
    await readEvents(response, event => {
      if (!current()) return true;
      if (typeof event.d === 'string') { x.text += event.d; setStatus(x, '설명 작성 중'); x.paintTimer ??= setTimeout(paint, 100); }
      if (event.done) { complete = true; return true; }
    });
    if (!current()) return;
    if (!complete) throw new Error('연결이 끊겨 설명을 끝내지 못했습니다. 다시 시도하세요.');
    if (!x.text.trim()) throw new Error('설명이 비어 있습니다. 다시 시도하세요.');
    clearTimeout(x.paintTimer); x.paintTimer = null;
    body.replaceChildren(mdFragment(x.text)); linkPages(body, S.docs.original?.numPages || 0);
    actions.forEach(b => { b.disabled = false; });
    setStatus(x, '완료');
  } catch (error) {
    if (explanation !== x || x.controller !== controller) return;
    clearTimeout(x.paintTimer); x.paintTimer = null;
    if (x.text) { body.replaceChildren(mdFragment(x.text)); } else body.replaceChildren();
    const stopped = isAbort(error) && controller.signal.aborted;
    const failure = document.createElement('p'); failure.className = 'explain-error'; failure.setAttribute('role', 'alert');
    failure.textContent = stopped ? '설명을 중지했습니다.' : errorText(signal.reason?.name === 'TimeoutError' ? signal.reason : error);
    body.append(failure);
    const detail = errorDetail(error);
    if (detail && !stopped) {
      const more = document.createElement('details'); more.className = 'error-detail';
      more.innerHTML = '<summary>자세히</summary><code></code>'; more.querySelector('code').textContent = detail; body.append(more);
    }
    if (isAuthExpired(error)) {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'btn sm'; b.textContent = '다시 연결'; b.onclick = () => openSettings();
      body.append(b);
    }
    // what already arrived stays usable: copy, 메모에 추가, 대화에 저장 (marked "(중지됨)")
    x.partial = !!x.text.trim();
    setStatus(x, !x.partial ? '' : stopped ? '중지됨 · 받은 부분까지 남길 수 있습니다.' : '답변이 중간에 끊겼습니다 (중지됨).');
    actions.forEach(b => { b.disabled = !x.partial; });
    retry.classList.remove('hidden');
  } finally {
    if (explanation === x && x.controller === controller) {
      stop.classList.add('hidden');
      body.removeAttribute('aria-busy'); positionExplanation();
    }
  }
}
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape' || !explanation || modalOpen()) return;
  const t = document.activeElement;
  if (!(explanation.card.contains(t) || t === document.body || $('#viewer').contains(t))) return;
  if (!explanation.card.contains(t) && (S.sel || !$('#quickCard').hidden)) return;  // Esc first clears the selection
  e.preventDefault(); e.stopImmediatePropagation(); closeExplanation();
}, true);
window.addEventListener('resize', () => { positionExplanation(); positionQuick(); });

/* ---------------------------------------------------------------- quick translation card */
const quick = $('#quickCard');
let quickRequest = null, quickAnchor = null, quickReturn = null;
export function closeQuick(restore = true) {
  quickRequest?.abort(new DOMException('닫기', 'AbortError'));
  quickRequest = null;
  quickAnchor = null;
  if (quick.hidden) return;
  const hadFocus = quick.contains(document.activeElement);
  quick.hidden = true;
  if (restore && hadFocus) (quickReturn?.isConnected ? quickReturn : $('#viewer')).focus({ preventScroll: true });
}
function positionQuick() {
  if (!quickAnchor) return;
  const { left, top, bottom } = quickAnchor;
  const { offsetWidth: width, offsetHeight: height } = quick;
  const below = bottom + 10, above = top - 10 - height;
  const y = below + height > innerHeight - 8 && above >= 8 ? above : below;
  quick.style.left = `${Math.max(8, Math.min(left, innerWidth - width - 8))}px`;
  quick.style.top = `${Math.max(8, Math.min(y, innerHeight - height - 8))}px`;
}
export async function showQuick(label, body, staticText) {
  closeQuick(false);
  quickReturn = document.activeElement;
  const slot = S.sel?.anchor && slotOf(S.sel.anchor.page, S.sel.kind);
  let left = 200, top = 200, bottom = 200;
  if (slot) {
    const pr = slot.el.getBoundingClientRect(), b = S.sel.anchor.bbox;
    left = pr.left + b[0] * S.scale; top = pr.top + b[1] * S.scale; bottom = pr.top + b[3] * S.scale;
  }
  const out = $('#quickBody');
  $('#quickLabel').textContent = label;
  out.innerHTML = '<span class="spinner" aria-hidden="true"></span><span class="sr-only">번역 중</span>';
  out.setAttribute('aria-busy', 'true');
  quick.hidden = false;
  quickAnchor = { left, top, bottom };
  positionQuick();
  quick.focus({ preventScroll: true });
  if (staticText != null) {
    const d = document.createElement('div'); d.className = 'orig'; d.textContent = staticText;
    out.replaceChildren(d); out.removeAttribute('aria-busy');
    positionQuick();
    return;
  }
  const sess = S.sess, pid = S.paper.id;
  const request = quickRequest = new AbortController();
  const current = () => live(sess) && quickRequest === request;
  if (!await requireEngine(current)) { if (current()) closeQuick(); return; }
  try {
    const res = await api(`/api/papers/${pid}/quick`, { method: 'POST', body, signal: AbortSignal.any([request.signal, sess.signal]), timeout: 310000 });
    if (!current()) return;
    out.replaceChildren(mdFragment(res.text));
    linkPages(out, S.docs.original?.numPages || 0);
  } catch (e) {
    if (!current()) return;
    out.textContent = errorText(e);
    if (isAuthExpired(e)) { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn sm'; b.textContent = '다시 연결'; b.onclick = () => openSettings(); out.append(' ', b); }
  } finally {
    if (current()) { out.removeAttribute('aria-busy'); positionQuick(); }
  }
}
$('#quickClose').onclick = () => closeQuick();
quick.addEventListener('keydown', e => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeQuick(); } });
