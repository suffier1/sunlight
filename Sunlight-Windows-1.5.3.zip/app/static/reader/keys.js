// Keyboard in the reader.
//   One-key shortcuts (T 번역, E 설명, Q 질문, N 메모, R 영역 선택, + / − 확대·축소) act only while focus is
//   in the paper or its selection toolbar, never behind a dialog, and can be turned off in 설정 → 고급 (WCAG 2.1.4).
//   Ctrl + / Ctrl − / Ctrl 0 zoom the paper anywhere in the reader (the host disables WebView zoom).
//   Esc leaves 영역 선택 wherever focus is (except text fields and dialogs).
//   Alt+L goes to the links on the page in view (reader/links.js: arrows move, Enter follows, Esc back).
import { S, $, readerShown, modalOpen } from './state.js';
import { shortcutsEnabled } from '../settings.js';
import { selAction, toggleRegion, clearSelection } from './selection.js';
import { zoomStep, setZoomMode } from './layout.js';
import { goBack, focusFirstLink } from './links.js';
import { toast } from '../ui-kit.js';

const inPaper = t => !!t?.closest?.('#viewer, #selPop, #regionPop');
const typing = t => !!t?.matches?.('input, textarea, select, [contenteditable="true"]');
document.addEventListener('keydown', e => {
  if (e.defaultPrevented || e.isComposing || !readerShown() || !S.docs.original || modalOpen()) return;
  const t = document.activeElement;
  // Ctrl/⌘ + − 0: the paper's zoom, not the app's
  if ((e.ctrlKey || e.metaKey) && !e.altKey) {
    if (e.key === '+' || e.key === '=' || e.code === 'NumpadAdd') { e.preventDefault(); zoomStep(1); }
    else if (e.key === '-' || e.code === 'NumpadSubtract') { e.preventDefault(); zoomStep(-1); }
    else if (e.key === '0' || e.code === 'Numpad0') { e.preventDefault(); setZoomMode('width'); }
    return;
  }
  if (e.altKey && e.key === 'ArrowLeft' && !typing(t) && goBack()) { e.preventDefault(); return; }
  // Alt+L: the links on the page in view (always available, also with one-key shortcuts off)
  if (e.altKey && e.code === 'KeyL' && !typing(t)) {
    e.preventDefault();
    if (!focusFirstLink()) toast('지금 보이는 쪽에는 링크가 없습니다.');
    return;
  }
  if (e.key === 'Escape' && S.region && !typing(t)) {
    e.preventDefault();
    clearSelection();
    if (!inPaper(t)) $('#regionBtn').focus({ preventScroll: true });
    return;
  }
  if (!inPaper(t) || typing(t)) return;
  if (e.key === 'Escape') {
    if (S.sel || !$('#selPop').classList.contains('hidden')) { e.preventDefault(); clearSelection(); }
    return;
  }
  if (e.altKey || !shortcutsEnabled()) return;
  const k = e.code;  // physical key, so it works with the Korean IME on (ㅅ = T, ㄷ = E)
  if (!$('#selPop').classList.contains('hidden')) {
    if (k === 'KeyT') { e.preventDefault(); selAction('translate'); return; }
    if (k === 'KeyE') { e.preventDefault(); selAction('explain'); return; }
    if (k === 'KeyQ') { e.preventDefault(); selAction('ask'); return; }
    if (k === 'KeyN') { e.preventDefault(); selAction('memo'); return; }
  }
  if (e.key === '+' || e.key === '=' || k === 'NumpadAdd') { e.preventDefault(); zoomStep(1); }
  else if (e.key === '-' || k === 'NumpadSubtract') { e.preventDefault(); zoomStep(-1); }
  else if (k === 'KeyR') { e.preventDefault(); toggleRegion(); }
});
