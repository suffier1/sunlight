// Page layout and rendering: slots (one per page per column), zoom, canvas rendering with a pixel cap,
// lazy render / eviction. Owns S.scale, S.dpr, S.slots, S.zoom, S.rectEpoch.
import * as pdfjsLib from '../vendor/pdfjs/pdf.min.mjs?v=2';
import { S, $, $$, readerShown } from './state.js';
import { drawHighlights } from './notes.js';
import { redrawSelection, hidePops, hideChip, resetHover } from './selection.js';
import { drawSearchHits } from './search.js';
import { positionExplanation } from './explain.js';
import { drawLinks } from './links.js';
import { currentPos, scrollToPos, updatePageIndicator } from './navigation.js';

export const PT = 96 / 72;                 // CSS px per PDF point at 100 %
const MAX_CANVAS_PIXELS = 2 ** 24;         // as pdf.js: beyond this the canvas is CSS-upscaled
const ZOOM_STEPS = [25, 33, 50, 67, 75, 80, 90, 100, 110, 125, 150, 175, 200, 250, 300, 400];
const MIN_SCALE = 0.25 * PT, MAX_SCALE = 4 * PT;
const viewer = $('#viewer');

export const dpr = () => Math.min(window.devicePixelRatio || 1, 2);
export const pageSize = i => S.pageSizes?.[i] || { w: 612, h: 792 };
export const toNorm = (i, b) => { const { w, h } = pageSize(i); return [b[0] / w, b[1] / h, (b[2] - b[0]) / w, (b[3] - b[1]) / h]; };
export const intersects = (a, b) => a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1];
export function slotOf(i, kind) { return S.slots.find(s => s.i === i && s.docKind === kind) || S.slots.find(s => s.i === i); }
export const columnStride = () => (S.slots[1]?.i === 0 ? 2 : 1);

// Page rectangles are read at most once per scroll/resize/layout change (pointer handlers use this).
export function rectOf(slot) {
  if (slot.rectEpoch !== S.rectEpoch) { slot.rect = slot.el.getBoundingClientRect(); slot.rectEpoch = S.rectEpoch; }
  return slot.rect;
}
export const invalidateRects = () => { S.rectEpoch++; };

export function clearSelBoxes(cls = '') { $$(`.sel-box${cls}`).forEach(b => b.remove()); }
export function drawSelBox(slot, bbox, cls) {
  const d = document.createElement('div');
  d.className = `sel-box ${cls}`;
  Object.assign(d.style, {
    left: `${bbox[0] * S.scale - 3}px`, top: `${bbox[1] * S.scale - 3}px`,
    width: `${(bbox[2] - bbox[0]) * S.scale + 6}px`, height: `${(bbox[3] - bbox[1]) * S.scale + 6}px`,
  });
  $('.blk-layer', slot.el)?.appendChild(d);
  return d;
}

/* ---------------------------------------------------------------- page sizes */
// Every page's size from pdf.js before the first layout, so the scroll height is right at once.
export async function readPageSizes(doc, signal) {
  const sizes = new Array(doc.numPages);
  const one = async i => {
    const page = await doc.getPage(i + 1);
    const vp = page.getViewport({ scale: 1 });
    sizes[i] = { w: vp.width, h: vp.height };
  };
  // A few at a time: getPage is cheap but each one is a worker round trip.
  for (let i = 0; i < doc.numPages; i += 16) {
    if (signal?.aborted) return null;
    await Promise.all(Array.from({ length: Math.min(16, doc.numPages - i) }, (_, k) => one(i + k)));
  }
  return sizes;
}
let sizedPages, maxPageWidth = 612, maxPageHeight = 792;
function pageExtent() {
  if (sizedPages !== S.pageSizes) {
    sizedPages = S.pageSizes;
    maxPageWidth = sizedPages?.reduce((w, p) => Math.max(w, p?.w || 0), 0) || 612;
    maxPageHeight = sizedPages?.reduce((h, p) => Math.max(h, p?.h || 0), 0) || 792;
  }
}

/* ---------------------------------------------------------------- zoom */
function fitScale(mode) {
  pageExtent();
  const cols = S.mode === 'side' ? 2 : 1;
  const width = Math.max(0.05, (viewer.clientWidth - 40 - 14 * (cols - 1) - 4) / (cols * maxPageWidth));
  if (mode === 'page') return Math.max(0.05, Math.min(width, (viewer.clientHeight - 40) / maxPageHeight));
  return width;
}
function targetScale() {
  const z = S.zoom;
  return z.mode === 'custom' ? Math.min(MAX_SCALE, Math.max(MIN_SCALE, z.scale)) : fitScale(z.mode);
}
const percentOf = scale => Math.round(scale / PT * 100);
function saveZoom() {
  try { localStorage.setItem('sl.zoom2', JSON.stringify(S.zoom)); } catch { /* session only */ }
}
export function renderZoomState() {
  const pct = `${percentOf(S.scale)}%`;
  $$('[data-zoom-value]').forEach(o => { o.textContent = pct; });
  $$('[data-zoom-fit]').forEach(b => b.setAttribute('aria-pressed', String(S.zoom.mode === b.dataset.zoomFit)));
}
export function setZoomMode(mode, scale, anchor) {
  S.zoom = mode === 'custom' ? { mode, scale: Math.min(MAX_SCALE, Math.max(MIN_SCALE, scale)) } : { mode, scale: 1 };
  saveZoom();
  resizePages(anchor);
}
export function zoomStep(dir, anchor) {
  const now = percentOf(S.scale);
  const next = dir > 0 ? ZOOM_STEPS.find(p => p > now) ?? ZOOM_STEPS.at(-1) : [...ZOOM_STEPS].reverse().find(p => p < now) ?? ZOOM_STEPS[0];
  setZoomMode('custom', next / 100 * PT, anchor);
}
export function zoomBy(factor, anchor) { setZoomMode('custom', S.scale * factor, anchor); }

// Ctrl+wheel over the paper zooms the paper (not the whole app); the point under the pointer stays put.
let wheelFactor = 1, wheelAnchor = null, wheelFrame = 0;
viewer.addEventListener('wheel', e => {
  if (!e.ctrlKey || !S.slots.length) return;
  e.preventDefault();
  wheelFactor *= Math.exp(-Math.max(-60, Math.min(60, e.deltaY)) * 0.004);
  wheelAnchor = { x: e.clientX, y: e.clientY };
  wheelFrame ||= requestAnimationFrame(() => {
    wheelFrame = 0;
    const f = wheelFactor; wheelFactor = 1;
    if (Math.abs(f - 1) > 0.002) zoomBy(f, wheelAnchor);
  });
}, { passive: false });

/* ---------------------------------------------------------------- slots */
function sizeSlot(slot) {
  const { w, h } = pageSize(slot.i);
  slot.el.style.width = `${Math.max(1, Math.floor(w * S.scale))}px`;
  slot.el.style.height = `${Math.max(1, Math.floor(h * S.scale))}px`;
  slot.el.style.setProperty('--scale-factor', S.scale);
}
// Rendering margins shrink as pages grow so the number of live canvases stays small at high zoom.
function makeObservers() {
  S.observer?.disconnect(); S.evictor?.disconnect();
  const z = Math.max(1, S.scale / (1.4 * PT));
  const near = Math.round(Math.max(300, 900 / z)), far = Math.round(Math.max(1000, 3000 / z));
  S.observer = new IntersectionObserver(entries => {
    for (const e of entries) if (e.isIntersecting) renderSlot(e.target._slot);
  }, { root: viewer, rootMargin: `${near}px 0px` });
  // pages far off screen give their canvas back
  S.evictor = new IntersectionObserver(entries => {
    for (const e of entries) if (!e.isIntersecting) releaseSlot(e.target._slot);
  }, { root: viewer, rootMargin: `${far}px 0px` });
  for (const slot of S.slots) { S.observer.observe(slot.el); S.evictor.observe(slot.el); }
}

export function buildPages() {
  if (!S.docs.original || !readerShown()) return;
  const pos = S.restorePos || currentPos();
  S.restorePos = null;
  S.scale = targetScale();
  S.dpr = dpr();
  S.slots.forEach(releaseSlot);
  resetHover(); hideChip(); clearSelBoxes();
  S.sel = null;
  const box = $('#pages');
  box.replaceChildren();
  S.slots = [];
  const n = S.docs.original.numPages;
  const hasTr = !!S.docs.translated;
  const kinds = S.mode === 'side' ? ['original', 'translated'] : [S.mode];
  const frag = document.createDocumentFragment();
  for (let i = 0; i < n; i++) {
    const row = document.createElement('div');
    row.className = 'row';
    for (const kind of kinds) {
      const useKind = kind === 'translated' && !hasTr ? 'original' : kind;
      const el = document.createElement('div');
      el.className = 'page';
      el.dataset.page = i;
      el.dataset.kind = kind;
      el.setAttribute('role', 'group');
      el.setAttribute('aria-label', `${i + 1}쪽${kind === 'translated' ? ' 번역' : ''}`);
      const slot = { el, i, kind, docKind: useKind, rendered: false, run: 0 };
      sizeSlot(slot);
      el._slot = slot;
      el.innerHTML = `<div class="hl-layer"></div><div class="blk-layer"></div>` +
        (kinds.length === 1 || kind === 'original' ? `<span class="pno" aria-hidden="true">${i + 1}</span>` : '');
      if (kind === 'translated' && !hasTr) el.insertAdjacentHTML('beforeend', '<span class="tag">번역 대기</span>');
      if (kind === 'translated' && hasTr) addPageAction(slot);
      row.appendChild(el);
      S.slots.push(slot);
    }
    frag.appendChild(row);
  }
  box.appendChild(frag);
  invalidateRects();
  makeObservers();
  renderZoomState();
  const slots = S.slots;
  requestAnimationFrame(() => { if (S.slots === slots) { scrollToPos(pos); updatePageIndicator(); } });
}
export function addPageAction(slot) {
  if (!$('.page-act', slot.el)) slot.el.insertAdjacentHTML('beforeend', `<div class="page-act"><button type="button" data-retr="${slot.i}">이 페이지 다시 번역</button></div>`);
}

// The translated PDF was rebuilt: re-render only the translated column, in place.
export function refreshTranslatedSlots() {
  for (const s of S.slots) {
    if (s.kind !== 'translated') continue;
    releaseSlot(s);
    s.docKind = 'translated';
    $$('.sel-box, .tag', s.el).forEach(x => x.remove());
    addPageAction(s);
    S.observer.unobserve(s.el); S.observer.observe(s.el);  // re-observing fires again for pages on screen
  }
}

let resizeT;
export function queuePageResize() {
  clearTimeout(resizeT);
  if (!S.slots.length) return;
  resizeT = setTimeout(() => resizePages(), 160);
}
window.addEventListener('resize', () => { invalidateRects(); queuePageResize(); });
new ResizeObserver(() => { invalidateRects(); queuePageResize(); }).observe(viewer);

// Point under `anchor` (client coords) → slot + fractions, to restore after the scale changes.
function anchorPoint(anchor) {
  for (const slot of S.slots) {
    const r = slot.el.getBoundingClientRect();
    if (anchor.y >= r.top && anchor.y <= r.bottom && anchor.x >= r.left - 7 && anchor.x <= r.right + 7)
      return { slot, fx: (anchor.x - r.left) / r.width, fy: (anchor.y - r.top) / r.height };
  }
  return null;
}
export function resizePages(anchor) {
  if (!S.slots.length || !readerShown()) { renderZoomState(); return; }
  const scale = targetScale(), density = dpr();
  pageExtent();
  const scaleChanged = Math.abs(scale - S.scale) * maxPageWidth >= 1;
  if (!scaleChanged && density === S.dpr) { renderZoomState(); return; }
  const point = scaleChanged && anchor ? anchorPoint(anchor) : null;
  const pos = scaleChanged && !point ? currentPos() : null;
  if (scaleChanged) {
    S.scale = scale;
    hideChip(); hidePops(); resetHover(); clearSelBoxes(':not(.para):not(.obj)');
  }
  S.dpr = density;
  for (const slot of S.slots) {
    if (scaleChanged) sizeSlot(slot);
    if (slot.rendered || slot.task) markStale(slot);
  }
  invalidateRects();
  if (point) {
    const r = point.slot.el.getBoundingClientRect();
    viewer.scrollLeft += r.left + point.fx * r.width - anchor.x;
    viewer.scrollTop += r.top + point.fy * r.height - anchor.y;
  } else if (pos) scrollToPos(pos);
  makeObservers();
  if (scaleChanged) { redrawSelection(); drawSearchHits(); }
  renderZoomState();
  updatePageIndicator();
  positionExplanation();
}
// Keep the old canvas (CSS-stretched) on screen until the new render replaces it.
function markStale(slot) {
  slot.run++;
  slot.task?.cancel?.();
  slot.task = null;
  slot.rendered = false;
}

// slot.run invalidates a render still in flight when the slot is released or re-rendered
export function releaseSlot(slot) {
  slot.run = (slot.run || 0) + 1;
  slot.task?.cancel?.();
  slot.task = null;
  const cv = $('canvas', slot.el);
  if (cv) { cv.width = cv.height = 0; cv.remove(); }
  const tl = $('.textLayer', slot.el);
  if (tl) { S.textLayers?.delete(tl); tl.remove(); }
  $('.link-layer', slot.el)?.remove();
  slot.page?.cleanup();
  slot.page = null;
  slot.rendered = false;
}
export async function renderSlot(slot) {
  if (slot.rendered) return;
  const doc = S.docs[slot.docKind];
  if (!doc) return;
  slot.rendered = true;
  const run = slot.run = (slot.run || 0) + 1;
  const stale = () => run !== slot.run || !slot.el.isConnected;
  let canvas;
  try {
    const page = slot.page || await doc.getPage(slot.i + 1);
    if (stale()) return;
    slot.page = page;
    const vp = page.getViewport({ scale: S.scale });
    let k = dpr();
    if (vp.width * vp.height * k * k > MAX_CANVAS_PIXELS) k = Math.sqrt(MAX_CANVAS_PIXELS / (vp.width * vp.height));
    canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.floor(vp.width * k));
    canvas.height = Math.max(1, Math.floor(vp.height * k));
    canvas.setAttribute('aria-hidden', 'true');
    const task = slot.task = page.render({ canvasContext: canvas.getContext('2d', { alpha: false }), viewport: vp, transform: k !== 1 ? [k, 0, 0, k, 0, 0] : null });
    await task.promise;
    if (slot.task === task) slot.task = null;
    if (stale()) { canvas.width = canvas.height = 0; return; }
    const old = $('canvas', slot.el);
    if (old) { old.width = old.height = 0; old.replaceWith(canvas); } else slot.el.prepend(canvas);
    if (!$('.textLayer', slot.el)) await renderTextLayer(slot, page, vp, stale);
    if (stale()) return;
    drawHighlights(slot);
    drawSearchHits(slot);
    drawLinks(slot, page);
    $('.page-load-error', slot.el)?.remove();
  } catch (e) {
    if (stale() || e?.name === 'RenderingCancelledException') return;  // cancelled, or the document was closed
    console.warn(e);
    if (canvas && !canvas.isConnected) canvas.width = canvas.height = 0;
    slot.task = null;
    slot.rendered = false;
    if (!$('.page-load-error', slot.el)) {
      const retry = document.createElement('button');
      retry.type = 'button'; retry.className = 'btn sm page-load-error'; retry.textContent = '이 페이지 다시 열기';
      retry.onclick = () => { retry.remove(); renderSlot(slot); };
      slot.el.append(retry);
    }
  }
}
// The text layer scales with --scale-factor, so it is built once per page and kept across zoom.
async function renderTextLayer(slot, page, vp, stale) {
  const tl = document.createElement('div');
  tl.className = 'textLayer';
  $('canvas', slot.el).after(tl);
  try {
    slot.task = new pdfjsLib.TextLayer({ textContentSource: page.streamTextContent(), container: tl, viewport: vp });
    await slot.task.render();
  } catch (e) { if (!stale()) console.warn(e); }
  if (stale()) { tl.remove(); return; }
  slot.task = null;
  const end = document.createElement('div');  // selection sentinel (see selection.js)
  end.className = 'endOfContent';
  tl.append(end);
  S.textLayers.set(tl, end);
}
