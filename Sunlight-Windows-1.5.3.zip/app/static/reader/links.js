// Links inside the PDF (Link annotations): anchors over the rendered page. Internal destinations jump
// within the paper and leave a "← 이전 위치" chip (also Alt+←); web links open in a new window.
// The layer is built once per rendered page with % positions, so it survives zoom.
// Keyboard: links stay out of the Tab order (a paper can have hundreds); Alt+L (or L) goes to the
// first link in view, arrow keys move between links, Enter follows, Esc returns to the paper.
import { S, $, $$ } from './state.js';
import { currentPos, scrollToPos, gotoPage, readingGesture } from './navigation.js';

// dest (named string or explicit array) → {page (0-based), y (fraction from the top)} or null
export async function resolveDest(doc, dest) {
  try {
    const d = typeof dest === 'string' ? await doc.getDestination(dest) : dest;
    const ref = d?.[0];
    const page = ref && typeof ref === 'object' ? await doc.getPageIndex(ref) : Number.isInteger(ref) ? ref : null;
    if (page == null) return null;
    let y = 0;
    if (d?.[1]?.name === 'XYZ' && Number.isFinite(d[3])) y = Math.max(0, Math.min(1, 1 - d[3] / (S.pageSizes[page]?.h || 792)));
    else if (d?.[1]?.name === 'FitH' && Number.isFinite(d[2])) y = Math.max(0, Math.min(1, 1 - d[2] / (S.pageSizes[page]?.h || 792)));
    return { page, y };
  } catch { return null; }
}

// The words under a link (e.g. "[13]" or "Figure 2"), read from the page's text layer.
function textUnder(slot, el) {
  const r = el.getBoundingClientRect();
  if (!r.width || !r.height) return '';
  const words = $$('.textLayer span', slot.el).filter(sp => {
    const s = sp.getBoundingClientRect(), cx = s.left + s.width / 2, cy = s.top + s.height / 2;
    return !sp.childElementCount && cx >= r.left - 1 && cx <= r.right + 1 && cy >= r.top - 1 && cy <= r.bottom + 1;
  }).map(sp => sp.textContent.trim()).filter(Boolean);
  const text = words.join(' ').replace(/\s+/g, ' ').trim();
  return text.length > 40 ? `${text.slice(0, 40)}…` : text;
}

const WEB = /^(https?:|mailto:)/i;
export async function drawLinks(slot, page) {
  if ($('.link-layer', slot.el)) return;
  const annots = await page.getAnnotations({ intent: 'display' }).catch(() => []);
  const links = annots.filter(a => a.subtype === 'Link' && ((a.url && WEB.test(a.url)) || a.dest));
  if (!links.length || !slot.el.isConnected || $('.link-layer', slot.el)) return;
  const doc = S.docs[slot.docKind];
  const vp = page.getViewport({ scale: 1 });
  const layer = document.createElement('div');
  layer.className = 'link-layer';
  const internal = [];
  for (const a of links) {
    const [x1, y1, x2, y2] = vp.convertToViewportRectangle(a.rect);
    const el = document.createElement('a');
    el.className = 'link-annot';
    el.tabIndex = -1;
    Object.assign(el.style, {
      left: `${Math.min(x1, x2) / vp.width * 100}%`, top: `${Math.min(y1, y2) / vp.height * 100}%`,
      width: `${Math.abs(x2 - x1) / vp.width * 100}%`, height: `${Math.abs(y2 - y1) / vp.height * 100}%`,
    });
    if (a.url && WEB.test(a.url)) {
      el.href = a.url; el.target = '_blank'; el.rel = 'noopener noreferrer';
      el.title = a.url;
      el.setAttribute('aria-label', `${a.url} (새 창에서 열기)`);
    } else {
      el.href = '#';
      el._dest = a.dest;
      el.setAttribute('aria-label', '논문 안의 연결된 위치로 이동');
      internal.push(el);
    }
    layer.append(el);
  }
  slot.el.append(layer);
  // Labels name the target: "[13], 11쪽으로 이동" (text under the link, then the page it opens)
  for (const el of internal) {
    const words = textUnder(slot, el);
    const at = doc && await resolveDest(doc, el._dest);
    if (!el.isConnected) return;
    el._at = at;
    const where = at ? `${at.page + 1}쪽으로 이동` : '논문 안의 연결된 위치로 이동';
    el.setAttribute('aria-label', words ? `${words}, ${where}` : where);
    el.title = el.getAttribute('aria-label');
  }
}

/* ---------------------------------------------------------------- jumping and coming back */
const backStack = [];
const chip = $('#linkBack');
const viewer = $('#viewer');
function paintChip() { chip.hidden = !backStack.length; }
export function resetLinks() { backStack.length = 0; paintChip(); }
export function goBack() {
  const pos = backStack.pop();
  paintChip();
  if (!pos) return false;
  readingGesture();
  scrollToPos(pos);
  viewer.focus({ preventScroll: true });
  return true;
}
chip.addEventListener('click', () => goBack());
$('#pages').addEventListener('click', async e => {
  const a = e.target.closest('a.link-annot');
  if (!a || !a._dest) return;
  e.preventDefault();
  const doc = S.docs[a.closest('.page')?._slot?.docKind] || S.docs.original;
  const at = a._at || (doc && await resolveDest(doc, a._dest));
  if (!at) return;
  const here = currentPos();
  if (here) { backStack.push(here); if (backStack.length > 20) backStack.shift(); paintChip(); }
  gotoPage(at.page, at.y);
  viewer.focus({ preventScroll: true });  // reading continues from the target; Alt+← comes back
});

/* ---------------------------------------------------------------- keyboard */
const visibleLinks = () => {
  const vr = viewer.getBoundingClientRect();
  return $$('.link-annot', viewer).filter(a => { const r = a.getBoundingClientRect(); return r.bottom > vr.top && r.top < vr.bottom && r.width > 0; });
};
// Alt+L / L: the first link in view (returns false when there is none)
export function focusFirstLink() {
  const first = visibleLinks()[0];
  if (!first) return false;
  first.focus({ preventScroll: true });
  return true;
}
$('#pages').addEventListener('keydown', e => {
  const a = e.target.closest?.('a.link-annot');
  if (!a) return;
  const all = $$('.link-annot', viewer), i = all.indexOf(a);
  let next = null;
  if (e.key === 'ArrowDown' || e.key === 'ArrowRight') next = all[i + 1];
  else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') next = all[i - 1];
  else if (e.key === 'Home') next = visibleLinks()[0];
  else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); viewer.focus({ preventScroll: true }); return; }
  else return;
  e.preventDefault();
  if (next) { next.focus({ preventScroll: true }); next.scrollIntoView({ block: 'nearest' }); }
});
