// Markdown + KaTeX for AI text, with an allowlist sanitizer.
// Math is lifted out before marked runs (so `_` and `*` inside formulas survive) and is put back
// only into TEXT nodes after sanitizing: a formula can never land inside an attribute, and KaTeX's
// own markup (classes, inline styles, MathML) is not subject to the attribute allowlist.
// Code is set aside during lifting so `$HOME` or LaTeX shown in code stays literal; inline $…$ follows
// Pandoc (no space inside the delimiters, no digit after) so "$5 and $10" is not math.

/* ---------------------------------------------------------------- policy (pure, no DOM) */
// Elements removed together with their content.
export const DROP_TAGS = new Set(['SCRIPT', 'STYLE', 'IFRAME', 'FRAME', 'FRAMESET', 'OBJECT', 'EMBED', 'LINK', 'META', 'BASE', 'FORM',
  'INPUT', 'BUTTON', 'TEXTAREA', 'SELECT', 'OPTION', 'SVG', 'MATH', 'TEMPLATE', 'NOSCRIPT', 'AUDIO', 'VIDEO', 'SOURCE', 'TRACK',
  'CANVAS', 'DIALOG', 'PORTAL', 'APPLET', 'TITLE', 'XMP', 'PLAINTEXT', 'NOEMBED', 'NOFRAMES']);
// Elements kept; anything else is unwrapped (its text stays).
export const KEEP_TAGS = new Set(['A', 'ABBR', 'B', 'BLOCKQUOTE', 'BR', 'CAPTION', 'CODE', 'DD', 'DEL', 'DETAILS', 'DIV', 'DL', 'DT', 'EM',
  'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'HR', 'I', 'IMG', 'INS', 'KBD', 'LI', 'MARK', 'OL', 'P', 'PRE', 'Q', 'S', 'SMALL', 'SPAN',
  'STRONG', 'SUB', 'SUMMARY', 'SUP', 'TABLE', 'TBODY', 'TD', 'TFOOT', 'TH', 'THEAD', 'TR', 'U', 'UL']);
export const LINK_OK = /^(https?:|mailto:|#|\/(?![\/\\]))/;
const norm = v => String(v).replace(/[\s\u0000-\u001f]/g, '').toLowerCase();
// Images load only from a paper's saved region crops; anything else becomes a link to click.
export const imageSrcOk = v => /^\/api\/papers\/[A-Za-z0-9]{1,64}\/region\/region_[0-9a-f]{8}\.png$/.test(String(v).trim());
// → true to keep the attribute as is
export function attrAllowed(tag, name, value) {
  name = name.toLowerCase();
  switch (name) {
    case 'href': return tag === 'A' && LINK_OK.test(norm(value));
    case 'src': return tag === 'IMG' && imageSrcOk(value);
    case 'title': case 'alt': return true;
    case 'colspan': case 'rowspan': return (tag === 'TD' || tag === 'TH') && /^\d{1,3}$/.test(value.trim());
    case 'start': return tag === 'OL' && /^-?\d{1,6}$/.test(value.trim());
    case 'align': return (tag === 'TD' || tag === 'TH') && /^(left|center|right)$/i.test(value.trim());
    case 'lang': return /^[a-z]{2,3}(-[a-z0-9]{2,8})*$/i.test(value.trim());
    case 'dir': return /^(ltr|rtl|auto)$/i.test(value.trim());
    case 'open': return tag === 'DETAILS';
    default: return false;
  }
}

// Split math and code out of the source. Pure: returns {src, math}.
export function liftMath(src) {
  const code = [], math = [];
  src = String(src || '').replace(/```[\s\S]*?(?:```|$)|`[^`\n]+`/g, m => { code.push(m); return `@@C${code.length - 1}@@`; });
  src = src.replace(/\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|\$(?=\S)([^$\n]*?\S)\$(?!\d)/g, (m, a, b, c, d) => {
    math.push({ tex: a ?? b ?? c ?? d, disp: a != null || b != null });
    return `@@M${math.length - 1}@@`;
  });
  src = src.replace(/@@C(\d+)@@/g, (m, i) => code[i] ?? m);
  return { src, math };
}

// Where a streaming answer can be cut so the part before never changes its rendering:
// the last blank line outside a code fence and outside $$ display math.
export function stableBoundary(text, from = 0) {
  let i = text.lastIndexOf('\n\n');
  for (let guard = 0; i > from && guard < 200; guard++, i = text.lastIndexOf('\n\n', i - 1)) {
    const head = text.slice(0, i);
    const fences = (head.match(/^\s*```/gm) || []).length;
    const display = (head.match(/\$\$/g) || []).length;
    if (fences % 2 === 0 && display % 2 === 0) return i + 2;
  }
  return from;
}

/* ---------------------------------------------------------------- DOM */
function sanitize(root) {
  const doc = root.ownerDocument || document;
  root.querySelectorAll('*').forEach(n => { if (DROP_TAGS.has(n.tagName.toUpperCase())) n.remove(); });
  // Walk in document order; unwrapping moves children up, so collect first.
  for (const n of [...root.querySelectorAll('*')]) {
    if (!n.isConnected && !root.contains(n)) continue;
    const tag = n.tagName.toUpperCase();
    if (!KEEP_TAGS.has(tag)) { n.replaceWith(...n.childNodes); continue; }
    for (const a of [...n.attributes]) if (!attrAllowed(tag, a.name, a.value)) n.removeAttribute(a.name);
    if (tag === 'IMG' && !n.hasAttribute('src')) {
      const raw = (n.getAttribute('title') || '').trim();
      const l = doc.createElement('span');
      l.textContent = `[이미지${n.getAttribute('alt') ? `: ${n.getAttribute('alt')}` : ''}]`;
      void raw;
      n.replaceWith(l);
    } else if (tag === 'A') {
      if (n.hasAttribute('href')) { n.target = '_blank'; n.rel = 'noopener noreferrer'; }
    }
  }
  return root;
}
// Off-server images become links before the attribute pass removes their src.
function linkifyImages(root) {
  const doc = root.ownerDocument || document;
  for (const img of [...root.querySelectorAll('img')]) {
    const v = img.getAttribute('src') || '';
    if (imageSrcOk(v)) continue;
    const ok = LINK_OK.test(norm(v));
    const l = doc.createElement(ok ? 'a' : 'span');
    l.textContent = `[이미지: ${img.getAttribute('alt') || v.trim()}]`;
    if (ok) l.setAttribute('href', v.trim());
    img.replaceWith(l);
  }
}

const katexCache = new Map();
function texHtml(x) {
  const k = (x.disp ? 'D' : 'I') + x.tex;
  if (!katexCache.has(k)) {
    if (katexCache.size > 800) katexCache.clear();
    let h = null;
    try { h = globalThis.katex?.renderToString(x.tex, { displayMode: x.disp, throwOnError: false, trust: false }) ?? null; } catch { h = null; }
    katexCache.set(k, h);
  }
  return katexCache.get(k);
}
function putMath(root, math) {
  const doc = root.ownerDocument || document;
  const walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const hits = [];
  for (let t; (t = walker.nextNode());) if (t.data.includes('@@M')) hits.push(t);
  for (const t of hits) {
    const f = doc.createDocumentFragment();
    let last = 0;
    for (const m of t.data.matchAll(/@@M(\d+)@@/g)) {
      const x = math[+m[1]];
      if (!x) continue;
      f.append(t.data.slice(last, m.index));
      const html = texHtml(x);
      if (html == null) f.append(x.disp ? `$$${x.tex}$$` : `$${x.tex}$`);
      else { const tpl = doc.createElement('template'); tpl.innerHTML = html; f.append(tpl.content); }
      last = m.index + m[0].length;
    }
    if (!last) continue;
    f.append(t.data.slice(last));
    t.replaceWith(f);
  }
}

// Markdown → sanitized DocumentFragment.
export function mdFragment(src) {
  const { src: lifted, math } = liftMath(src);
  const t = document.createElement('template');
  t.innerHTML = globalThis.marked ? marked.parse(lifted, { breaks: false }) : lifted.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  linkifyImages(t.content);
  sanitize(t.content);
  putMath(t.content, math);
  return t.content;
}
export function md(src) {
  const d = document.createElement('div');
  d.append(mdFragment(src));
  return d.innerHTML;
}
export function renderMd(el, src, numPages = 0) {
  el.replaceChildren(mdFragment(src));
  if (numPages) linkPages(el, numPages);
  return el;
}

// "p.3" / "pp. 4–5" in AI text → button that scrolls the paper there (code and formulas left alone)
const PREF = /\b(pp?\.\s?)(\d{1,4})/g;
export function linkPages(root, numPages) {
  if (!numPages) return root;
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), hits = [];
  for (let t; (t = w.nextNode());) if (/\bpp?\.\s?\d/.test(t.data) && !t.parentElement?.closest('code, pre, a, button, .katex')) hits.push(t);
  for (const t of hits) {
    const f = document.createDocumentFragment();
    let last = 0;
    for (const m of t.data.matchAll(PREF)) {
      const p = +m[2];
      if (!p || p > numPages) continue;
      const a = document.createElement('button');
      a.type = 'button';
      a.className = 'pref'; a.dataset.goto = p; a.title = `${p}쪽으로 이동`; a.textContent = m[0];
      f.append(t.data.slice(last, m.index), a);
      last = m.index + m[0].length;
    }
    if (!last) continue;
    f.append(t.data.slice(last));
    t.replaceWith(f);
  }
  return root;
}

// Streaming answer: blocks before the last stable blank line are rendered once and kept;
// only the trailing block is re-rendered on each paint. finish() renders the whole text once.
export function streamRenderer(el, numPages = 0) {
  let stableLen = 0;
  const stable = document.createElement('div'), tail = document.createElement('div');
  stable.className = tail.className = 'md-part';
  el.replaceChildren(stable, tail);
  return {
    update(text) {
      const cut = stableBoundary(text, stableLen);
      if (cut > stableLen) {
        const part = document.createElement('div');
        part.className = 'md-part';
        renderMd(part, text.slice(stableLen, cut), numPages);
        stable.append(part);
        stableLen = cut;
      }
      renderMd(tail, text.slice(stableLen), numPages);
    },
    finish(text) { renderMd(el, text, numPages); },
  };
}
