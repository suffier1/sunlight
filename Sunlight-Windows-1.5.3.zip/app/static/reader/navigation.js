// Reading position (page + fraction, survives zoom/mode/window changes), page indicator and
// go-to-page, the "continue where another device was" prompt. Owns S.position*, S.restorePos.
import { S, $, live } from './state.js';
import { columnStride } from './layout.js';
import { showPanel } from './panel.js';

const viewer = $('#viewer');

// The reading line sits a little below the viewer's top edge: the page indicator, the saved position
// (이어 읽기 "N쪽 읽는 중") and restoring all use it, so they always agree.
export const readingProbe = () => Math.min(160, viewer.clientHeight / 3);
export function currentPos(probe = readingProbe()) {
  if (!S.slots.length) return null;
  const top = viewer.getBoundingClientRect().top + probe;
  const stride = columnStride();
  let lo = 0, hi = S.slots.length / stride;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (S.slots[mid * stride].el.getBoundingClientRect().bottom > top + 1) hi = mid;
    else lo = mid + 1;
  }
  const s = S.slots[lo * stride];
  if (!s) return null;
  const r = s.el.getBoundingClientRect();
  return { p: s.i, f: r.height ? Math.max(0, (top - r.top) / r.height) : 0 };
}
export function savePos() {
  if (!S.positionDirty || !S.position) return;
  S.positionDirty = false;
  S.position.move(currentPos());
}
export function scrollToPos(pos) {
  const el = pos && S.slots[pos.p * columnStride()]?.el;
  if (!el) { viewer.scrollTop = 0; return; }
  viewer.scrollTop += el.getBoundingClientRect().top - viewer.getBoundingClientRect().top + (pos.f || 0) * el.offsetHeight - readingProbe();
}
// Only movement the reader caused is saved (an open, a re-layout or a remote jump is not a write).
export const readingGesture = () => { S.positionGesture = performance.now() + 1400; };
for (const event of ['wheel', 'touchmove', 'pointerdown']) viewer.addEventListener(event, readingGesture, { passive: true });
document.addEventListener('keydown', e => {
  if (['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' '].includes(e.key) && !e.target.closest?.('textarea,input,select,dialog')) readingGesture();
});
let posT;
export function positionScrolled() {
  if (!S.position || !(S.positionGesture > performance.now())) return;
  readingGesture();
  S.positionDirty = true;
  clearTimeout(posT);
  posT = setTimeout(savePos, 400);
}
export function stopPositionTimer() { clearTimeout(posT); }
window.addEventListener('pagehide', savePos);

export function gotoPage(i, yFrac = 0) {
  const el = S.slots.find(s => s.i === i)?.el;
  if (!el) return;
  readingGesture();
  if (viewer.inert) {
    showPanel(false);
    viewer.focus({ preventScroll: true });
  }
  const top = el.offsetTop + el.offsetHeight * (yFrac || 0) - 120;
  // a long smooth scroll would render every page it passes
  viewer.scrollTo({ top, behavior: Math.abs(top - viewer.scrollTop) > 3 * viewer.clientHeight || matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
}
document.addEventListener('click', e => {
  const a = e.target.closest('.pref');
  if (a) gotoPage(+a.dataset.goto - 1);
});

/* ---------------------------------------------------------------- page indicator */
const pageInput = $('#pageInput'), pageTotal = $('#pageTotal');
export function updatePageIndicator() {
  const n = S.docs.original?.numPages || 0;
  $('#pageNav').hidden = !n;
  if (!n) return;
  const p = (currentPos()?.p ?? 0) + 1;
  pageTotal.textContent = `/ ${n}`;
  pageInput.setAttribute('aria-label', `현재 쪽, 전체 ${n}쪽 중`);
  if (document.activeElement !== pageInput && pageInput.value !== String(p)) pageInput.value = String(p);
}
pageInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    e.preventDefault();
    const n = S.docs.original?.numPages || 0, p = Math.round(+pageInput.value.replace(/[^\d]/g, ''));
    if (p >= 1 && p <= n) { gotoPage(p - 1); viewer.focus({ preventScroll: true }); }
    else { pageInput.select(); pageInput.setAttribute('aria-invalid', 'true'); }
  } else if (e.key === 'Escape') { e.preventDefault(); pageInput.blur(); updatePageIndicator(); viewer.focus({ preventScroll: true }); }
});
pageInput.addEventListener('input', () => pageInput.removeAttribute('aria-invalid'));
pageInput.addEventListener('focus', () => pageInput.select());
pageInput.addEventListener('blur', () => { pageInput.removeAttribute('aria-invalid'); updatePageIndicator(); });

/* ---------------------------------------------------------------- another device's position (contract §8) */
const remote = $('#remotePos');
export function hideRemotePrompt() { remote.hidden = true; }
// info: {page (1-based), fraction, device, at} from reading-position.js onNewer
export function promptRemotePosition(info, sess) {
  const n = S.docs.original?.numPages || 0;
  const page = Math.round(Number(info?.page));
  if (!live(sess) || !(page >= 1 && page <= n)) return;
  if ((currentPos()?.p ?? 0) + 1 === page) return;
  const name = typeof info.device === 'string' ? info.device.trim().slice(0, 40) : '';
  const device = !name ? '휴대폰' : name === 'PC' ? '다른 PC' : name;
  $('#remotePosText').textContent = `${device}에서 읽던 ${page}쪽으로 이동`;
  remote.hidden = false;
  const frac = Number.isFinite(info.fraction) ? Math.max(0, Math.min(1, info.fraction)) : 0;
  $('#remotePosGo').onclick = () => { hideRemotePrompt(); gotoPage(page - 1, frac); viewer.focus({ preventScroll: true }); };
  $('#remotePosSkip').onclick = () => { hideRemotePrompt(); viewer.focus({ preventScroll: true }); };
}
