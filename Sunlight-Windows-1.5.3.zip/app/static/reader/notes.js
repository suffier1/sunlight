// Highlights on the page, the 메모 tab, note drafts and the highlight popover. Owns S.highlights.
// A draft and its write queue belong to the note (keyed by URL), so redrawing the panel cannot lose one.
import { api, esc, toast, errorText, confirmDialog } from '../ui-kit.js';
import { S, $, $$, live } from './state.js';
import { toNorm } from './layout.js';
import { mergeBoxes, pointPdf } from './selection.js';
import { gotoPage } from './navigation.js';
import { switchTab } from './panel.js';

export const COLORS = ['yellow', 'green', 'blue', 'pink'];
const COLOR_NAME = { yellow: '노란색', green: '초록색', blue: '파란색', pink: '분홍색' };
const hlColor = c => (COLORS.includes(c) ? c : 'yellow');
const OBJ_NAME = { figure: '그림', table: '표', equation: '수식' };
const CAPTION_RE = { figure: /^(?:fig\.?|figure)\s*(\d+)/i, table: /^table\s*(\d+)/i };
// "그림 3" from the nearest "Figure 3" caption on the page, else just "그림"
export function objectLabel(o) {
  if (!o) return '영역';
  const name = OBJ_NAME[o.kind] || '영역';
  const re = CAPTION_RE[o.kind];
  if (!re) return name;
  let best = null;
  for (const b of S.blocksByPage.get(o.page) || []) {
    const m = re.exec(b.text.trim());
    if (!m || b.bbox[2] < o.bbox[0] || b.bbox[0] > o.bbox[2]) continue;  // same column
    const d = b.bbox[1] >= o.bbox[3] ? b.bbox[1] - o.bbox[3] : b.bbox[3] <= o.bbox[1] ? o.bbox[1] - b.bbox[3] : 0;
    if (d < 80 && (!best || d < best.d)) best = { d, n: m[1] };
  }
  return best ? `${name} ${best.n}` : name;
}
// older figure highlights stored "[그림] <every word inside the figure>"
const noteText = t => (/^\[(그림|표|수식|영역)\]/.exec(t || '')?.[1]) || t;

const area = r => Math.max(0, r[2]) * Math.max(0, r[3]);
// normalized [x, y, w, h] rect lists → overlap / the LARGER area: only "the same spot again" counts
export function overlapShare(a, b) {
  let inter = 0;
  for (const p of a) for (const q of b) {
    inter += area([0, 0, Math.min(p[0] + p[2], q[0] + q[2]) - Math.max(p[0], q[0]), Math.min(p[1] + p[3], q[1] + q[3]) - Math.max(p[1], q[1])]);
  }
  const big = Math.max(a.reduce((s, r) => s + area(r), 0), b.reduce((s, r) => s + area(r), 0));
  return big ? inter / big : 0;
}
const toBoxes = rects => rects.map(([x, y, w, h]) => [x, y, x + w, y + h]);
const toRects = boxes => boxes.map(([x0, y0, x1, y1]) => [x0, y0, x1 - x0, y1 - y0]);
const base = () => `/api/papers/${S.paper.id}/highlights`;

export async function loadHighlights(sess = S.sess) {
  const all = await api(base(), { signal: sess.signal, timeout: 12000 });
  if (!live(sess)) return;
  if (!Array.isArray(all)) throw new Error('메모 데이터를 읽을 수 없습니다.');
  S.highlights = all;
  S.highlightsReady = true;
  S.slots.forEach(drawHighlights);
  renderNotes();
  pruneDrafts(S.paper.id);
}
export function resetNotes() {
  S.highlights = []; S.highlightsReady = false;
  closeHighlightPopover(false);
  $('#tab-notes').innerHTML = '<div class="empty" role="status">메모를 불러오는 중입니다.</div>';
  setTabCount(0);
}
function setTabCount(n) {
  const tab = $('[data-tab="notes"]');
  tab.innerHTML = `메모${n ? `<span class="n" aria-hidden="true">${n}</span>` : ''}`;
  tab.setAttribute('aria-label', n ? `메모, ${n}개` : '메모');
}
export function drawHighlights(slot) {
  const layer = $('.hl-layer', slot.el);
  if (!layer) return;
  layer.replaceChildren();
  for (const h of S.highlights) {
    if (h.page !== slot.i || (h.kind || 'original') !== slot.docKind) continue;
    const rects = toRects(mergeBoxes(toBoxes(h.rects)));  // older highlights stored overlapping rects
    for (const [x, y, w, hh] of rects) {
      const d = document.createElement('div');
      d.className = `hl ${hlColor(h.color)}`;
      d.dataset.hid = h.id;
      Object.assign(d.style, { left: `${x * 100}%`, top: `${y * 100}%`, width: `${w * 100}%`, height: `${hh * 100}%` });
      layer.appendChild(d);
    }
    // keyboard path to the popover: one focusable marker per highlight, visible on focus
    if (rects.length) {
      const [x, y, , hh] = rects[0];
      const a = document.createElement('button');
      a.type = 'button'; a.className = 'hl-anchor'; a.dataset.hid = h.id;
      a.setAttribute('aria-label', `${h.page + 1}쪽 ${COLOR_NAME[hlColor(h.color)]} 하이라이트${h.note ? ', 메모 있음' : ''}: ${noteText(h.text).slice(0, 80)}`);
      Object.assign(a.style, { left: `${x * 100}%`, top: `${y * 100}%`, height: `${hh * 100}%` });
      layer.appendChild(a);
    }
  }
}
$('#pages').addEventListener('click', e => {
  const a = e.target.closest('.hl-anchor');
  if (!a) return;
  const h = S.highlights.find(x => x.id === a.dataset.hid);
  const r = a.getBoundingClientRect();
  if (h) openHighlightPopover(h, { x: r.left + 8, y: r.bottom }, a);
});
// Hit test for a click on the page (highlights sit under the text layer and take no pointer events).
export function highlightAt(slot, ev) {
  const [x, y] = pointPdf(slot, ev);
  const { w, h: ph } = S.pageSizes?.[slot.i] || { w: 612, h: 792 };
  const nx = x / w, ny = y / ph;
  return S.highlights.find(h => h.page === slot.i && (h.kind || 'original') === slot.docKind &&
    h.rects.some(([rx, ry, rw, rh]) => nx >= rx && nx <= rx + rw && ny >= ry && ny <= ry + rh));
}
function redrawPage(page) { S.slots.filter(x => x.i === page).forEach(drawHighlights); }

/* ---------------------------------------------------------------- create */
// One highlight per page (a selection can span pages). Overlapping ones are replaced in one server transaction.
export async function addHighlightFromSelection(s, color = 'yellow', text = s.text) {
  const sess = S.sess, pid = S.paper.id, url = base();
  const per = (await s.pageTexts?.catch(() => null)) || {};
  if (!live(sess)) return [];
  const rects = s.parts.flatMap(p => p.boxes.map(b => ({ page: p.page, r: toNorm(p.page, b) })));
  const made = [];
  try {
    for (const page of [...new Set(rects.map(x => x.page))]) {
      const mine = rects.filter(x => x.page === page).map(x => x.r);
      const old = S.highlights.filter(h => h.page === page && (h.kind || 'original') === s.kind && overlapShare(h.rects, mine) > 0.5);
      const replace_ids = old.map(h => h.id);
      if (replace_ids.some(id => noteBusy.has(`${url}/${id}`))) throw new Error('메모 작업이 끝나면 다시 시도하세요.');
      for (const id of replace_ids) setNoteBusy(`${url}/${id}`, pid, id, true);
      let h;
      try {
        await flushNoteDrafts(draft => draft.pid === pid && replace_ids.includes(draft.hid));
        if (!live(sess)) return made;
        const label = s.source === 'object' ? objectLabel(s.obj) : s.source === 'region' ? '영역' : (per[page] || text);
        h = await api(url, { method: 'POST', signal: sess.signal, body: { page, rects: mine, text: label, color, kind: s.kind, replace_ids } });
      } finally {
        for (const id of replace_ids) setNoteBusy(`${url}/${id}`, pid, id, false);
      }
      if (!live(sess)) return made;
      // the replaced highlights' notes are merged by the server into the new one
      S.highlights = S.highlights.filter(x => !old.includes(x)).concat(h);
      made.push(h);
      redrawPage(page);
    }
  } catch (e) {
    if (live(sess)) await loadHighlights(sess).catch(() => {});  // show what the server actually has
    throw e;
  }
  renderNotes();
  return made;
}
// The highlight at the selection's first page, made (yellow) if there is none yet.
export async function ensureHighlight(sel, text) {
  const first = sel.parts[0];
  const mine = first.boxes.map(b => toNorm(first.page, b));
  let h = S.highlights.find(x => x.page === first.page && (x.kind || 'original') === sel.kind && overlapShare(x.rects, mine) > 0.5);
  if (!h) [h] = await addHighlightFromSelection(sel, 'yellow', text ?? await (sel.textPromise || Promise.resolve(sel.text)).catch(() => sel.text));
  if (!h) throw new Error('메모를 만들지 못했습니다. 다시 시도하세요.');
  return h;
}
// "메모에 추가" from an explanation: the highlight at the selection (made if missing) gets the text appended.
export async function attachNote(sel, text) {
  const h = await ensureHighlight(sel);
  const url = `${base()}/${h.id}`;
  await flushNoteDrafts(d => d.url === url);
  const cur = S.highlights.find(x => x.id === h.id) || h;
  const note = [cur.note, text].filter(x => x && x.trim()).join('\n\n').slice(0, 20000);
  await api(url, { method: 'PATCH', body: { note } });
  cur.note = note;
  renderNotes();
  return cur;
}

/* ---------------------------------------------------------------- popover on the page */
const pop = $('#hlPop');
let popHighlight = null, popReturn = null;
export function openHighlightPopover(h, at, returnTo = null) {
  popHighlight = h; popReturn = returnTo;
  $('#hlPopTitle').textContent = `${h.page + 1}쪽 하이라이트`;
  $$('[data-hl-color]', pop).forEach(b => b.setAttribute('aria-pressed', String(b.dataset.hlColor === hlColor(h.color))));
  $('[data-hl-note]', pop).textContent = h.note ? '메모 보기' : '메모 쓰기';
  pop.hidden = false;
  pop.style.left = `${Math.max(8, Math.min(at.x - pop.offsetWidth / 2, innerWidth - pop.offsetWidth - 8))}px`;
  pop.style.top = `${Math.max(8, Math.min(at.y + 10, innerHeight - pop.offsetHeight - 8))}px`;
  ($('[aria-pressed="true"]', pop) || $('button', pop)).focus({ preventScroll: true });
}
export function closeHighlightPopover(restore = true) {
  if (pop.hidden) return;
  pop.hidden = true;
  const back = popReturn;
  popHighlight = null; popReturn = null;
  if (restore) (back?.isConnected ? back : $('#viewer')).focus({ preventScroll: true });
}
pop.addEventListener('keydown', e => {
  if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeHighlightPopover(); }
  if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
    const buttons = $$('button', pop), i = buttons.indexOf(document.activeElement);
    e.preventDefault();
    buttons[(i + (e.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length].focus();
  }
});
pop.addEventListener('focusout', e => { if (e.relatedTarget && !pop.contains(e.relatedTarget)) closeHighlightPopover(false); });
document.addEventListener('pointerdown', e => { if (!pop.hidden && !pop.contains(e.target)) closeHighlightPopover(false); }, true);
pop.addEventListener('click', async e => {
  const h = popHighlight;
  const b = e.target.closest('button');
  if (!h || !b) return;
  if (b.dataset.hlColor) {
    const color = b.dataset.hlColor, prev = h.color;
    h.color = color; redrawPage(h.page); renderNotes();
    $$('[data-hl-color]', pop).forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    try { await api(`${base()}/${h.id}`, { method: 'PATCH', body: { color } }); }
    catch (err) { h.color = prev; redrawPage(h.page); renderNotes(); toast(`색을 바꾸지 못했습니다. ${errorText(err)}`, { kind: 'error' }); }
  } else if (b.hasAttribute('data-hl-note')) {
    closeHighlightPopover(false);
    focusNote(h.id);
  } else if (b.hasAttribute('data-hl-delete')) {
    closeHighlightPopover(false);
    await deleteHighlight(h);
  }
});
export function focusNote(hid) {
  switchTab('notes');
  const t = $(`#tab-notes .note[data-hid="${CSS.escape(hid)}"] textarea`);
  t?.scrollIntoView({ block: 'nearest' });
  t?.focus({ preventScroll: true });
  if (t) growNote(t);
}

/* ---------------------------------------------------------------- 메모 tab */
export function renderNotes() {
  const hs = [...S.highlights].sort((a, b) => a.page - b.page || (a.rects[0]?.[1] ?? 0) - (b.rects[0]?.[1] ?? 0));
  setTabCount(hs.length);
  const el = $('#tab-notes');
  const editing = document.activeElement?.closest('.note textarea') && el.contains(document.activeElement) ? document.activeElement : null;
  const focus = editing && { id: editing.closest('.note').dataset.hid, start: editing.selectionStart, end: editing.selectionEnd };
  if (!hs.length) { el.innerHTML = '<div class="empty">표시할 문장을 선택하고 색을 고르세요.</div>'; return; }
  el.innerHTML = `<div class="notes">${hs.map(h => `
    <div class="note ${hlColor(h.color)}" data-hid="${esc(h.id)}">
      <button type="button" class="nt" title="표시한 위치로 이동">${esc(noteText(h.text))}</button>
      <textarea aria-label="${h.page + 1}쪽 하이라이트 메모" placeholder="메모" rows="1">${esc(h.note || '')}</textarea>
      <div class="nm"><span>${h.page + 1}쪽${h.kind === 'translated' ? ' · 번역본' : ''}</span><small class="sv" role="status"></small><button type="button" class="link hidden" data-save-note>다시 저장</button><button type="button" class="link" data-del>삭제</button></div>
    </div>`).join('')}</div>`;
  const pid = S.paper.id, url0 = base();
  $$('.note', el).forEach(n => {
    const h = S.highlights.find(x => x.id === n.dataset.hid);
    const url = `${url0}/${h.id}`, t = $('textarea', n);
    const restored = noteDrafts.get(url) || restoreNoteDraft(url, pid, h);
    if (restored) { t.value = restored.value; renderNoteStatus(restored); }
    t.onfocus = () => growNote(t);
    setNoteBusy(url, pid, h.id, noteBusy.has(url));
    n.onclick = async e => {
      if (e.target.closest('textarea')) return;
      if (e.target.closest('[data-save-note]')) {
        const draft = noteDrafts.get(url);
        if (draft) saveNoteDraft(draft).catch(() => {});
        return;
      }
      if (e.target.closest('[data-del]')) { await deleteHighlight(h); return; }
      gotoPage(h.page, h.rects[0]?.[1]);
      setTimeout(() => $$(`.hl[data-hid="${CSS.escape(h.id)}"]`).forEach(d => { d.classList.add('flash'); setTimeout(() => d.classList.remove('flash'), 1400); }), 400);
    };
    t.oninput = () => {
      const draft = noteDrafts.get(url) || { url, pid, hid: h.id };
      growNote(t);
      draft.value = t.value; draft.failed = false; draft.restored = false;
      noteDrafts.set(url, draft);
      try { localStorage.setItem(`sl.noteDraft.${url}`, draft.value); } catch { /* continue saving through the app */ }
      renderNoteStatus(draft);
      scheduleNoteSave(draft);
    };
    t.onblur = () => {
      const draft = noteDrafts.get(url);
      if (draft && !draft.failed) saveNoteDraft(draft).catch(() => {});
    };
  });
  requestAnimationFrame(() => $$('textarea', el).forEach(growNote));
  if (focus) {
    const input = $(`.note[data-hid="${CSS.escape(focus.id)}"] textarea`, el);
    if (input && !input.disabled) { input.focus({ preventScroll: true }); input.setSelectionRange(focus.start, focus.end); }
  }
}
// The memo box grows with its text (up to a limit, then it scrolls).
export function growNote(t) {
  if (!t.offsetParent) return;  // hidden tab: measured again on focus / next render
  t.style.height = 'auto';
  t.style.height = `${Math.min(320, t.scrollHeight + 2)}px`;
}
async function deleteHighlight(h) {
  const pid = S.paper.id, url = `${base()}/${h.id}`;
  if ((h.note || noteDrafts.has(url)) && !await confirmDialog({
    title: '메모가 있는 하이라이트를 삭제할까요?', body: '하이라이트와 메모가 함께 삭제되며 되돌릴 수 없습니다.', confirm: '삭제', danger: true,
  })) return;
  setNoteBusy(url, pid, h.id, true);
  const draft = noteDrafts.get(url);
  if (draft) {
    clearTimeout(draft.timer);
    draft.deleting = true;
    await draft.writing?.catch(() => {});
  }
  try { await api(url, { method: 'DELETE' }); } catch (err) {
    if (draft) { draft.deleting = false; draft.failed = true; renderNoteStatus(draft); }
    setNoteBusy(url, pid, h.id, false);
    toast(`삭제하지 못했습니다. ${errorText(err)}`, { kind: 'error' });
    return;
  }
  forgetNoteDraft(url, draft);
  setNoteBusy(url, pid, h.id, false);
  if (S.paper?.id !== pid) return;
  S.highlights = S.highlights.filter(x => x.id !== h.id);
  redrawPage(h.page);
  renderNotes();
  toast('하이라이트를 삭제했습니다.');
}

const noteDrafts = new Map();
const noteBusy = new Set();
function setNoteBusy(url, pid, hid, busy) {
  if (busy) noteBusy.add(url); else noteBusy.delete(url);
  if (S.paper?.id !== pid) return;
  const n = $(`#tab-notes .note[data-hid="${CSS.escape(hid)}"]`);
  if (n) $$('button, textarea', n).forEach(el => { el.disabled = busy; });
}
// A draft left in this browser by a closed window: shown as restored, saved when the box loses focus.
function restoreNoteDraft(url, pid, highlight) {
  let value;
  try { value = localStorage.getItem(`sl.noteDraft.${url}`); } catch { return; }
  if (value === null) return;
  const draft = { url, pid, hid: highlight.id, value, restored: true };
  noteDrafts.set(url, draft);
  if (value === (highlight.note || '')) { forgetNoteDraft(url, draft); return; }
  return draft;
}
// Drafts whose highlight no longer exists are dropped.
function pruneDrafts(pid) {
  const prefix = `sl.noteDraft./api/papers/${pid}/highlights/`;
  const ids = new Set(S.highlights.map(h => h.id));
  try {
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (key?.startsWith(prefix) && !ids.has(key.slice(prefix.length))) localStorage.removeItem(key);
    }
  } catch { /* storage unavailable */ }
}
function forgetNoteDraft(url, draft) {
  if (noteDrafts.get(url) !== draft) return;
  clearTimeout(draft?.timer);
  noteDrafts.delete(url);
  try {
    const key = `sl.noteDraft.${url}`;
    if (!draft || localStorage.getItem(key) === draft.value) localStorage.removeItem(key);
  } catch { /* the server copy has already been saved */ }
}
function renderNoteStatus(draft) {
  if (S.paper?.id !== draft.pid) return;
  const n = $(`#tab-notes .note[data-hid="${CSS.escape(draft.hid)}"]`);
  if (!n) return;
  const pending = noteDrafts.get(draft.url) === draft;
  $('.sv', n).textContent = draft.failed ? '저장하지 못했습니다' : draft.writing ? '저장 중' : draft.restored ? '저장하지 않은 메모를 복원했습니다' : pending ? '저장 대기' : '저장됨';
  $('.sv', n).classList.toggle('bad', !!draft.failed);
  $('[data-save-note]', n).classList.toggle('hidden', !draft.failed || draft.deleting);
}
function scheduleNoteSave(draft) {
  clearTimeout(draft.timer);
  draft.timer = setTimeout(() => saveNoteDraft(draft).catch(() => {}), 600);
}
function saveNoteDraft(draft) {
  clearTimeout(draft.timer);
  if (draft.deleting || noteDrafts.get(draft.url) !== draft) return Promise.resolve();
  if (draft.writing) return draft.writing;
  const note = draft.value;
  draft.failed = false; draft.restored = false;
  draft.writing = api(draft.url, { method: 'PATCH', body: { note }, timeout: 12000 }).then(() => {
    const h = S.paper?.id === draft.pid && S.highlights.find(x => x.id === draft.hid);
    if (h) h.note = note;
    if (draft.value === note && !draft.deleting) forgetNoteDraft(draft.url, draft);
  }).catch(error => {
    if (draft.value === note) draft.failed = true;
    throw error;
  }).finally(() => {
    draft.writing = null;
    renderNoteStatus(draft);
    if (!draft.deleting && draft.value !== note && noteDrafts.get(draft.url) === draft) scheduleNoteSave(draft);
  });
  renderNoteStatus(draft);
  return draft.writing;
}
export async function flushNoteDrafts(matches = () => true) {
  const drafts = [...noteDrafts.values()].filter(draft => !draft.deleting && matches(draft));
  const results = await Promise.allSettled(drafts.map(async draft => {
    while (!draft.deleting && noteDrafts.get(draft.url) === draft) await saveNoteDraft(draft);
  }));
  if (results.some(r => r.status === 'rejected')) throw new Error('메모를 저장하지 못했습니다. 다시 시도해 주세요.');
}
window.addEventListener('pagehide', () => {
  for (const draft of noteDrafts.values()) {
    if (draft.writing || draft.deleting) continue;  // a concurrent unload write could undo the newest edit
    fetch(draft.url, { method: 'PATCH', keepalive: true, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ note: draft.value }) }).catch(() => {});
  }
});
