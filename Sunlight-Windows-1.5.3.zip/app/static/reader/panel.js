// 논문 도구 side panel: open state per window width, tabs (요약 · 대화 · 메모), splitter.
import { errorBlock } from '../ui-kit.js';
import { $, $$ } from './state.js';
import { hidePops, hideChip, resetHover } from './selection.js';
import { closeQuick } from './explain.js';
import { growNote } from './notes.js';

const compactReader = matchMedia('(max-width: 900px)');
const panel = $('#panel'), panelToggle = $('#panelToggle'), splitter = $('#splitter'), viewer = $('#viewer');
const prefKey = () => (compactReader.matches ? 'sl.panelOpen.narrow' : 'sl.panelOpen.wide');
const store = (k, v) => { try { localStorage.setItem(k, v); } catch { /* session only */ } };
const read = k => { try { return localStorage.getItem(k); } catch { return null; } };

export function restorePanelPreference() { showPanel(read(prefKey()) === 'true'); }
export function showPanel(open) {
  const overlay = open && compactReader.matches;
  const focused = document.activeElement;
  const focusTab = overlay && (viewer.contains(focused) || focused === splitter);
  if (!open && (panel.contains(focused) || focused === splitter)) panelToggle.focus({ preventScroll: true });
  panel.classList.toggle('collapsed', !open);
  panelToggle.setAttribute('aria-expanded', String(open));
  if (focusTab) $('.tabs [aria-selected="true"]').focus({ preventScroll: true });
  splitter.hidden = !open || overlay;
  if (overlay && !viewer.inert) { hidePops(); hideChip(); closeQuick(false); resetHover(); }
  viewer.inert = overlay;
}
compactReader.addEventListener('change', restorePanelPreference);
export function switchTab(t) {
  showPanel(true);
  $$('.tabs button').forEach(b => {
    const selected = b.dataset.tab === t;
    b.classList.toggle('on', selected);
    b.setAttribute('aria-selected', String(selected));
    b.tabIndex = selected ? 0 : -1;
  });
  $$('.tab-body').forEach(b => b.classList.toggle('hidden', b.id !== `tab-${t}`));
  if (t === 'chat') { const log = $('#chatLog'); log.scrollTop = log.scrollHeight; }
  if (t === 'notes') requestAnimationFrame(() => $$('#tab-notes textarea').forEach(growNote));
}
const panelTabs = $$('.tabs button');
panelTabs.forEach(b => b.onclick = () => switchTab(b.dataset.tab));
$('.tabs').addEventListener('keydown', event => {
  const index = panelTabs.indexOf(event.target);
  if (index === -1 || event.altKey || event.ctrlKey || event.metaKey) return;
  let next;
  if (event.key === 'ArrowLeft') next = (index + panelTabs.length - 1) % panelTabs.length;
  else if (event.key === 'ArrowRight') next = (index + 1) % panelTabs.length;
  else if (event.key === 'Home') next = 0;
  else if (event.key === 'End') next = panelTabs.length - 1;
  else return;
  event.preventDefault();
  switchTab(panelTabs[next].dataset.tab);
  panelTabs[next].focus();
});
panelToggle.onclick = () => {
  const open = panel.classList.contains('collapsed');
  showPanel(open);
  store(prefKey(), String(open));
  if (open) $('.tabs [aria-selected="true"]').focus({ preventScroll: true });
};
$('#reader').addEventListener('keydown', event => {
  if (event.key !== 'Escape' || event.defaultPrevented || event.isComposing || panel.classList.contains('collapsed')) return;
  if (!panel.contains(event.target) && event.target !== splitter && event.target !== panelToggle) return;
  event.preventDefault();
  showPanel(false);
});

// An error inside a panel: message, retry, raw detail behind "자세히".
export function showPanelRetry(el, err, retry) {
  const wrap = document.createElement('div');
  wrap.className = 'empty';
  wrap.append(errorBlock(err, { retry, role: 'status' }));
  el.replaceChildren(wrap);
}

// splitter between the paper and the panel: drag to resize, double-click / Enter for the default width
const PANEL_W = 400;
let panelW = +read('sl.panelW') || PANEL_W;
const maxPanelWidth = () => Math.max(300, innerWidth - 360);
function setPanelWidth(w) {
  panelW = Math.round(Math.max(300, Math.min(w, maxPanelWidth())));
  panel.style.setProperty('--panel-w', `${panelW}px`);
  splitter.setAttribute('aria-valuemin', '300');
  splitter.setAttribute('aria-valuemax', String(maxPanelWidth()));
  splitter.setAttribute('aria-valuenow', String(panelW));
  splitter.setAttribute('aria-valuetext', `${panelW} 픽셀`);
}
setPanelWidth(panelW);
window.addEventListener('resize', () => setPanelWidth(+read('sl.panelW') || PANEL_W));
splitter.addEventListener('pointerdown', e => {
  if (e.button !== 0) return;
  e.preventDefault();
  const right = panel.getBoundingClientRect().right;
  splitter.setPointerCapture(e.pointerId);
  splitter.classList.add('drag'); document.body.classList.add('resizing');
  const move = ev => setPanelWidth(right - ev.clientX);
  const up = () => {
    splitter.removeEventListener('pointermove', move); splitter.removeEventListener('pointerup', up); splitter.removeEventListener('pointercancel', up);
    splitter.classList.remove('drag'); document.body.classList.remove('resizing');
    store('sl.panelW', panelW);
  };
  splitter.addEventListener('pointermove', move); splitter.addEventListener('pointerup', up); splitter.addEventListener('pointercancel', up);
});
splitter.addEventListener('dblclick', () => { setPanelWidth(PANEL_W); store('sl.panelW', panelW); });
splitter.addEventListener('keydown', event => {
  if (event.altKey || event.ctrlKey || event.metaKey) return;
  const widths = { ArrowLeft: panelW + 24, ArrowRight: panelW - 24, Home: 300, End: maxPanelWidth(), Enter: PANEL_W };
  if (!Object.hasOwn(widths, event.key)) return;
  event.preventDefault();
  setPanelWidth(widths[event.key]);
  store('sl.panelW', panelW);
});
