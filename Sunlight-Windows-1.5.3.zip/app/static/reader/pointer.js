// The paper's only scroll and mousemove listeners. Both are coalesced to one pass per frame,
// and page rectangles are measured at most once per frame (layout.rectOf).
import { $ } from './state.js';
import { invalidateRects } from './layout.js';
import { hoverMove, hidePops, hideChip, resetHover, showSelPop } from './selection.js';
import { positionScrolled, updatePageIndicator } from './navigation.js';
import { positionExplanation } from './explain.js';
import { closeHighlightPopover } from './notes.js';

const viewer = $('#viewer');
let scrollFrame = 0, popT = 0, refocus = false;
viewer.addEventListener('scroll', () => {
  invalidateRects();
  positionScrolled();
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    // a keyboard user on the selection toolbar gets it back (and the focus) when scrolling stops
    if ($('#selPop').contains(document.activeElement)) { refocus = true; viewer.focus({ preventScroll: true }); }
    hideChip(); resetHover(); hidePops(); closeHighlightPopover(false);
    positionExplanation();
    updatePageIndicator();
    clearTimeout(popT);
    popT = setTimeout(() => { showSelPop(refocus); refocus = false; }, 160);
  });
}, { passive: true });

let moveFrame = 0, lastMove = null;
viewer.addEventListener('mousemove', ev => {
  lastMove = ev;
  if (moveFrame) return;
  moveFrame = requestAnimationFrame(() => {
    moveFrame = 0;
    if (lastMove) hoverMove(lastMove);
  });
});
