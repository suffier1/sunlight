// Pure text matching for in-document search (no DOM; covered by a node probe).
export const normalize = s => String(s ?? '').normalize('NFKC').replace(/\s+/g, ' ').toLowerCase();
// specs: where to look in each block and which page column shows it, e.g.
//   [{ field: 'text', kind: 'original' }]                          원문
//   [{ field: 'tr', kind: 'translated', fallback: 'text' }]        번역 (untranslated blocks keep the original)
// (a plain field name is accepted: 'text' → original, 'tr' → translated)
// → one hit per occurrence: [{block, field, kind, at, nth}] in reading order
export function findMatches(blocks, query, specs = ['text', 'tr'], limit = 2000) {
  const q = normalize(query).trim();
  if (q.length < 1) return [];
  specs = specs.map(s => (typeof s === 'string' ? { field: s, kind: s === 'tr' ? 'translated' : 'original' } : s));
  const out = [];
  for (const block of blocks) {
    for (const spec of specs) {
      let field = spec.field, t = block[field];
      if ((typeof t !== 'string' || !t) && spec.fallback) { field = spec.fallback; t = block[field]; }
      if (typeof t !== 'string' || !t) continue;
      const hay = normalize(t);
      for (let at = hay.indexOf(q), nth = 0; at >= 0; at = hay.indexOf(q, at + q.length), nth++) {
        out.push({ block, field, kind: spec.kind, at, nth });
        if (out.length >= limit) return out;
      }
    }
  }
  return out;
}
// A short excerpt around the match at `at` (default: the first one): [before, match, after]
export function snippet(text, query, radius = 40, at = -1) {
  const flat = String(text ?? '').normalize('NFKC').replace(/\s+/g, ' ');
  const q = normalize(query).trim().length;
  const i = at >= 0 ? at : flat.toLowerCase().indexOf(normalize(query).trim());
  if (i < 0) return [flat.slice(0, radius * 2), '', ''];
  const start = Math.max(0, i - radius);
  return [(start ? '…' : '') + flat.slice(start, i), flat.slice(i, i + q), flat.slice(i + q, i + q + radius) + (i + q + radius < flat.length ? '…' : '')];
}
// Outline from headings when the PDF has none: skip the title page block before the first
// Abstract/Introduction, numeric-only or very short lines; prefer numbered headings when there are ≥3.
export function headingOutline(blocks, max = 200) {
  const heads = blocks.filter(b => b.kind === 'heading' && typeof b.text === 'string')
    .map(b => ({ b, t: b.text.replace(/\s+/g, ' ').trim() }))
    .filter(({ t }) => t.length >= 3 && !/^[\d\s.,:;()\-–—ivxlc]+$/i.test(t) && /[A-Za-z가-힣]{2}/.test(t));
  const start = heads.findIndex(({ t }) => /^(\d+(\.\d+)*\.?\s*)?(abstract|introduction|초록|요약|서론)\b/i.test(t));
  let list = start > 0 ? heads.slice(start) : heads;
  const numbered = list.filter(({ t }) => /^(\d+(\.\d+)*\.?|[IVX]+\.|[A-Z]\.)\s+\S/.test(t));
  if (numbered.length >= 3) list = list.filter(x => numbered.includes(x) || /^(abstract|references|acknowledg|appendix|초록|참고 문헌)/i.test(x.t));
  return list.slice(0, max).map(({ b, t }) => ({
    b, title: t.slice(0, 120), depth: /^\d+\.\d+/.test(t) ? 1 : 0,
  }));
}
