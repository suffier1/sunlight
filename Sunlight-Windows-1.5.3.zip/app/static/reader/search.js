// In-document search (Ctrl+F) over the paper's text blocks, and the outline (목차).
// Owns S.search and S.outline. Hits are drawn per page as boxes in the page's block layer.
import { api } from '../ui-kit.js';
import { S, $, $$, live, readerShown, modalOpen } from './state.js';
import { normalize, findMatches, snippet, headingOutline } from './search-match.js';
import { gotoPage, readingGesture } from './navigation.js';
import { rectOf } from './layout.js';
import { resolveDest } from './links.js';

/* ---------------------------------------------------------------- data */
// GET /search-index covers every text block (contract §6); an older server falls back to /blocks.
async function loadIndex(sess) {
  const version = S.paper?.translated_version ?? 0;
  if (S.search.index && S.search.indexVersion === version) return S.search.index;
  let blocks;
  try {
    const r = await api(`/api/papers/${S.paper.id}/search-index`, { signal: sess.signal, timeout: 15000 });
    blocks = Array.isArray(r?.blocks) ? r.blocks : null;
  } catch (e) {
    if (!live(sess)) throw e;
    if (e.status !== 404 && e.status !== 405) throw e;
  }
  if (!live(sess)) return null;
  blocks ??= S.blocks;
  const order = new Map(S.blocks.map((b, i) => [b.id, i]));
  blocks = [...blocks].sort((a, b) => a.page - b.page || (order.get(a.id) ?? 1e9) - (order.get(b.id) ?? 1e9) || a.bbox[1] - b.bbox[1]);
  S.search.index = blocks; S.search.indexVersion = version;
  return blocks;
}
// What is on screen: 원문 → original text; 번역 → translation (original where a block has none); 병렬 → both.
const ORIGINAL = { field: 'text', kind: 'original' }, TRANSLATED = { field: 'tr', kind: 'translated', fallback: 'text' };
const shownSpecs = () => (S.mode === 'original' || !S.docs.translated ? [ORIGINAL] : S.mode === 'translated' ? [TRANSLATED] : [ORIGINAL, { field: 'tr', kind: 'translated' }]);

/* ---------------------------------------------------------------- UI */
const bar = $('#searchBar'), input = $('#docSearch'), count = $('#searchCount'), list = $('#searchResults');
export function resetSearch() {
  S.search = { index: null, indexVersion: -1, hits: [], current: -1, query: '' };
  S.outline = null;
  closeSearch(false);
  $('#outlineBtn').hidden = true;
  closeOutline(false);
}
export function openSearch() {
  if (!S.paper || !S.docs.original) return;
  bar.hidden = false;
  $('#searchBtn').setAttribute('aria-expanded', 'true');
  input.focus(); input.select();
  if (input.value.trim()) runSearch();
}
export function closeSearch(restore = true) {
  if (bar.hidden) return;
  bar.hidden = true;
  list.hidden = true;
  $('#searchListToggle').setAttribute('aria-expanded', 'false');
  $('#searchBtn').setAttribute('aria-expanded', 'false');
  S.search.hits = []; S.search.current = -1;
  drawSearchHits();
  if (restore) $('#viewer').focus({ preventScroll: true });
}
let searchT = 0;
input.addEventListener('input', () => { clearTimeout(searchT); searchT = setTimeout(runSearch, 160); });
input.addEventListener('keydown', e => {
  if (e.key === 'Enter') { e.preventDefault(); if (S.search.query !== input.value) runSearch().then(() => step(0)); else step(e.shiftKey ? -1 : 1); }
  else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeSearch(); }
  else if (e.key === 'ArrowDown' && !list.hidden) { e.preventDefault(); $('button', list)?.focus(); }
});
$('#searchNext').onclick = () => step(1);
$('#searchPrev').onclick = () => step(-1);
$('#searchClose').onclick = () => closeSearch();
$('#searchListToggle').onclick = () => {
  list.hidden = !list.hidden;
  $('#searchListToggle').setAttribute('aria-expanded', String(!list.hidden));
};
list.addEventListener('click', e => {
  const b = e.target.closest('button[data-hit]');
  if (b) { go(+b.dataset.hit); }
});
list.addEventListener('keydown', e => {
  const buttons = $$('button', list), i = buttons.indexOf(document.activeElement);
  if (e.key === 'ArrowDown') { e.preventDefault(); buttons[Math.min(i + 1, buttons.length - 1)]?.focus(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); if (i <= 0) input.focus(); else buttons[i - 1].focus(); }
  else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); list.hidden = true; input.focus(); }
});
bar.addEventListener('keydown', e => { if (e.key === 'Escape' && !e.defaultPrevented) { e.preventDefault(); closeSearch(); } });

async function runSearch() {
  const sess = S.sess, query = input.value;
  S.search.query = query;
  if (!query.trim()) { S.search.hits = []; S.search.current = -1; count.textContent = ''; list.replaceChildren(); drawSearchHits(); return; }
  count.textContent = '찾는 중';
  let blocks;
  try { blocks = await loadIndex(sess); } catch { if (live(sess)) count.textContent = '본문을 불러오지 못했습니다'; return; }
  if (!live(sess) || S.search.query !== query || !blocks) return;
  const hits = findMatches(blocks, query, shownSpecs());
  S.search.hits = hits;
  S.search.current = hits.length ? Math.max(0, hits.findIndex(h => h.block.page >= currentPage())) : -1;
  count.textContent = hits.length ? `${S.search.current + 1} / ${hits.length}` : '결과 없음';
  renderList(query);
  drawSearchHits();
}
function currentPage() { return +($('#pageInput').value || 1) - 1; }
function renderList(query) {
  const hits = S.search.hits.slice(0, 300);
  list.replaceChildren(...hits.map((h, i) => {
    const li = document.createElement('li');
    const b = document.createElement('button');
    b.type = 'button'; b.dataset.hit = i;
    const [pre, mid, post] = snippet(h.block[h.field], query, 40, h.at);
    const where = document.createElement('span'); where.className = 'where';
    where.textContent = `${h.block.page + 1}쪽${h.kind === 'translated' ? ' · 번역' : ''}`;
    const m = document.createElement('mark'); m.textContent = mid;
    b.append(where, pre, m, post);
    li.append(b);
    return li;
  }));
  if (S.search.hits.length > 300) {
    const li = document.createElement('li'); li.className = 'more'; li.textContent = `처음 300개만 표시합니다. 검색어를 더 구체적으로 입력하세요.`;
    list.append(li);
  }
}
function step(dir) {
  const n = S.search.hits.length;
  if (!n) return;
  go(((S.search.current + dir) % n + n) % n);
}
function go(i) {
  const h = S.search.hits[i];
  if (!h) return;
  S.search.current = i;
  count.textContent = `${i + 1} / ${S.search.hits.length}`;
  $$('button[aria-current]', list).forEach(b => b.removeAttribute('aria-current'));
  $(`button[data-hit="${i}"]`, list)?.setAttribute('aria-current', 'true');
  const ph = S.pageSizes[h.block.page]?.h || 792;
  readingGesture();
  gotoPage(h.block.page, Math.max(0, h.block.bbox[1] / ph - 0.05));
  drawSearchHits();
}

// Draw the hits on one slot (after it renders) or on every slot: the matching words on the text
// layer (the current one stronger); a box around the paragraph only where the words are split across
// text runs and cannot be marked one by one.
export function drawSearchHits(slot) {
  const slots = slot ? [slot] : S.slots;
  const hits = S.search?.hits || [];
  const cur = hits[S.search?.current];
  const q = normalize(S.search?.query || '').trim();
  for (const s of slots) {
    $$('.search-hit', s.el).forEach(x => x.remove());
    $$('.textLayer .search-span', s.el).forEach(x => x.classList.remove('search-span', 'current'));
    const mine = hits.filter(h => h.block.page === s.i && h.kind === s.docKind);
    if (!mine.length || !q) continue;
    const spans = $$('.textLayer span', s.el).filter(sp => !sp.childElementCount && normalize(sp.textContent).includes(q));
    const r = spans.length ? rectOf(s) : null;
    const inBlock = (sp, bb) => {
      const sr = sp.getBoundingClientRect(), x = (sr.left + sr.width / 2 - r.left) / S.scale, y = (sr.top + sr.height / 2 - r.top) / S.scale;
      return x >= bb[0] - 2 && x <= bb[2] + 2 && y >= bb[1] - 2 && y <= bb[3] + 2;
    };
    const layer = $('.blk-layer', s.el);
    for (const block of new Set(mine.map(h => h.block))) {
      const marks = spans.filter(sp => inBlock(sp, block.bbox));
      marks.forEach(sp => sp.classList.add('search-span'));
      const isCur = cur?.block === block && cur.kind === s.docKind;
      if (isCur && marks.length) (marks[Math.min(cur.nth, marks.length - 1)]).classList.add('current');
      if (marks.length) continue;
      const bb = block.bbox, d = document.createElement('div');
      d.className = `search-hit${isCur ? ' current' : ''}`;
      Object.assign(d.style, { left: `${bb[0] * S.scale - 2}px`, top: `${bb[1] * S.scale - 2}px`, width: `${(bb[2] - bb[0]) * S.scale + 4}px`, height: `${(bb[3] - bb[1]) * S.scale + 4}px` });
      layer?.append(d);
    }
  }
}
document.addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey || e.key.toLowerCase() !== 'f' || !readerShown() || modalOpen()) return;
  e.preventDefault();
  openSearch();
});
$('#searchBtn').onclick = () => (bar.hidden ? openSearch() : closeSearch());

/* ---------------------------------------------------------------- outline */
async function flattenOutline(doc, items, depth, out, sess) {
  for (const it of items || []) {
    if (out.length >= 400 || !live(sess)) return;
    const at = it.dest ? await resolveDest(doc, it.dest) : null;
    if (at && it.title?.trim()) out.push({ title: it.title.trim(), page: at.page, y: at.y, depth });
    if (depth < 2) await flattenOutline(doc, it.items, depth + 1, out, sess);
  }
}
// pdf.js outline first; papers without one get their headings from the search index.
export async function loadOutline(sess) {
  const doc = S.docs.original;
  if (!doc) return;
  let entries = [];
  try { await flattenOutline(doc, await doc.getOutline(), 0, entries, sess); } catch { entries = []; }
  if (!live(sess)) return;
  if (!entries.length) {
    const blocks = await loadIndex(sess).catch(() => null);
    if (!live(sess)) return;
    entries = headingOutline(blocks || [])
      .map(({ b, title, depth }) => ({ title, page: b.page, y: Math.max(0, b.bbox[1] / (S.pageSizes[b.page]?.h || 792) - 0.03), depth }));
  }
  S.outline = entries;
  $('#outlineBtn').hidden = !entries.length;
}
const outlineMenu = $('#outlineMenu');
function openOutline() {
  if (!S.outline?.length) return;
  outlineMenu.replaceChildren(...S.outline.map(o => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = `depth-${o.depth}`; b.setAttribute('role', 'menuitem');
    b.textContent = o.title;
    const pg = document.createElement('span'); pg.className = 'pg'; pg.textContent = `${o.page + 1}`; pg.setAttribute('aria-label', `${o.page + 1}쪽`);
    b.append(pg);
    b.onclick = () => { closeOutline(false); gotoPage(o.page, o.y); $('#viewer').focus({ preventScroll: true }); };
    return b;
  }));
  outlineMenu.hidden = false;
  $('#outlineBtn').setAttribute('aria-expanded', 'true');
  const cur = currentPage();
  const items = $$('button', outlineMenu);
  const here = S.outline.findLastIndex(o => o.page <= cur);
  (items[Math.max(0, here)] || items[0])?.focus();
}
export function closeOutline(restore = true) {
  if (outlineMenu.hidden) return;
  outlineMenu.hidden = true;
  $('#outlineBtn').setAttribute('aria-expanded', 'false');
  if (restore) $('#outlineBtn').focus();
}
$('#outlineBtn').onclick = () => (outlineMenu.hidden ? openOutline() : closeOutline());
outlineMenu.addEventListener('keydown', e => {
  const items = $$('button', outlineMenu), i = items.indexOf(document.activeElement);
  if (e.key === 'ArrowDown') { e.preventDefault(); items[Math.min(i + 1, items.length - 1)]?.focus(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); items[Math.max(i - 1, 0)]?.focus(); }
  else if (e.key === 'Home') { e.preventDefault(); items[0]?.focus(); }
  else if (e.key === 'End') { e.preventDefault(); items.at(-1)?.focus(); }
  else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeOutline(); }
});
document.addEventListener('pointerdown', e => {
  if (!outlineMenu.hidden && !outlineMenu.contains(e.target) && e.target.closest('#outlineBtn') == null) closeOutline(false);
});
outlineMenu.addEventListener('focusout', e => { if (e.relatedTarget && !outlineMenu.contains(e.relatedTarget) && e.relatedTarget.id !== 'outlineBtn') closeOutline(false); });

resetSearch();
