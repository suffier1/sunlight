/* Selection, the selection toolbar, hover hints and the region tool. Owns S.sel, S.region, S.regionSel.
 * Ways to select, all ending in the same toolbar (번역 · 설명 · 질문 · 색 · 복사):
 *   drag            → any span of text, across lines, paragraphs, columns and pages
 *   triple-click / ¶ chip → the whole paragraph;  Shift+click → add / remove more paragraphs
 *   click           → a figure, table or equation (sent to the AI as an image)
 *   keyboard        → Enter in the paper selects the paragraph at the top; Alt+↑/↓ moves, Shift+Alt extends
 * Selected text is re-extracted by the server because pdf.js garbles some fonts (ligatures, custom encodings). */
import { api, esc, toast, errorText, dismissToast } from '../ui-kit.js';
import { S, $, $$, live } from './state.js';
import { slotOf, drawSelBox, clearSelBoxes, intersects, rectOf, invalidateRects } from './layout.js';
import { engineName, shortcutsEnabled } from '../settings.js';
import { showExplanation, closeExplanation, explanationOpen, showQuick, closeQuick } from './explain.js';
import { addHighlightFromSelection, highlightAt, openHighlightPopover, ensureHighlight, focusNote } from './notes.js';
import { switchTab, showPanel } from './panel.js';
import { setChatCtx } from './chat.js';
import { readingGesture } from './navigation.js';

const viewer = $('#viewer'), selPop = $('#selPop'), regionPop = $('#regionPop');

/* ---------------------------------------------------------------- pdf.js selection fix */
// Keep the "end of content" sentinel right after the selection anchor, otherwise dragging over gaps
// between text spans makes Chrome jump the selection to unrelated text.
let prevRange = null;
function resetTextLayer(div, end) {
  div.append(end);
  end.style.width = ''; end.style.height = '';
  div.classList.remove('selecting');
}
document.addEventListener('pointerup', () => { for (const [div, end] of S.textLayers) resetTextLayer(div, end); });
document.addEventListener('selectionchange', () => {
  if (!S.textLayers.size) return;
  const sel = document.getSelection();
  if (!sel.rangeCount) { for (const [div, end] of S.textLayers) resetTextLayer(div, end); return; }
  const active = new Set();
  for (let k = 0; k < sel.rangeCount; k++) {
    const r = sel.getRangeAt(k);
    for (const div of S.textLayers.keys()) if (!active.has(div) && r.intersectsNode(div)) active.add(div);
  }
  for (const [div, end] of S.textLayers) {
    if (active.has(div)) div.classList.add('selecting'); else resetTextLayer(div, end);
  }
  const range = sel.getRangeAt(0);
  const modifyStart = prevRange && (range.compareBoundaryPoints(Range.END_TO_END, prevRange) === 0
    || range.compareBoundaryPoints(Range.START_TO_END, prevRange) === 0);
  let anchor = modifyStart ? range.startContainer : range.endContainer;
  if (anchor.nodeType === Node.TEXT_NODE) anchor = anchor.parentNode;
  const layer = anchor.parentElement?.closest('.textLayer');
  const end = S.textLayers.get(layer);
  if (end && anchor.parentElement) {
    end.style.width = layer.style.width; end.style.height = layer.style.height;
    anchor.parentElement.insertBefore(end, modifyStart ? anchor : anchor.nextSibling);
  }
  prevRange = range.cloneRange();
});

/* ---------------------------------------------------------------- popups */
export function hidePops() { selPop.classList.add('hidden'); regionPop.classList.add('hidden'); }
function placePop(pop, x, y) {
  pop.classList.remove('hidden');
  pop.style.left = `${Math.max(8, Math.min(x - pop.offsetWidth / 2, innerWidth - pop.offsetWidth - 8))}px`;
  const above = y - pop.offsetHeight - 10;
  pop.style.top = `${Math.max(8, Math.min(above >= 8 ? above : y + 24, innerHeight - pop.offsetHeight - 8))}px`;
}
// The data-sending notice is shown in the toolbar until the first AI action; afterwards it stays as
// the buttons' description (tooltip + aria-describedby).
const SCOPE_SEEN = 'sl.scopeSeen';
const scopeSeen = () => { try { return localStorage.getItem(SCOPE_SEEN) === '1'; } catch { return false; } };
function markScopeSeen() { try { localStorage.setItem(SCOPE_SEEN, '1'); } catch { /* shown again next time */ } }
function scopeText(s) {
  const provider = engineName();
  if (s.source === 'object') return `번역은 영역 속 글을, 설명은 영역 이미지와 해당 쪽 본문을 ${provider}에 보냅니다. 논문 제목도 함께 보냅니다.`;
  if (s.kind === 'translated') return `설명을 누르면 선택한 글과 해당 쪽 원문, 논문 제목을 ${provider}에 보냅니다.`;
  return `번역·설명을 누르면 논문 제목과 선택한 글을 ${provider}에 보냅니다. 단어 번역에는 주변 문맥, 설명에는 해당 쪽 본문이 포함됩니다.`;
}
export function refreshScopes() {
  $('#regionScope').textContent = `설명을 누르면 영역 이미지와 해당 쪽 본문, 논문 제목을 ${engineName()}에 보냅니다.`;
  if (!selPop.classList.contains('hidden')) showSelPop();
}
function paintKeyHints() {
  const on = shortcutsEnabled();
  $$('#selPop [data-key]').forEach(b => {
    const k = b.dataset.key;
    $('.key', b).hidden = !on;
    if (on) b.setAttribute('aria-keyshortcuts', k); else b.removeAttribute('aria-keyshortcuts');
  });
}
// re-show the toolbar over the current selection (after scrolling, or once clean text arrives)
export function showSelPop(focus = false) {
  const s = S.sel;
  if (!s || explanationOpen() || viewer.inert) return;
  const slot = slotOf(s.anchor.page, s.kind);
  if (!slot) return;
  const pr = rectOf(slot);
  const b = s.anchor.bbox;
  const x = pr.left + ((b[0] + b[2]) / 2) * S.scale, y = pr.top + b[1] * S.scale;
  const vr = viewer.getBoundingClientRect();
  if (y < vr.top - 4 || y > vr.bottom - 10) { hidePops(); return; }
  // on a translated page the useful "translation" is the original text
  const localOriginal = s.kind === 'translated' && s.source !== 'object';
  const tb = $('#selPop [data-a="translate"]');
  $('.label', tb).textContent = localOriginal ? '원문' : '번역';
  const scope = scopeText(s);
  $('#selectionScope').textContent = scope;
  $('#selectionScope').hidden = scopeSeen();
  $$('#selPop [data-ai]').forEach(btn => { btn.title = `${btn.dataset.title} — ${scope}`; });
  if (localOriginal) tb.removeAttribute('aria-describedby'); else tb.setAttribute('aria-describedby', 'selectionScope');
  paintKeyHints();
  placePop(selPop, x, y);
  if (focus) $('button', selPop).focus({ preventScroll: true });
}
// toolbar keyboard: arrows move between buttons (one tab stop), Esc returns to the paper
for (const pop of [selPop, regionPop]) {
  pop.addEventListener('keydown', e => {
    const buttons = $$('button', pop).filter(b => b.offsetParent);
    const i = buttons.indexOf(document.activeElement);
    if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
      e.preventDefault();
      buttons[(i + (e.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length]?.focus();
    } else if (e.key === 'Home' || e.key === 'End') {
      e.preventDefault(); (e.key === 'Home' ? buttons[0] : buttons.at(-1))?.focus();
    } else if (e.key === 'Escape') {
      e.preventDefault(); e.stopPropagation(); clearSelection(); viewer.focus({ preventScroll: true });
    } else if (e.altKey && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      e.preventDefault(); stepParagraph(e.key === 'ArrowDown' ? 1 : -1, e.shiftKey);
    }
  });
}
export function clearSelection() {
  hidePops(); clearSelBoxes(); S.sel = null; window.getSelection().removeAllRanges();
  closeQuick();
  if (S.region) toggleRegion();
}
// After a re-layout: paragraph/object boxes follow the new scale, the toolbar follows its anchor.
export function redrawSelection() {
  const s = S.sel;
  clearSelBoxes('.para'); clearSelBoxes('.obj');
  if (!s || s.source === 'text') { if (s && !selPop.classList.contains('hidden')) showSelPop(); return; }
  const style = s.source === 'object' ? 'obj' : 'para';
  for (const part of s.parts) {
    const slot = slotOf(part.page, s.kind);
    if (slot) part.boxes.forEach(box => drawSelBox(slot, box, style));
  }
  if (!selPop.classList.contains('hidden')) showSelPop();
}

function originalsFor(parts) {  // original-language paragraphs under the selection (context for the AI)
  const out = [], seen = new Set();
  for (const { page, boxes } of parts)
    for (const b of S.blocksByPage.get(page) || []) if (boxes.some(x => intersects(x, b.bbox)) && !seen.has(b.text)) {
      seen.add(b.text); out.push(b.text);
    }
  return out.join('\n');
}
function setSel(sel, focus = false) {
  S.sel = sel;
  sel.textPromise = sel.textPromise || Promise.resolve(sel.text);
  showSelPop(focus);
}

// A range's client rects overlap (one per text span *and* per text node); drawn semi-transparent they
// stack into darker patches. Fold them into one box per line.
export function mergeBoxes(boxes) {
  const lines = [];
  for (const b of [...boxes].sort((p, q) => (p[1] + p[3]) - (q[1] + q[3]) || p[0] - q[0])) {
    const h = b[3] - b[1];
    const line = lines.find(l => Math.min(l.y1, b[3]) - Math.max(l.y0, b[1]) > Math.min(l.y1 - l.y0, h) * 0.5);
    if (line) { line.boxes.push(b); line.y0 = Math.min(line.y0, b[1]); line.y1 = Math.max(line.y1, b[3]); }
    else lines.push({ y0: b[1], y1: b[3], boxes: [b] });
  }
  const out = [];
  for (const l of lines) {
    let cur = null;
    for (const b of l.boxes.sort((p, q) => p[0] - q[0])) {
      if (cur && b[0] <= cur[2] + (l.y1 - l.y0) * 0.6) cur[2] = Math.max(cur[2], b[2]);
      else { cur = [b[0], l.y0, b[2], l.y1]; out.push(cur); }
    }
  }
  return out;
}

function selectFromRange() {
  const sel = window.getSelection();
  const raw = sel.toString().replace(/\s+/g, ' ').trim();
  if (!raw || !sel.rangeCount) return false;
  const range = sel.getRangeAt(0);
  const startPage = (range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement)?.closest('.page');
  if (!startPage) return false;
  const endPage = (range.endContainer.nodeType === 1 ? range.endContainer : range.endContainer.parentElement)?.closest('.page');
  const { docKind: kind, i: firstPage } = startPage._slot;
  const lastPage = endPage?._slot.i ?? Infinity;
  const parts = new Map();  // page index → PDF-point boxes
  const clientRects = [...range.getClientRects()].filter(r => r.width > 1 && r.height > 1);
  for (const slot of S.slots) {
    if (slot.docKind !== kind || slot.i < firstPage || slot.i > lastPage) continue;
    const pr = slot.el.getBoundingClientRect();
    for (const r of clientRects) {
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      if (cx < pr.left || cx > pr.right || cy < pr.top || cy > pr.bottom) continue;
      const box = [(r.left - pr.left) / S.scale, (r.top - pr.top) / S.scale, (r.right - pr.left) / S.scale, (r.bottom - pr.top) / S.scale];
      if (!parts.has(slot.i)) parts.set(slot.i, []);
      parts.get(slot.i).push(box);
    }
  }
  if (!parts.size) return false;
  const list = [...parts].map(([page, boxes]) => ({ page, boxes: mergeBoxes(boxes) }));
  const first = list[0];
  const anchorBox = first.boxes.reduce((a, b) => [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[2], b[2]), Math.max(a[3], b[3])]);
  // The PDF.js fallback keeps original writing systems when the extracted text is unavailable.
  const strip = t => t.replace(/[-]/g, '');
  const fallback = strip(raw);
  const rawOf = page => {
    const el = S.slots.find(s => s.i === page && s.docKind === kind)?.el, tl = el && $('.textLayer', el);
    if (!tl) return '';
    const r = document.createRange();
    r.selectNodeContents(tl);
    if (range.compareBoundaryPoints(Range.START_TO_START, r) > 0) r.setStart(range.startContainer, range.startOffset);
    if (range.compareBoundaryPoints(Range.END_TO_END, r) < 0) r.setEnd(range.endContainer, range.endOffset);
    return strip(r.toString().replace(/\s+/g, ' ').trim());
  };
  const sess = S.sess;
  const texts = Promise.all(list.map(p => {
    const own = rawOf(p.page);
    return api(`/api/papers/${S.paper.id}/text`, {
      method: 'POST', signal: sess.signal, timeout: 6000,
      body: { kind, page: p.page, rects: p.boxes.map(b => [b[0] - 1, b[1] - 1, b[2] + 1, b[3] + 1]) },
    }).then(r => r.text || own, () => own);
  }));
  const textPromise = texts.then(ts => ts.filter(Boolean).join(' ') || fallback);
  setSel({
    source: 'text', kind, text: raw, textPromise, parts: list, anchor: { page: first.page, bbox: anchorBox },
    context: originalsFor(list),
    pageTexts: texts.then(ts => Object.fromEntries(list.map((p, k) => [p.page, ts[k]]))),
  });
  textPromise.then(t => { if (S.sel?.textPromise === textPromise) S.sel.text = t; });
  return true;
}

function paraSelection(paras, kind, focus = false) {
  clearSelBoxes();
  window.getSelection().removeAllRanges();
  const order = S.blockOrder;  // the server's paragraph order follows the columns
  paras.sort((a, b) => a.page - b.page || (order.get(a) ?? 0) - (order.get(b) ?? 0));
  for (const b of paras) { const sl = slotOf(b.page, kind); if (sl) drawSelBox(sl, b.bbox, 'para'); }
  const textOf = b => (kind === 'translated' && b.tr) || b.text;
  const text = paras.map(textOf).join('\n\n');
  const byPage = new Map();
  for (const b of paras) { if (!byPage.has(b.page)) byPage.set(b.page, []); byPage.get(b.page).push(b); }
  setSel({
    source: 'para', kind, text, paras, anchor: { page: paras[0].page, bbox: paras[0].bbox },
    parts: [...byPage].map(([page, bs]) => ({ page, boxes: bs.map(b => b.bbox) })),
    context: kind === 'translated' ? paras.map(b => b.text).join('\n\n') : '',
    pageTexts: Promise.resolve(Object.fromEntries([...byPage].map(([page, bs]) => [page, bs.map(textOf).join('\n\n')]))),
  }, focus);
}

const OBJ_NAME = { figure: '그림', table: '표', equation: '수식' };
function objectSelection(slot, obj, focus = false) {
  clearSelBoxes();
  window.getSelection().removeAllRanges();
  drawSelBox(slot, obj.bbox, 'obj');
  const label = OBJ_NAME[obj.kind] || '영역';
  const textPromise = api(`/api/papers/${S.paper.id}/text`, {
    method: 'POST', signal: S.sess.signal, body: { kind: 'original', page: obj.page, rects: [obj.bbox] },
  }).then(r => r.text).catch(() => '');
  setSel({
    source: 'object', kind: slot.docKind, label, obj, text: `[${label} · p.${obj.page + 1}]`, textPromise,
    anchor: { page: obj.page, bbox: obj.bbox }, parts: [{ page: obj.page, boxes: [obj.bbox] }],
    region: { page: obj.page, rect: obj.bbox, kind: slot.docKind }, thumb: cropThumb(slot.el, obj.bbox),
  }, focus);
}
function cropThumb(pageEl, bbox) {
  const cv = $('canvas', pageEl);
  if (!cv) return null;
  const k = cv.width / pageEl.getBoundingClientRect().width * S.scale;
  const c = document.createElement('canvas');
  c.width = Math.max(1, (bbox[2] - bbox[0]) * k); c.height = Math.max(1, (bbox[3] - bbox[1]) * k);
  c.getContext('2d').drawImage(cv, bbox[0] * k, bbox[1] * k, c.width, c.height, 0, 0, c.width, c.height);
  return c.toDataURL('image/png');
}

export function pointPdf(slot, ev) {
  const r = rectOf(slot);
  return [(ev.clientX - r.left) / S.scale, (ev.clientY - r.top) / S.scale];
}
export function paraAt(slot, ev) {
  const [x, y] = pointPdf(slot, ev);
  return (S.blocksByPage.get(slot.i) || []).find(b => x >= b.bbox[0] - 2 && x <= b.bbox[2] + 2 && y >= b.bbox[1] - 2 && y <= b.bbox[3] + 2);
}
export function objectAt(slot, ev) {
  const [x, y] = pointPdf(slot, ev);
  let best, bestArea = Infinity;
  for (const o of S.objectsByPage.get(slot.i) || []) {
    if (!(x >= o.bbox[0] && x <= o.bbox[2] && y >= o.bbox[1] && y <= o.bbox[3])) continue;
    const area = (o.bbox[2] - o.bbox[0]) * (o.bbox[3] - o.bbox[1]);
    if (!best || area < bestArea) { best = o; bestArea = area; }
  }
  return best;
}
function blockAt(slot, ev) {
  const [x, y] = pointPdf(slot, ev);
  return (S.blocksByPage.get(slot.i) || []).find(b => b.tr && x >= b.bbox[0] && x <= b.bbox[2] && y >= b.bbox[1] && y <= b.bbox[3]);
}

/* ---------------------------------------------------------------- keyboard paragraph / figure selection */
function readingUnits(kind) {
  const units = [];
  for (const b of S.blocks) units.push({ b, page: b.page, y: b.bbox[1] });
  for (const list of S.objectsByPage.values()) for (const o of list) units.push({ o, page: o.page, y: o.bbox[1] });
  const order = S.blockOrder;
  units.sort((p, q) => p.page - q.page || (p.b && q.b ? (order.get(p.b) ?? 0) - (order.get(q.b) ?? 0) : p.y - q.y));
  return units.filter(u => slotOf(u.page, kind));
}
function selectUnit(u, kind, extend = false) {
  readingGesture();
  // bring it into view first so the toolbar can open (and take focus) next to it
  const slot = slotOf(u.page, kind), bbox = u.o?.bbox || u.b.bbox;
  const r = slot.el.getBoundingClientRect(), vr = viewer.getBoundingClientRect();
  const top = r.top + bbox[1] * S.scale, bottom = r.top + bbox[3] * S.scale;
  if (top < vr.top + 40 || bottom > vr.bottom - 20) { viewer.scrollTop += top - vr.top - 80; invalidateRects(); }
  if (u.o) objectSelection(slot, u.o, true);
  else {
    const cur = extend && S.sel?.source === 'para' ? S.sel.paras : [];
    paraSelection(cur.includes(u.b) ? cur : [...cur, u.b], kind, true);
  }
}
function unitKind() {
  const k = S.sel?.kind;
  return k || (S.mode === 'translated' ? 'translated' : 'original');
}
// Enter in the paper: the first paragraph or figure at the top of the view
export function selectFirstVisibleUnit() {
  const kind = unitKind();
  const vr = viewer.getBoundingClientRect();
  const u = readingUnits(kind).find(x => {
    const slot = slotOf(x.page, kind), r = slot.el.getBoundingClientRect();
    const bbox = x.o?.bbox || x.b.bbox;
    return r.top + bbox[3] * S.scale > vr.top + 20;
  });
  if (u) selectUnit(u, kind);
}
function stepParagraph(dir, extend) {
  const kind = unitKind();
  const units = readingUnits(kind);
  const cur = S.sel?.source === 'object' ? S.sel.obj : S.sel?.paras?.at(dir > 0 ? -1 : 0);
  const i = units.findIndex(u => u.b === cur || u.o === cur);
  const next = units[i < 0 ? 0 : i + dir];
  if (next) selectUnit(next, kind, extend && !next.o);
}
viewer.addEventListener('keydown', e => {
  if (e.target !== viewer || e.isComposing || viewer.inert) return;
  if (e.key === 'Enter' && !e.ctrlKey && !e.altKey && !e.metaKey) { e.preventDefault(); selectFirstVisibleUnit(); }
  else if (e.altKey && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) { e.preventDefault(); if (S.sel) stepParagraph(e.key === 'ArrowDown' ? 1 : -1, e.shiftKey); else selectFirstVisibleUnit(); }
});

/* ---------------------------------------------------------------- hover (called from pointer.js per frame) */
let hoverTimer = null, hoverBlk = null, hoverObjEl = null;
const paraChip = document.createElement('button');
paraChip.type = 'button';
paraChip.className = 'para-chip hidden';
paraChip.textContent = '¶';
paraChip.tabIndex = -1;  // keyboard users select paragraphs with Enter / Alt+arrows in the paper
paraChip.title = '문단 전체 선택 (Shift+클릭으로 여러 문단 선택)';
paraChip.setAttribute('aria-label', '문단 전체 선택');
document.body.appendChild(paraChip);
let chip = null, chipHideT = null, overChip = false;
export function hideChip() { paraChip.classList.add('hidden'); clearSelBoxes('.para-hint'); chip = null; }
function hideChipSoon() { clearTimeout(chipHideT); chipHideT = setTimeout(() => { if (!overChip) hideChip(); }, 300); }
paraChip.addEventListener('mouseenter', () => {
  overChip = true; clearTimeout(chipHideT);
  if (chip) drawSelBox(chip.slot, chip.b.bbox, 'para-hint');
});
paraChip.addEventListener('mouseleave', () => { overChip = false; clearSelBoxes('.para-hint'); hideChipSoon(); });
paraChip.addEventListener('mousedown', e => e.preventDefault());
paraChip.addEventListener('click', e => {
  if (!chip) return;
  const { b, slot } = chip;
  const cur = e.shiftKey && S.sel?.source === 'para' && S.sel.kind === slot.docKind ? S.sel.paras : [];
  const paras = cur.includes(b) ? cur.filter(x => x !== b) : [...cur, b];
  hideChip();
  if (paras.length) paraSelection(paras, slot.docKind); else { clearSelBoxes(); S.sel = null; hidePops(); }
});

function markBlock(b) {
  $$('.blk').forEach(x => x.remove());
  if (!b) return;
  for (const s of S.slots) {
    if (s.i !== b.page || s.docKind === 'original' && S.mode !== 'side') continue;
    const d = document.createElement('div');
    d.className = 'blk pair';
    Object.assign(d.style, {
      left: `${b.bbox[0] * S.scale - 2}px`, top: `${b.bbox[1] * S.scale - 2}px`,
      width: `${(b.bbox[2] - b.bbox[0]) * S.scale + 4}px`, height: `${(b.bbox[3] - b.bbox[1]) * S.scale + 4}px`,
    });
    $('.blk-layer', s.el).appendChild(d);
  }
}
export function resetHover() { hoverBlk = null; clearTimeout(hoverTimer); markBlock(null); $('#tip').classList.add('hidden'); }
export function forgetHoverBlock() { hoverBlk = null; markBlock(null); }

// One pointer-move pass: figure hover box, ¶ chip, translated-paragraph pairing and original-text tip.
export function hoverMove(ev) {
  const pg = ev.target.closest?.('.page');
  const slot = pg?._slot;
  const idle = slot && !ev.buttons && !S.region;
  // figures / tables / equations
  const o = idle ? objectAt(slot, ev) : null;
  if (hoverObjEl && (!o || hoverObjEl._obj !== o)) { hoverObjEl.remove(); hoverObjEl = null; }
  if (o && !hoverObjEl) {
    hoverObjEl = drawSelBox(slot, o.bbox, 'obj-hover');
    hoverObjEl._obj = o;
    hoverObjEl.dataset.label = { figure: '그림 · 클릭', table: '표 · 클릭', equation: '수식 · 클릭' }[o.kind] || '';
  }
  pg?.classList.toggle('over-obj', !!o);
  // ¶ chip
  const b = idle && !o ? paraAt(slot, ev) : null;
  if (!b) { if (chip) hideChipSoon(); }
  else {
    clearTimeout(chipHideT);
    if (chip?.b !== b || chip.slot !== slot) {
      chip = { b, slot };
      const r = rectOf(slot);
      paraChip.classList.remove('hidden');
      paraChip.style.left = `${Math.max(4, r.left + b.bbox[0] * S.scale - 28)}px`;
      paraChip.style.top = `${r.top + b.bbox[1] * S.scale - 1}px`;
    }
  }
  // translated pairing + original tip
  if (!idle || !S.docs.translated) { if (hoverBlk) resetHover(); return; }
  const tb = blockAt(slot, ev);
  if (tb === hoverBlk) return;
  hoverBlk = tb;
  $('#tip').classList.add('hidden');
  clearTimeout(hoverTimer);
  markBlock(S.mode === 'side' || slot.docKind === 'translated' ? tb : null);
  if (tb && slot.docKind === 'translated') {
    hoverTimer = setTimeout(() => {
      const tip = $('#tip');
      tip.innerHTML = `<b>원문</b>${esc(tb.text)}`;
      tip.classList.remove('hidden');
      const r = rectOf(slot);
      const top = r.top + tb.bbox[3] * S.scale + 8;
      const left = Math.min(r.left + tb.bbox[0] * S.scale, innerWidth - tip.offsetWidth - 12);
      tip.style.left = `${Math.max(8, left)}px`;
      tip.style.top = `${top + tip.offsetHeight > innerHeight ? r.top + tb.bbox[1] * S.scale - tip.offsetHeight - 8 : top}px`;
    }, 450);
  }
}
viewer.addEventListener('mouseleave', () => { hideChipSoon(); resetHover(); });

/* ---------------------------------------------------------------- mouse selection */
let down = null;
viewer.addEventListener('mousedown', e => {
  if (e.target.closest('.pop, .page-act, .hl-anchor, .link-annot') || S.region || e.button !== 0) return;
  hidePops();
  down = { x: e.clientX, y: e.clientY, shift: e.shiftKey };
  if (!e.shiftKey) { clearSelBoxes(':not(.search)'); if (S.sel?.source !== 'text') S.sel = null; }
  viewer.classList.add('selecting');
  e.target.closest('.textLayer')?.classList.add('selecting');
});
document.addEventListener('mouseup', e => {
  viewer.classList.remove('selecting');
  if (S.region || !down || e.target.closest('.pop, .quick, .panel, .topbar, .modal, .page-act, .explain-pop, .hl-pop, .link-annot')) { down = null; return; }
  const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y) > 4;
  const shift = down.shift;
  down = null;
  const sess = S.sess;
  const pageEl = e.target.closest('.page') || document.elementFromPoint(e.clientX, e.clientY)?.closest('.page');
  setTimeout(() => {
    if (!live(sess) || (pageEl && !pageEl.isConnected)) return;
    const slot = pageEl?._slot;
    // triple-click → paragraph;  Shift+click → add/remove paragraph
    if (slot && !moved && (e.detail >= 3 || shift)) {
      const b = paraAt(slot, e);
      if (b) {
        const cur = shift && S.sel?.source === 'para' && S.sel.kind === slot.docKind ? S.sel.paras : [];
        const paras = cur.includes(b) ? cur.filter(x => x !== b) : [...cur, b];
        if (paras.length) paraSelection(paras, slot.docKind); else { clearSelBoxes(); S.sel = null; }
        return;
      }
    }
    if (selectFromRange()) return;
    if (slot && !moved && e.detail === 1) {
      const h = highlightAt(slot, e);  // a click on a highlight opens its color/memo popover
      if (h) { openHighlightPopover(h, { x: e.clientX, y: e.clientY }); return; }
      const o = objectAt(slot, e);     // plain click on a figure / table / equation
      if (o) { objectSelection(slot, o); return; }
    }
    if (!shift) S.sel = null;
  }, 10);
});
selPop.addEventListener('mousedown', e => e.preventDefault());
selPop.addEventListener('click', e => {
  const b = e.target.closest('button');
  if (b) selAction(b.dataset.a, b.dataset.color);
});

function withOriginal(s, text) {
  return s.context && s.kind === 'translated' ? `${text}\n\n[원문]\n${s.context}` : text;
}
export async function selAction(a, color) {
  const s = S.sel;
  if (!s || !S.paper) return;
  if (a === 'hl' && !S.highlightsReady) { toast('메모 목록을 불러온 뒤 다시 시도하세요.'); return; }
  if (a === 'translate' || a === 'explain') markScopeSeen();
  hidePops();
  if (a === 'explain') {
    showExplanation({
      anchor: s.anchor, kind: s.kind, label: s.source === 'object' ? s.label : '선택한 문장', isRegion: s.source === 'object', thumb: s.thumb,
      sel: s, prepare: async () => s.source === 'object' ? { region: s.region } : { selection: withOriginal(s, await s.textPromise) },
    });
    return;
  }
  closeExplanation(false);
  const sess = S.sess;
  const text = await s.textPromise.catch(() => s.text || '');
  if (!live(sess)) return;  // the paper was closed while the clean text was still coming
  if (a === 'copy') {
    navigator.clipboard.writeText(text || '').then(() => toast('복사했습니다.'), () => toast('복사하지 못했습니다. 글을 선택하고 Ctrl+C를 누르세요.', { kind: 'error' }));
    return;
  }
  if (a === 'memo') {  // the highlight at the selection (made yellow if missing) and its note box
    try {
      const h = await ensureHighlight(s, text);
      if (!live(sess)) return;
      window.getSelection().removeAllRanges(); clearSelBoxes(); S.sel = null;
      focusNote(h.id);
    } catch (e) { if (live(sess)) toast(`메모를 만들지 못했습니다. ${errorText(e)}`, { kind: 'error' }); }
    return;
  }
  if (a === 'hl') {
    try { await addHighlightFromSelection(s, color, text); }
    catch (e) { if (live(sess)) toast(`메모에 표시하지 못했습니다. ${errorText(e)}`, { kind: 'error' }); }
    if (!live(sess)) return;
    window.getSelection().removeAllRanges();
    clearSelBoxes();
    S.sel = null;
    return;
  }
  if (s.source === 'object') {
    const ctx = { region: s.region, thumb: s.thumb };
    if (a === 'ask') askAbout(ctx);
    else if (a === 'translate') {
      if (!text) { toast(`번역할 글자가 없습니다. ${s.label}의 내용을 보려면 설명을 누르세요.`); return; }
      showQuick(`${s.label} 속 글자 번역`, { kind: 'translate', text });
    }
    return;
  }
  if (a === 'translate' && s.kind === 'translated') { showQuick('원문', null, s.context || '(원문 문단을 찾지 못했습니다)'); return; }
  if (a === 'translate') {
    const isWord = !/\s/.test(text) && text.length < 40;
    showQuick(isWord ? `${text}의 뜻` : '번역', { kind: isWord ? 'word' : 'translate', text, context: s.context });
    return;
  }
  if (a === 'ask') askAbout({ selection: withOriginal(s, text) });
}
function askAbout(ctx) { switchTab('chat'); setChatCtx(ctx); $('#chatText').focus(); }

/* ---------------------------------------------------------------- region tool */
const REGION_HINT = '그림·표·수식 영역을 드래그하세요. Esc로 취소합니다.';
export function toggleRegion() {
  S.region = !S.region;
  if (S.region && viewer.inert) showPanel(false);
  $('#regionBtn').setAttribute('aria-pressed', String(S.region));
  hideChip();
  $('#regionBtn').classList.toggle('on', S.region);
  viewer.classList.toggle('region-mode', S.region);
  if (S.region) toast(REGION_HINT); else dismissToast(REGION_HINT);
  $$('.region-box').forEach(b => b.remove());
}
$('#regionBtn').onclick = toggleRegion;
$('#pages').addEventListener('pointerdown', e => {
  if (!S.region || e.button !== 0) return;
  const pageEl = e.target.closest('.page');
  if (!pageEl) return;
  e.preventDefault();
  $$('.region-box').forEach(b => b.remove());
  pageEl.setPointerCapture(e.pointerId);
  const pr = pageEl.getBoundingClientRect();
  const x0 = e.clientX - pr.left, y0 = e.clientY - pr.top;
  const box = document.createElement('div');
  box.className = 'region-box';
  pageEl.appendChild(box);
  const move = ev => {
    if (ev.pointerId !== e.pointerId) return;
    const x1 = Math.min(Math.max(ev.clientX - pr.left, 0), pr.width), y1 = Math.min(Math.max(ev.clientY - pr.top, 0), pr.height);
    Object.assign(box.style, { left: `${Math.min(x0, x1)}px`, top: `${Math.min(y0, y1)}px`, width: `${Math.abs(x1 - x0)}px`, height: `${Math.abs(y1 - y0)}px` });
  };
  const up = ev => {
    if (ev.pointerId !== e.pointerId) return;
    pageEl.removeEventListener('pointermove', move);
    pageEl.removeEventListener('pointerup', up);
    pageEl.removeEventListener('pointercancel', up);
    if (pageEl.hasPointerCapture(e.pointerId)) pageEl.releasePointerCapture(e.pointerId);
    const w = box.offsetWidth, h = box.offsetHeight;
    if (ev.type === 'pointercancel' || w < 12 || h < 12) { box.remove(); return; }
    const l = box.offsetLeft, t = box.offsetTop;
    const rect = [l / S.scale, t / S.scale, (l + w) / S.scale, (t + h) / S.scale];
    let thumb = null;
    const cv = $('canvas', pageEl);
    if (cv) {
      const k = cv.width / pr.width, c = document.createElement('canvas');
      c.width = w * k; c.height = h * k;
      c.getContext('2d').drawImage(cv, l * k, t * k, w * k, h * k, 0, 0, c.width, c.height);
      thumb = c.toDataURL('image/png');
    }
    // the server crops the same document the thumbnail came from (a translated page, or the original)
    S.regionSel = { page: pageEl._slot.i, rect, thumb, kind: pageEl._slot.docKind };
    const br = box.getBoundingClientRect();
    placePop(regionPop, br.left + br.width / 2, br.top);
    $('button', regionPop).focus({ preventScroll: true });
  };
  pageEl.addEventListener('pointermove', move);
  pageEl.addEventListener('pointerup', up);
  pageEl.addEventListener('pointercancel', up);
});
regionPop.addEventListener('click', e => {
  const a = e.target.closest('button')?.dataset.a;
  if (!a) return;
  hidePops();
  const r = S.regionSel;
  $$('.region-box').forEach(b => b.remove());
  if (S.region) toggleRegion();
  if (a === 'cancel' || !r) { viewer.focus({ preventScroll: true }); return; }
  const ctx = { region: { page: r.page, rect: r.rect, kind: r.kind }, thumb: r.thumb };
  markScopeSeen();
  if (a === 'explain') showExplanation({
    anchor: { page: r.page, bbox: r.rect }, kind: r.kind, label: '선택한 영역', isRegion: true, thumb: r.thumb,
    sel: { source: 'region', kind: r.kind, parts: [{ page: r.page, boxes: [r.rect] }], text: `[영역 · p.${r.page + 1}]` },
    prepare: async () => ({ region: ctx.region }),
  });
  else askAbout(ctx);
});
