// Reads a text/event-stream response body (POST answers from /chat and /explain).
// onEvent(obj) gets each parsed `data:` frame; return true from it to stop reading.
// Throws the server's error frame as an Error carrying {code, detail} for errorText().
export async function readEvents(response, onEvent) {
  if (!response.body) throw Object.assign(new Error('응답을 읽을 수 없습니다. 다시 시도하세요.'), { code: 'provider_failed' });
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '', stop = false;
  const consume = frame => {
    const data = frame.split('\n').filter(line => line.startsWith('data:')).map(line => line.slice(5).trimStart()).join('\n');
    if (!data) return;  // keepalive comments
    const event = JSON.parse(data);
    if (event.error) throw Object.assign(new Error(typeof event.error === 'string' ? event.error : ''), { code: event.code || '', detail: typeof event.error === 'string' ? event.error : '', raw: typeof event.raw === 'string' ? event.raw : '' });
    if (onEvent(event) === true) stop = true;
  };
  try {
    while (!stop) {
      const { value, done } = await reader.read();
      buffer += done ? decoder.decode() : decoder.decode(value, { stream: true });
      buffer = buffer.replace(/\r\n/g, '\n');
      let end;
      while (!stop && (end = buffer.indexOf('\n\n')) >= 0) { consume(buffer.slice(0, end)); buffer = buffer.slice(end + 2); }
      if (done) { if (!stop && buffer.trim()) consume(buffer); break; }
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
