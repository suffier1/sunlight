// Reader state shared by the reader modules. Each field lists its owner (the only module that
// assigns it); the others read. A per-paper session carries the AbortController for every request
// made for the open paper: closing the paper aborts them instead of checking generation numbers.
export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];

function readZoom() {
  try {
    const z = JSON.parse(localStorage.getItem('sl.zoom2'));
    if (z && ['width', 'page', 'custom'].includes(z.mode) && (z.mode !== 'custom' || Number.isFinite(z.scale))) return z;
  } catch { /* default */ }
  return { mode: 'width', scale: 1 };
}

export const S = {
  // settings.js
  settings: null, backends: null, models: null, langs: [], pdfFonts: [], appName: 'Sunlight',
  statusPending: false, statusError: false,
  // paper.js
  sess: null, paper: null, docs: {}, trVersion: -1, pendingMode: null, summaryState: null,
  mode: localStorage.getItem('sl.mode') || 'side',
  // paper.js (data revision) — lookups built by setReaderData
  blocks: [], blocksByPage: new Map(), objectsByPage: new Map(), blockOrder: new Map(),
  pageSizes: [], pageDataReady: false, blockFailures: 0,
  // layout.js
  zoom: readZoom(), scale: 1.2, dpr: 1, slots: [], rectEpoch: 0, observer: null, evictor: null,
  textLayers: new Map(),  // text layer div → its endOfContent sentinel (layout.js adds, selection.js reads)
  // selection.js
  sel: null, region: false, regionSel: null,
  // notes.js
  highlights: [], highlightsReady: false,
  // chat.js
  chatCtx: null, chatDrafts: new Map(), streams: new Map(), chatLoading: false,
  // navigation.js
  position: null, positionDirty: false, positionGesture: 0, restorePos: null,
};

// A session exists from openPaper until closeReader. `sess.signal` aborts every fetch made for it.
export function openSession(pid) {
  S.sess?.ctrl.abort(new DOMException('논문 닫기', 'AbortError'));
  const ctrl = new AbortController();
  S.sess = { pid, ctrl, signal: ctrl.signal };
  return S.sess;
}
export function closeSession() {
  S.sess?.ctrl.abort(new DOMException('논문 닫기', 'AbortError'));
  S.sess = null;
}
export const live = sess => !!sess && sess === S.sess && !sess.signal.aborted;
export const isAbort = e => e?.name === 'AbortError';

export const readerShown = () => !$('#reader').classList.contains('hidden');
// Open modal UI that one-key shortcuts must not reach behind.
export const modalOpen = () => !!document.querySelector('dialog[open], .modal:not(.hidden):not(dialog), .session-screen');
