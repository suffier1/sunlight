// The 요약 tab. Reads S.paper; fetches the saved summary when the summary state changes.
import { api, esc, errorText } from '../ui-kit.js';
import { S, $, $$, live } from './state.js';
import { md, linkPages } from './markdown.js';
import { engineName, chatScopeText, isAuthExpired, openSettings, engineReady } from '../settings.js';
import { gotoPage } from './navigation.js';
import { switchTab, showPanelRetry } from './panel.js';
import { sendChat } from './chat.js';
import { runPaperAction, resumePaper, setMode, cancelJob } from './paper.js';

export function summaryProgress(paper) {
  if (paper.summary_status === 'queued') return '요약 대기';
  return paper.summary_stage === 'checking' ? '요약을 원문과 대조 중' : '요약 중';
}
const el = $('#tab-summary');
function replace(html) {
  const hadFocus = el.contains(document.activeElement);
  el.innerHTML = html;
  if (hadFocus) el.focus({ preventScroll: true });
}
const startSummary = () => runPaperAction('resummary');
export async function renderSummary() {
  const p = S.paper;
  const st = p.summary_status;
  const previous = ['error', 'stopped', 'interrupted'].includes(st) && p.summary_previous_available;
  if (p.storage_issue && st !== 'done' && !previous) { replace('<div class="empty">논문을 복구한 뒤 요약을 만들 수 있습니다.</div>'); return; }
  if (st === 'idle') {
    if (p.status === 'analyzing') { replace('<div class="empty">PDF 분석 중</div>'); return; }
    if (p.scanned) { replace('<div class="empty">스캔 PDF는 원문으로 읽을 수 있습니다.<br>전체 번역·요약에는 OCR로 인식한 텍스트가 필요합니다.</div>'); return; }
    replace(`<div class="empty"><p id="summaryScope">AI 요약 시작을 누르면 본문이 ${esc(engineName())}로 전송됩니다.</p><div class="err-acts"><button type="button" class="btn sm primary" data-summary-start aria-describedby="summaryScope">AI 요약 시작</button></div>
      <p class="ai-hint" id="summaryAiHint" hidden>AI 연결 필요 <button type="button" class="link-btn" data-open-settings>설정에서 연결</button></p></div>`);
    $('[data-summary-start]', el).onclick = startSummary;
    refreshSummaryScopes();
    return;
  }
  if (st === 'running' || st === 'queued') {
    replace(`<div class="empty" role="status"><span class="spinner" aria-hidden="true"></span>${esc(summaryProgress(p))}<div class="err-acts"><button type="button" class="btn sm" data-summary-stop>중지</button></div></div>`);
    $('[data-summary-stop]', el).onclick = e => { e.currentTarget.disabled = true; cancelJob('summary'); };
    return;
  }
  if ((st === 'stopped' || st === 'interrupted') && !previous) {
    replace(`<div class="empty">${st === 'stopped' ? '요약을 중지했습니다.' : '요약이 중단되었습니다. 이어서 할 수 있습니다.'}
      <div class="err-acts">${st === 'interrupted' ? '<button type="button" class="btn sm primary" data-fix="resume">이어서 하기</button>' : ''}<button type="button" class="btn sm" data-fix="resummary">다시 요약</button></div></div>`);
    $('[data-fix="resume"]', el)?.addEventListener('click', () => resumePaper());
    $('[data-fix="resummary"]', el).onclick = startSummary;
    return;
  }
  if (st === 'error' && !previous) {
    const err = { detail: p.summary_error || p.error || '', code: p.summary_error_code || '' };
    replace(`<div class="empty" role="status">요약하지 못했습니다.<br><small>${esc(errorText(err))}</small>
      <div class="err-acts">${isAuthExpired(err) ? '<button type="button" class="btn sm" data-fix="login">다시 연결</button>' : ''}<button type="button" class="btn sm" data-fix="resummary">다시 요약</button></div></div>`);
    $('[data-fix="login"]', el)?.addEventListener('click', () => openSettings());
    $('[data-fix="resummary"]', el).onclick = startSummary;
    return;
  }
  const sess = S.sess;
  const snapshot = S.summaryState;
  const current = () => live(sess) && S.summaryState === snapshot;
  let s;
  try { s = await api(`/api/papers/${p.id}/summary`, { signal: sess.signal, timeout: 12000 }); } catch (e) {
    if (current()) showPanelRetry(el, e, renderSummary);
    return;
  }
  if (!current()) return;
  // the fields come from the AI: show only what has the expected shape, skip the rest
  const str = x => (typeof x === 'string' ? x.trim() : '');
  const arr = v => (Array.isArray(v) ? v : []);
  const tldr = (typeof s?.tldr === 'string' ? [s.tldr] : arr(s?.tldr)).filter(str);
  const verified = Array.isArray(s?.sources);
  const sourcesByClaim = new Map();
  for (const source of arr(s?.sources)) {
    if (!Number.isInteger(source?.claim) || source.claim < 0 || source.claim >= tldr.length ||
        !Number.isInteger(source?.page) || source.page < 1 || source.page > p.pages || !str(source.quote)) continue;
    const list = sourcesByClaim.get(source.claim) || [];
    list.push(source);
    sourcesByClaim.set(source.claim, list);
  }
  const citation = source => `<div class="summary-source"><button type="button" class="link" data-summary-page="${source.page}" aria-label="원문 ${source.page}쪽으로 이동">${source.page}쪽</button><q>${esc(source.quote)}</q></div>`;
  const kws = arr(s?.keywords).filter(k => k && typeof k === 'object' && str(k.term));
  const qs = arr(s?.questions).filter(str);
  const overview = str(s?.overview);
  const review = s?.grounding_review;
  const checked = review?.version === 1 && review.status === 'supported' && /^[a-f0-9]{64}$/i.test(review.draft_id);
  if (!tldr.length && !overview) { replace('<div class="empty">요약 없음</div>'); return; }
  const failedNote = previous ? `<p class="summary-context-note">${st === 'error' ? '다시 요약하지 못했습니다.' : '새 요약을 중지했습니다.'} 이전 요약을 표시합니다. ${p.storage_issue ? '' : '<button type="button" class="link" data-fix="resummary">다시 요약</button>'}${p.summary_error ? `<br>${esc(errorText({ detail: p.summary_error }))}` : ''}</p>` : '';
  replace(`<div class="sum">
    ${failedNote}
    ${checked ? '<p class="summary-context-note">AI 근거 대조 완료</p>' : ''}
    ${s?.source_context_truncated === true ? '<p class="summary-context-note">문서가 길어 일부 원문을 바탕으로 요약했습니다.</p>' : ''}
    ${tldr.length ? `<h4>${tldr.length === 3 ? '3줄 요약' : '요약'}</h4><ol class="tldr">${tldr.map((x, index) => `<li><div class="md">${md(x).replace(/^<p>|<\/p>\s*$/g, '')}</div>${arr(sourcesByClaim.get(index)).map(citation).join('')}</li>`).join('')}</ol>` : ''}
    ${kws.length ? `<h4>키워드</h4><div class="kw-list">${kws.map(k => `
      <button type="button" class="kw" aria-expanded="false"><b>${esc(k.term)}</b>${str(k.tr) && k.tr !== k.term ? `<small>${esc(k.tr)}</small>` : ''}<div class="d">${esc(str(k.desc))}</div></button>`).join('')}</div>` : ''}
    ${overview ? `<h4>핵심 정리</h4><div class="md">${md(overview)}</div>` : ''}
    ${qs.length ? `<h4>이어서 물어보기</h4><p class="summary-question-scope" id="summaryQuestionScope">${esc(chatScopeText())}</p><div class="qs">${qs.map(q => `<button type="button" class="q" aria-describedby="summaryQuestionScope">${esc(q)}</button>`).join('')}</div>` : ''}
  </div>`);
  $('[data-fix="resummary"]', el)?.addEventListener('click', startSummary);
  if (!verified) $$('.md', el).forEach(m => linkPages(m, S.docs.original?.numPages || 0));
  $$('[data-summary-page]', el).forEach(b => b.onclick = () => {
    if (S.mode === 'translated') setMode('original');
    gotoPage(Number(b.dataset.summaryPage) - 1);
  });
  $$('.kw', el).forEach(k => k.onclick = () => k.setAttribute('aria-expanded', String(k.classList.toggle('open'))));
  $$('.q', el).forEach(q => q.onclick = () => { switchTab('chat'); $('#chatText').focus(); sendChat(q.textContent); });
}
export function refreshSummaryScopes() {
  const q = $('#summaryQuestionScope');
  if (q) q.textContent = chatScopeText();
  const s = $('#summaryScope');
  if (s) s.textContent = `AI 요약 시작을 누르면 본문이 ${engineName()}로 전송됩니다.`;
  const hint = $('#summaryAiHint');
  if (hint) hint.hidden = !S.backends || S.statusPending || engineReady();
}
