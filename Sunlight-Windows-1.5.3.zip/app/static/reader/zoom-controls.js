// Zoom buttons (topbar on wide windows, the ⋯ menu on narrow ones): −, %, +, 폭 맞춤, 쪽 맞춤.
import { zoomStep, setZoomMode } from './layout.js';

document.addEventListener('click', e => {
  const b = e.target.closest('[data-zoom], [data-zoom-fit]');
  if (!b || !b.closest('#reader')) return;
  if (b.dataset.zoom) zoomStep(b.dataset.zoom === 'in' ? 1 : -1);
  else setZoomMode(b.dataset.zoomFit);
});
