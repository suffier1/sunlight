// Shared reading position for the desktop reader (contract §8).
//
//   const position = readingPosition(paperId, { onNewer });
//   const saved = await position.load();        // { p, f } (0-based page, fraction) or null
//   position.move(saved || { p: 0, f: 0 }, true); // baseline for the opened paper: NOT written
//   position.move({ p, f });                     // a real movement: written (debounced by the caller)
//   position.flush();                            // send a pending movement now (pagehide, paper switch)
//   position.close();                            // stop listening; also done when another paper opens
//
// onNewer({ page, fraction, device, at, revision }) is called when another device saved a newer
// position for this paper than this window has seen: after a rejected write (409), and when the
// window regains focus or becomes visible. `page` is 1-based, `device` is the phone's name ("iPhone")
// or "PC", `at` is epoch seconds. Show a non-blocking prompt such as "휴대폰에서 읽던 23쪽으로 이동"
// (이동 / 무시). Moving there is an ordinary move(); ignoring needs no call. Either way the next
// movement in this window takes over, because the newer revision has already been adopted.
//
// Each open reader remembers the revision it actually saw. A background window may flush a
// pending move, but cannot silently replace a newer position from another device.
let current = null;

export function readingPosition(id, { onNewer } = {}) {
  current?.close();
  const url = '/api/papers/' + encodeURIComponent(id) + '/position';
  const key = 'sl.pos.' + id;
  const lifetime = new AbortController();
  let revision = null, pending = null, saving = null, last = null, checking = null, lastCheck = 0;
  let local = null;
  try { local = JSON.parse(localStorage.getItem(key)); } catch { /* optional local fallback */ }

  async function fetchPosition(timeout = 2000) {
    const response = await fetch(url, { cache: 'no-store', credentials: 'same-origin', signal: AbortSignal.timeout(timeout) });
    if (!response.ok) throw new Error(String(response.status));
    return response.json();
  }
  async function load() {
    try {
      const data = await fetchPosition();
      revision = data.revision;
      last = revision ? { p: data.page - 1, f: data.fraction } : local;
      return last;
    } catch { return local; }
  }
  // Adopt a newer stored revision and tell the reader if it points somewhere else.
  function consider(data) {
    if (lifetime.signal.aborted || revision === null || !(data.revision > revision)) return;
    revision = data.revision;
    if (data.device === 'PC' || last && data.page - 1 === last.p) return;
    onNewer?.({ page: data.page, fraction: data.fraction, device: data.device || '다른 기기', at: data.updated_at, revision: data.revision });
  }
  function check() {
    if (checking || lifetime.signal.aborted || Date.now() - lastCheck < 2000) return checking;
    lastCheck = Date.now();
    checking = fetchPosition().then(consider, () => {}).finally(() => { checking = null; });
    return checking;
  }
  function remember(pos) {
    try { localStorage.setItem(key, JSON.stringify(pos)); } catch { /* storage may be full */ }
  }
  async function drain() {
    while (pending && revision !== null) {
      const pos = pending;
      pending = null;
      try {
        const response = await fetch(url, {
          method: 'PUT', keepalive: true, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ page: pos.p + 1, fraction: pos.f, revision }),
          signal: AbortSignal.timeout(3500),
        });
        if (response.status === 409) {
          // Another device moved on. Offer its place; only a later movement here takes over.
          pending = null;
          try { consider(await fetchPosition()); } catch { /* the next focus check retries */ }
          return;
        }
        if (!response.ok) throw new Error(String(response.status));
        revision = (await response.json()).revision;
        last = pos;
      } catch {
        pending ??= pos;
        return;
      }
    }
  }
  function flush() {
    if (!saving) saving = drain().finally(() => { saving = null; });
    return saving;
  }
  function move(pos, opened = false) {
    if (!pos || !Number.isInteger(pos.p) || pos.p < 0 || !Number.isFinite(pos.f)) return;
    const next = { p: pos.p, f: Math.max(0, Math.min(1, pos.f)) };
    remember(next);
    // Opening a paper is not a movement: it sets the baseline and writes nothing.
    if (opened) { last = next; return; }
    if (!pending && last?.p === next.p && Math.abs(last.f - next.f) < 0.002) return;
    pending = next;
    return flush();
  }
  const onFocus = () => { void check(); };
  const onVisible = () => { if (document.visibilityState === 'visible') void check(); };
  window.addEventListener('focus', onFocus, { signal: lifetime.signal });
  document.addEventListener('visibilitychange', onVisible, { signal: lifetime.signal });
  const api = {
    load, move, flush, check,
    close() {
      lifetime.abort();
      if (current === api) current = null;
    },
  };
  current = api;
  return api;
}
