const BASE = '/api/review';
const MAX_PAPERS = 200;
const MAX_COLUMNS = 24;
const PAGE_ROWS = 20;
const FALLBACK_POLL = 15000;
const jobNames = { running: '논문을 정리하는 중', completed: '비교표 완료', partial: '일부 논문 정리 완료',
  failed: '논문을 정리하지 못했습니다', cancelled: '중지됨', interrupted: '중단됨 · 남은 논문을 다시 시작할 수 있습니다' };
const finished = state => ['completed', 'partial', 'failed', 'cancelled', 'interrupted'].includes(state);

// kit: ui-kit ({api, esc, toast, confirmDialog, errorText, onServerEvent, serverEventsLive}).
// titleOf(paperId) gives the library title; context() the current library scope (for reopening from a toast).
export function createReviewUI({ kit, sendPdf, requireEngine, engineName, onImport, titleOf = () => '', context }) {
  const { api, esc, toast, confirmDialog, errorText } = kit;
  const $ = id => document.getElementById('review' + id);
  const dialog = $('Dialog');
  let scope, libraryItems = [], localItems = [], source = 'library', opener;
  let columns = [], suggestion = null, settingsLoaded = false, busy = false, opening = 0, page = 'draft';
  let job = null, history = [], poll, requestKey, requestSignature, importAbort, suggestedFor, resultVersion = '';
  let retryFor = '', retryKey, sourceRequest = 0, evidenceKey = '', loadSeq = 0, previewStart = 0, previewJob = '';
  let detailId = null, gridScrollLeft = 0, gridScrollTop = 0, fetching = false, fetchAgain = false;
  let watching = null, watchTimer = 0;
  const activeJob = () => history[0]?.status === 'running';
  const selectedItems = () => (source === 'pc' ? localItems : libraryItems).filter(item => item.selected);
  const post = (path, data, timeout = 30000) => api(BASE + path, { method: 'POST', body: data, timeout });
  const write = (el, value) => { if (el.textContent !== value) el.textContent = value; };
  const say = message => write($('Status'), message);
  const error = message => write($('Error'), message ? errorText(message) : '');
  // Rows and history read by paper title; the file name is only the fallback.
  // Two papers with the same title also show their file names.
  const baseName = row => row.title || titleOf(row.paper_id) || row.filename || '이름 없는 논문';
  const nameKey = name => name.replace(/\.pdf$/i, '').trim().toLocaleLowerCase();
  const repeated = new WeakMap();
  const repeatedNames = rows => {
    if (!repeated.has(rows)) {
      const seen = new Set(), dup = new Set();
      for (const row of rows) { const k = nameKey(baseName(row)); if (seen.has(k)) dup.add(k); else seen.add(k); }
      repeated.set(rows, dup);
    }
    return repeated.get(rows);
  };
  const rowName = row => {
    const name = baseName(row);
    return job?.rows && repeatedNames(job.rows).has(nameKey(name)) && row.filename && row.filename !== name ? `${name} (${row.filename})` : name;
  };
  const button = (name, id, primary = false) => {
    const el = document.createElement('button');
    el.type = 'button'; el.id = 'review' + id; el.className = 'btn' + (primary ? ' primary' : '');
    el.textContent = name; return el;
  };

  function paintSelection(listChanged = false) {
    const items = source === 'pc' ? localItems : libraryItems;
    const count = items.reduce((n, item) => n + Number(item.selected), 0);
    write($('PaperLabel'), `${source === 'pc' ? '내 PC' : scope.name} · ${items.length}편 중 ${count}편 선택`);
    $('All').checked = !!count && count === items.length;
    $('All').indeterminate = count > 0 && count < items.length;
    $('All').disabled = !items.length || busy;
    if (listChanged) {
      const list = $('PaperList');
      list.replaceChildren();
      if (!items.length) {
        list.textContent = source === 'pc' ? '선택한 PDF가 없습니다.' : '이 목록에 논문이 없습니다.';
      } else {
        const fragment = document.createDocumentFragment();
        items.forEach((item, index) => {
          const label = document.createElement('label'); label.className = 'review-paper';
          const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.checked = item.selected;
          checkbox.dataset.index = index;
          const text = document.createElement('span'); text.textContent = item.label + (item.problem ? ' · ' + item.problem : '');
          label.append(checkbox, text); fragment.append(label);
        });
        list.append(fragment);
      }
    }
    if (page === 'draft' && !busy) {
      $('Start').disabled = !settingsLoaded || !count || count > MAX_PAPERS || activeJob();
      $('Start').textContent = `${count}편 표 만들기`;
    }
    if (page === 'draft') write($('Scope'), count > MAX_PAPERS ? `한 번에 ${MAX_PAPERS}편까지 선택할 수 있습니다.` :
      count ? `표 만들기를 누르면 선택한 논문 본문과 열 지침을 ${engineName()}에 보냅니다.` : '표에 담을 논문을 선택하세요.');
  }
  function providerChanged() {
    if (!dialog.open) return;
    $('SuggestScope').textContent = `작성한 설명과 현재 열 설정을 ${engineName()}에 보냅니다.`;
    if (page === 'draft') paintSelection();
  }

  function renderColumns(focusIndex, control = '.review-col-title') {
    $('Columns').innerHTML = columns.map((column, i) =>
      `<li data-index="${i}"><div class="review-column-head">
        <input type="text" class="review-col-title" maxlength="80" aria-label="${i + 1}열 이름" placeholder="열 이름" value="${esc(column.title)}">
        <button type="button" data-action="up" aria-label="${i + 1}열 위로" title="위로"${!i ? ' disabled' : ''}>↑</button>
        <button type="button" data-action="down" aria-label="${i + 1}열 아래로" title="아래로"${i === columns.length - 1 ? ' disabled' : ''}>↓</button>
        <button type="button" data-action="remove" aria-label="${i + 1}열 삭제" title="열 삭제"${columns.length === 1 ? ' disabled' : ''}>×</button></div>
        <textarea class="review-col-instruction" rows="1" maxlength="600" aria-label="${i + 1}열 작성 지침" placeholder="이 열에 어떤 내용을 넣을까요?">${esc(column.instruction)}</textarea></li>`
    ).join('');
    write($('ColumnCount'), `· ${columns.length}개`);
    $('AddColumn').disabled = columns.length >= MAX_COLUMNS;
    if (focusIndex != null) {
      const row = $('Columns').children[focusIndex];
      (row?.querySelector(control + ':not(:disabled)') || row?.querySelector('input') || $('AddColumn')).focus();
    }
  }

  function config() {
    const chosen = columns.map(column => ({ title: column.title.trim(), instruction: column.instruction.trim() }));
    const seen = new Set();
    for (let i = 0; i < chosen.length; i++) {
      const { title, instruction } = chosen[i];
      const duplicate = seen.has(title.toLowerCase());
      if (!title || !instruction || duplicate) {
        $('ColumnsPanel').open = true;
        $('Columns').children[i].querySelector(!title || duplicate ? 'input' : 'textarea').focus();
        throw new Error(duplicate ? `${i + 1}열의 이름이 겹칩니다.` : `${i + 1}열의 ${title ? '작성 지침을' : '이름을'} 입력하세요.`);
      }
      seen.add(title.toLowerCase());
    }
    return { columns: chosen, length: $('Length').value, format: $('Format').value };
  }

  function setBusy(value) {
    busy = value;
    $('Draft').inert = value;
    $('New').disabled = $('Recent').disabled = value;
    $('History').disabled = value;
    if (value) $('All').disabled = true;
    if ($('ChangeJob')) $('ChangeJob').disabled = value;
    if ($('Start')) $('Start').disabled = value;
    if (!value && page === 'draft') paintSelection();
  }

  function resetSuggestion() {
    suggestion = null;
    $('Suggestion').hidden = true;
    $('SuggestedColumns').replaceChildren();
  }
  $('Description').oninput = resetSuggestion;
  $('Suggest').onclick = async () => {
    const description = $('Description').value.trim();
    if (!description) { error('원하는 열을 한 문장으로 설명하세요.'); $('Description').focus(); return; }
    const seq = opening;
    error(''); setBusy(true); say('열 구성을 제안받는 중…');
    try {
      if (!await requireEngine(() => dialog.open && opening === seq)) return;
      const result = await post('/columns', { description, columns: columns.filter(c => c.title.trim() && c.instruction.trim()) }, 200000);
      if (!dialog.open || opening !== seq) return;
      suggestion = result.columns;
      suggestedFor = JSON.stringify(columns);
      $('SuggestedColumns').innerHTML = suggestion.map(c => `<li><strong>${esc(c.title)}</strong><span>${esc(c.instruction)}</span></li>`).join('');
      $('Suggestion').hidden = false;
    } catch (e) { if (dialog.open && opening === seq) error(e); }
    finally { if (opening === seq) { setBusy(false); say(''); if (suggestion) $('Apply').focus(); } }
  };
  $('Apply').onclick = () => {
    if (!suggestion) return;
    if (suggestedFor !== JSON.stringify(columns)) { resetSuggestion(); error('열 설정이 바뀌었습니다. 새 설정으로 다시 제안받으세요.'); return; }
    columns = suggestion.map(c => ({ ...c })); resetSuggestion(); renderColumns(0); error(''); say('제안된 열을 적용했습니다.');
  };
  $('Discard').onclick = () => { resetSuggestion(); $('Suggest').focus(); };
  $('Columns').oninput = event => {
    const row = event.target.closest('li');
    if (!row) return;
    columns[Number(row.dataset.index)][event.target.matches('input') ? 'title' : 'instruction'] = event.target.value;
    resetSuggestion(); say(''); error('');
  };
  $('Columns').onclick = event => {
    const action = event.target.closest('button')?.dataset.action;
    if (!action) return;
    const i = Number(event.target.closest('li').dataset.index);
    let next = i;
    if (action === 'remove') { columns.splice(i, 1); next = Math.min(i, columns.length - 1); }
    else { next = i + (action === 'up' ? -1 : 1); [columns[i], columns[next]] = [columns[next], columns[i]]; }
    resetSuggestion(); renderColumns(next, action === 'remove' ? 'input' : `[data-action="${action}"]`); say(''); error('');
  };
  $('AddColumn').onclick = () => { columns.push({ title: '', instruction: '' }); resetSuggestion(); renderColumns(columns.length - 1); };
  $('Save').onclick = async () => {
    const seq = opening;
    error(''); say('');
    try {
      const options = config(); setBusy(true);
      await api(BASE + '/settings', { method: 'PUT', body: options, timeout: 15000 });
      if (opening === seq) say('비교표 설정을 저장했습니다.');
    } catch (e) { if (opening === seq) error(e); }
    finally { if (opening === seq) setBusy(false); }
  };

  for (const radio of dialog.querySelectorAll('[name="reviewSource"]')) radio.onchange = () => {
    source = radio.value; $('Pc').hidden = source !== 'pc'; error(''); say(''); paintSelection(true);
  };
  $('All').onchange = () => {
    const items = source === 'pc' ? localItems : libraryItems;
    items.forEach(item => { item.selected = $('All').checked; });
    paintSelection(true);
  };
  $('PaperList').onchange = event => {
    const item = (source === 'pc' ? localItems : libraryItems)[Number(event.target.dataset.index)];
    if (item) { item.selected = event.target.checked; paintSelection(); }
  };
  function chooseFiles(input) {
    if (!input.files.length) return;
    const pdfs = [...input.files].filter(f => /\.pdf$/i.test(f.name));
    localItems = pdfs.map(file => ({ file, label: file.webkitRelativePath || file.name, selected: true }));
    input.value = '';
    error(pdfs.length ? '' : '선택한 위치에 PDF가 없습니다.'); say('');
    $('Papers').open = !!pdfs.length; paintSelection(true);
  }
  for (const [trigger, input] of [['BrowseFiles', 'FileInput'], ['BrowseFolder', 'FolderInput']]) {
    $(trigger).onclick = () => $(input).click();
    $(input).onchange = () => chooseFiles($(input));
  }

  async function importSelected(items, signal) {
    let finished = 0;
    let added = false;
    write($('Scope'), 'PDF를 추가하는 중입니다. 창을 닫으면 남은 파일 추가가 중단됩니다.');
    try {
      for (const item of items) {
        signal.throwIfAborted();
        if (!item.paperId) {
          const prefix = `PDF 추가 ${finished + 1}/${items.length} · ${item.file.name}`;
          say(prefix);
          try {
            const paper = await sendPdf(item.file, false, percent => say(percent == null ? prefix : `${prefix} (${percent}%)`), signal);
            item.paperId = paper.id; delete item.problem; added = true;
          } catch (e) { if (signal.aborted) throw e; item.problem = errorText(e); }
        }
        finished++;
      }
    } finally { if (added) void onImport(); }
    const failed = items.filter(item => !item.paperId);
    if (failed.length) {
      $('Papers').open = true; paintSelection(true);
      throw new Error(`PDF ${failed.length}편을 추가하지 못했습니다. 목록에서 해당 파일을 확인하거나 선택을 해제하세요. 다른 PDF는 라이브러리에 보관했습니다.`);
    }
  }

  async function start() {
    if (busy || activeJob()) return;
    const seq = opening;
    error(''); say('');
    try {
      const options = config(), items = selectedItems();
      if (!items.length || items.length > MAX_PAPERS) throw new Error(`논문을 1~${MAX_PAPERS}편 선택하세요.`);
      setBusy(true);
      if (!await requireEngine(() => dialog.open && opening === seq)) return;
      if (source === 'pc') {
        const controller = importAbort = new AbortController();
        try { await importSelected(items, controller.signal); } finally { if (importAbort === controller) importAbort = null; }
      }
      if (!dialog.open || opening !== seq) return;
      const data = { ...options, paper_ids: [...new Set(items.map(item => item.paperId))] };
      const signature = JSON.stringify(data);
      if (requestSignature !== signature) { requestKey = crypto.randomUUID(); requestSignature = signature; }
      say('작업을 시작하는 중…');
      const result = await post('/jobs', { ...data, request_id: requestKey });
      if (!dialog.open || opening !== seq) return;
      requestSignature = null; job = result;
      history = [{ id: job.id, status: job.status, count: job.rows.length, first_filename: job.rows[0]?.filename, first_title: job.rows[0] ? rowName(job.rows[0]) : '', created: Date.now()/1000 }, ...history.filter(old => old.id !== job.id)];
      showPage('result');
    } catch (e) { if (dialog.open && opening === seq) error(e); }
    finally { if (opening === seq) { setBusy(false); say(''); } }
  }

  const rowStatus = row => row.error || ({ failed: '오류 · 다시 시작할 수 있습니다', cancelled: '중지됨', running: '정리 중', pending: '대기' }[row.status] || '');
  const displayValue = value => value ? esc(value) : '<span class="review-no-value" aria-label="원문에서 확인되지 않음">—</span>';
  function columnWidth(column) {
    const title = column.title.trim();
    if (/^(?:출판|발행|발표|게재)?\s*(?:연도|년도)$|^year$/i.test(title)) return 76;
    if (/^(?:저자|이름|학회(?:지)?|학술지|저널|게재처|학회\s*[·/]\s*(?:학술지|저널)|authors?|venue)$/i.test(title)) return 144;
    return 214;
  }
  function renderTable() {
    if (!job || page !== 'result') return;
    const rows = job.rows;
    if (previewJob !== job.id || previewStart >= rows.length) previewStart = 0;
    previewJob = job.id;
    const slice = rows.slice(previewStart, previewStart + PAGE_ROWS);
    const focused = document.activeElement?.closest('#reviewTable [data-paper]')?.dataset.paper;
    const widths = job.columns.map(columnWidth);
    $('Table').style.minWidth = `calc(var(--review-source-width) + ${widths.reduce((sum, w) => sum + w, 0)}px)`;
    $('Table').innerHTML = `<colgroup><col>${'<col>'.repeat(widths.length)}</colgroup><thead><tr><th scope="col">논문</th>${job.columns.map(c => `<th scope="col">${esc(c.title)}</th>`).join('')}</tr></thead><tbody>${slice.map(row => {
      const cells = row.status === 'completed'
        ? job.columns.map((_, index) => `<td>${displayValue(row.values[index])}</td>`).join('')
        : `<td class="review-row-status" colspan="${job.columns.length}">${esc(rowStatus(row))}</td>`;
      return `<tr data-row="${esc(row.paper_id)}"><th scope="row"><button type="button" data-paper="${esc(row.paper_id)}" aria-label="${esc(rowName(row))} 항목별로 읽기">${esc(rowName(row))}</button></th>${cells}</tr>`;
    }).join('')}</tbody>`;
    const cols = $('Table').querySelectorAll('col');
    widths.forEach((width, index) => { cols[index + 1].style.width = width + 'px'; });
    if (focused) $('Table').querySelector(`[data-paper="${CSS.escape(focused)}"]`)?.focus({ preventScroll:true });
    $('Paging').hidden = rows.length <= PAGE_ROWS; $('Prev').disabled = previewStart === 0;
    const remaining = rows.length - previewStart - slice.length;
    $('Next').disabled = remaining <= 0;
    write($('Prev'), `이전 ${PAGE_ROWS}편`);
    write($('Next'), `다음 ${remaining > 0 ? Math.min(PAGE_ROWS, remaining) : PAGE_ROWS}편`);
    write($('PageLabel'), `${previewStart + 1}–${previewStart + slice.length} / ${rows.length}편`);
    updateColumnNav();
  }
  function updateColumnNav() {
    const grid = $('Grid'), max = grid.scrollWidth - grid.clientWidth;
    $('ColumnNav').hidden = grid.clientWidth === 0 || max <= 2;
    $('PrevColumn').disabled = grid.scrollLeft <= 1;
    $('NextColumn').disabled = grid.scrollLeft >= max - 1;
  }
  function moveColumn(direction) {
    const grid = $('Grid');
    const max = grid.scrollWidth - grid.clientWidth;
    let offset = 0;
    const stops = [0];
    for (const cell of $('Table').tHead.rows[0].cells) {
      if (cell.cellIndex === 0) continue;
      offset += cell.offsetWidth;
      if (offset >= max - 1) break;
      stops.push(offset);
    }
    stops.push(max);
    const target = direction > 0 ? stops.find(x => x > grid.scrollLeft + 1) : stops.reverse().find(x => x < grid.scrollLeft - 1);
    if (target !== undefined) grid.scrollLeft = target;
    updateColumnNav();
  }
  new ResizeObserver(updateColumnNav).observe($('Grid'));
  $('Grid').addEventListener('scroll', updateColumnNav, {passive: true});
  $('PrevColumn').onclick = () => moveColumn(-1);
  $('NextColumn').onclick = () => moveColumn(1);
  $('Prev').onclick = () => { previewStart -= PAGE_ROWS; renderTable(); $('Grid').scrollTop = 0; };
  $('Next').onclick = () => { previewStart += PAGE_ROWS; renderTable(); $('Grid').scrollTop = 0; };
  function resetEvidence() {
    sourceRequest++; evidenceKey = ''; $('Evidence').open = false;
    $('Quotes').replaceChildren();
    $('EvidenceStatus').textContent = ''; $('EvidenceRetry').hidden = true;
  }
  function showPaper(pid, focus = true) {
    const i = job.rows.findIndex(row => row.paper_id === pid);
    if (i < 0) return;
    if (!detailId) { gridScrollLeft = $('Grid').scrollLeft; gridScrollTop = $('Grid').scrollTop; }
    if (detailId !== pid) resetEvidence();
    detailId = pid;
    const row = job.rows[i];
    $('GridView').hidden = true; $('PaperView').hidden = false; dialog.classList.add('reading-review-paper');
    write($('PaperTitle'), rowName(row)); write($('PaperPosition'), `${i + 1} / ${job.rows.length}편`);
    $('PrevPaper').disabled = !i; $('NextPaper').disabled = i + 1 === job.rows.length;
    write($('PaperIssue'), rowStatus(row));
    $('Values').hidden = $('Evidence').hidden = $('JumpEvidence').hidden = row.status !== 'completed';
    if (row.status === 'completed') $('Values').innerHTML = job.columns.map((c, n) =>
      `<div><dt>${esc(c.title)}</dt><dd>${row.values[n] ? esc(row.values[n]) : '<span class="review-no-value">원문에서 확인되지 않음</span>'}</dd></div>`).join('');
    if (focus) { $('Body').scrollTop = 0; $('PaperTitle').focus({ preventScroll: true }); }
  }
  function backToTable(focus = true) {
    const previous = detailId;
    detailId = null; resetEvidence(); $('GridView').hidden = false; $('PaperView').hidden = true; dialog.classList.remove('reading-review-paper');
    if (!previous || !focus || !job) return;
    const i = job.rows.findIndex(row => row.paper_id === previous);
    if (i >= 0) previewStart = Math.floor(i / PAGE_ROWS) * PAGE_ROWS;
    renderTable(); $('Grid').scrollLeft = gridScrollLeft; $('Grid').scrollTop = gridScrollTop;
    const rowButton = $('Table').querySelector(`[data-paper="${CSS.escape(previous)}"]`);
    rowButton?.focus({ preventScroll:true }); rowButton?.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }
  $('Table').onclick = event => {
    const row = event.target.closest('tr[data-row]');
    if (row && (event.target.closest('button') || window.getSelection()?.isCollapsed)) showPaper(row.dataset.row);
  };
  $('Back').onclick = () => backToTable();
  $('JumpEvidence').onclick = () => {
    $('Evidence').open = true;
    const summary = $('Evidence').querySelector('summary');
    summary.focus({preventScroll:true}); summary.scrollIntoView({ block:'start' });
  };
  $('PrevPaper').onclick = () => showPaper(job.rows[job.rows.findIndex(r => r.paper_id === detailId)-1].paper_id);
  $('NextPaper').onclick = () => showPaper(job.rows[job.rows.findIndex(r => r.paper_id === detailId)+1].paper_id);
  dialog.addEventListener('cancel', event => { if (detailId) { event.preventDefault(); backToTable(); } });
  async function readEvidence() {
    if (!$('Evidence').open || !dialog.open || !job) return;
    const pid = detailId;
    if (!pid) return;
    const key = job.id + ':' + pid;
    if (evidenceKey === key) return;
    const seq = ++sourceRequest;
    $('Quotes').replaceChildren(); $('EvidenceRetry').hidden = true;
    write($('EvidenceStatus'), '근거를 불러오는 중…');
    try {
      const result = await api(BASE + `/jobs/${encodeURIComponent(job.id)}/papers/${encodeURIComponent(pid)}/sources`, { timeout: 15000 });
      if (!dialog.open || !$('Evidence').open || seq !== sourceRequest) return;
      const fragments = [];
      for (const [index, items] of (result.sources || []).entries()) {
        if (!items?.length || !job.columns[index]) continue;
        const term = document.createElement('dt'); term.textContent = job.columns[index].title;
        fragments.push(term);
        for (const item of items) {
          const quote = document.createElement('dd'); quote.textContent = `PDF ${item.page}쪽 · ${item.quote}`; fragments.push(quote);
        }
      }
      evidenceKey = key; $('Quotes').replaceChildren(...fragments);
      write($('EvidenceStatus'), fragments.length ? '' : '저장된 원문 근거가 없습니다.');
      const heading = $('Evidence').querySelector('summary');
      // The short loading panel can reach the bottom before its quotes arrive.
      if (document.activeElement === heading) heading.scrollIntoView({ block: 'start' });
    } catch (e) {
      if (!dialog.open || !$('Evidence').open || seq !== sourceRequest) return;
      write($('EvidenceStatus'), '원문 근거를 불러오지 못했습니다.'); $('EvidenceRetry').hidden = false;
    }
  }
  $('Evidence').ontoggle = () => {
    if ($('Evidence').open && job) void readEvidence(); else sourceRequest++;
  };
  $('EvidenceRetry').onclick = readEvidence;
  async function loadResult(id) {
    if (!id || busy) return;
    const openingSeq = opening, currentLoad = ++loadSeq;
    clearTimeout(poll); setBusy(true); error(''); say('저장된 표를 불러오는 중…');
    try {
      const next = await api(BASE + '/jobs/' + encodeURIComponent(id), { timeout: 15000 });
      if (!dialog.open || openingSeq !== opening || currentLoad !== loadSeq) return;
      backToTable(false); job = next; showPage('result');
    } catch (e) {
      if (openingSeq === opening && dialog.open) { error(e); if (job) $('History').value = job.id; }
    } finally { if (openingSeq === opening && currentLoad === loadSeq) { setBusy(false); say(''); schedulePoll(); } }
  }
  $('History').onchange = () => loadResult($('History').value);
  function renderHistory() {
    $('HistoryField').hidden = history.length < 2;
    if (history.length < 2) return;
    $('History').replaceChildren(...history.map((item, index) => {
      const date = new Date(item.created * 1000);
      const stamp = Number.isFinite(date.getTime()) ? date.toLocaleString('ko-KR', { dateStyle:'short', timeStyle:'short' }) + ' · ' : '';
      const name = item.first_title || (item.id === job.id && job.rows[0] && rowName(job.rows[0])) || item.first_filename;
      const papers = name ? name + (item.count > 1 ? ` 외 ${item.count - 1}편` : '') : `논문 ${item.count}편`;
      return new Option(`${index ? '' : '최근 · '}${stamp}${papers}`, item.id);
    }));
    $('History').value = job.id;
  }
  function showResult() {
    if (!job) return;
    const active = job.status === 'running';
    const done = job.rows.filter(row => row.status === 'completed').length;
    const failed = job.rows.filter(row => row.status === 'failed' || row.status === 'cancelled');
    const errors = failed.filter(row => row.status === 'failed').length;
    const current = job.rows.find(row => row.status === 'running');
    write($('JobHeading'), jobNames[job.status] || '작업 상태');
    write($('Counts'), `전체 ${job.rows.length}편 · 완료 ${done}편` + (errors ? ` · 실패 ${errors}편` : '') + (failed.length > errors ? ` · 중지 ${failed.length - errors}편` : '') + (current ? ` · 정리 중: ${rowName(current)}` : ''));
    $('Progress').hidden = !active; $('Progress').max = job.rows.length || 1; $('Progress').value = done + failed.length;
    write($('JobHint'), active ? '완료된 논문부터 표에 나타납니다. 창을 닫고 계속 읽을 수 있습니다.' : '논문 이름을 누르면 항목별 내용과 원문 근거를 볼 수 있습니다.');
    const entry = history.find(item => item.id === job.id);
    if (entry) entry.status = job.status;
    const snapshot = JSON.stringify([job.id, job.status, done, failed.length, current?.paper_id]);
    if (resultVersion !== snapshot) {
      renderTable(); if (detailId) showPaper(detailId, false); resultVersion = snapshot;
    }
    const actions = $('Actions');
    if (actions.dataset.jobState === job.id + ':' + job.status) return;
    actions.dataset.jobState = job.id + ':' + job.status;
    actions.replaceChildren();
    if (job.id === history[0]?.id && (active || failed.length || done < job.rows.length)) {
      const control = button(active ? '중지' : '남은 논문 다시 시작', 'ChangeJob');
      control.onclick = async () => {
        if (active && !await confirmDialog({ title: '남은 논문 정리를 중지할까요?', body: '완료된 논문은 표에 남습니다. 나중에 남은 논문만 다시 시작할 수 있습니다.', confirm: '중지' })) return;
        const seq = opening; setBusy(true); control.disabled = true; clearTimeout(poll); error('');
        try {
          if (!active && !await requireEngine(() => dialog.open && opening === seq)) return;
          if (!active && retryFor !== job.id) { retryFor = job.id; retryKey = crypto.randomUUID(); }
          const result = await post(`/jobs/${encodeURIComponent(job.id)}/${active ? 'cancel' : 'retry'}`, active ? {} : { request_id: retryKey });
          if (opening === seq) { retryFor = ''; job = result; showResult(); }
        } catch (e) { if (opening === seq) error(e); }
        finally { if (opening === seq) { control.disabled = false; setBusy(false); schedulePoll(); } }
      };
      actions.append(control);
    }
    $('Export').hidden = active;
    $('Formats').replaceChildren();
    if (!active) {
      const formats = job.format === 'csv' ? ['csv', 'xlsx'] : ['xlsx', 'csv'];
      for (const format of formats) {
        const a = document.createElement('a');
        a.href = BASE + `/jobs/${encodeURIComponent(job.id)}/export?format=${format}`;
        a.download = `Sunlight-review-${job.id.slice(0, 8)}.${format}`;
        a.textContent = format === 'xlsx' ? 'Excel (.xlsx)' : 'CSV (.csv)';
        $('Formats').append(a);
      }
      const note = document.createElement('p');
      note.className = 'review-note';
      note.textContent = (!done ? '완료된 논문이 없어 파일명과 처리 상태만 담깁니다. ' : done < job.rows.length ? '미완료 논문은 파일명과 상태가 함께 저장됩니다. ' : '') + 'CSV를 Excel로 열면 숫자 앞의 0이 사라질 수 있습니다.';
      $('Formats').append(note);
    }
    write($('Scope'), '');
    dialog.classList.toggle('has-review-commands', !!actions.children.length);
  }

  // Progress arrives as `review` push events; a timer runs only as the slow fallback while the stream is down.
  async function fetchJob() {
    if (page !== 'result' || !dialog.open || !job) return;
    if (fetching) { fetchAgain = true; return; }
    const seq = opening, id = job.id;
    fetching = true;
    try {
      const query = Number.isSafeInteger(job.revision) ? '?revision=' + job.revision : '';
      const result = await api(BASE + '/jobs/' + encodeURIComponent(id) + query, { timeout: 15000, cache: 'no-store' });
      if (!dialog.open || page !== 'result' || opening !== seq || job?.id !== id || busy) return;
      if (!result.unchanged) { job = result; showResult(); }
      error('');
    } catch { if (dialog.open && opening === seq && page === 'result') error('작업 상태를 불러오지 못했습니다. 다시 확인하고 있습니다.'); }
    finally {
      fetching = false;
      if (fetchAgain) { fetchAgain = false; void fetchJob(); } else if (opening === seq) schedulePoll();
    }
  }
  function schedulePoll() {
    clearTimeout(poll);
    if (page !== 'result' || !dialog.open || job?.status !== 'running') return;
    poll = setTimeout(fetchJob, kit.serverEventsLive?.() ? 60000 : FALLBACK_POLL);
  }

  // A table still being made when the dialog closes is watched in the background:
  // the 논문 비교표 buttons show it, and completion is announced with a way back to the table.
  function setBadge(running) {
    for (const b of document.querySelectorAll('[data-open-review]')) {
      if (running) { b.dataset.reviewState = 'running'; b.setAttribute('aria-description', '비교표를 만드는 중입니다'); }
      else { delete b.dataset.reviewState; b.removeAttribute('aria-description'); }
    }
  }
  function announceDone(id, state) {
    watching = null; clearTimeout(watchTimer); setBadge(false);
    if (dialog.open || state === 'cancelled') return;
    const text = state === 'completed' ? '논문 비교표 완료' : state === 'partial' ? '논문 비교표 일부 완료' : '논문 비교표를 끝내지 못했습니다';
    toast(text, { kind: state === 'completed' ? 'success' : state === 'partial' ? 'info' : 'error', ms: 10000,
      action: { label: '열기', run: () => open(context?.() || scope, document.querySelector('[data-open-review]'), { jobId: id }) } });
  }
  function watch(id) {
    watching = id; setBadge(true); clearTimeout(watchTimer);
    if (kit.serverEventsLive?.()) return;
    watchTimer = setTimeout(async () => {
      if (watching !== id || dialog.open) return;
      try {
        const result = await api(BASE + '/jobs/' + encodeURIComponent(id), { timeout: 15000, cache: 'no-store' });
        if (watching !== id || dialog.open) return;
        if (finished(result.status)) { announceDone(id, result.status); return; }
      } catch { /* keep watching */ }
      if (watching === id) watch(id);
    }, FALLBACK_POLL);
  }
  kit.onServerEvent?.('review', event => {
    if (!event?.job_id) return;
    const entry = history.find(item => item.id === event.job_id);
    if (entry && event.state) entry.status = event.state;
    if (dialog.open) { if (job?.id === event.job_id && page === 'result') void fetchJob(); return; }
    if (event.state === 'running' && watching !== event.job_id) watch(event.job_id);
    else if (finished(event.state) && watching === event.job_id) announceDone(event.job_id, event.state);
  });
  kit.onServerEventsState?.(live => { if (!live && watching && !dialog.open) watch(watching); else if (dialog.open) schedulePoll(); });

  function showPage(next) {
    page = next; clearTimeout(poll); error(''); say('');
    dialog.dataset.reviewPage = next; backToTable(false); $('Export').open = false;
    $('Draft').hidden = next !== 'draft'; $('Result').hidden = next !== 'result';
    $('New').setAttribute('aria-pressed', String(next === 'draft'));
    $('Recent').setAttribute('aria-pressed', String(next === 'result')); $('Recent').hidden = !history.length;
    $('Body').scrollTop = 0; delete $('Actions').dataset.jobState;
    if (next === 'draft') {
      const startButton = button('표 만들기', 'Start', true); startButton.onclick = start;
      $('Actions').replaceChildren(startButton); paintSelection(true);
      if (activeJob()) say('만드는 중인 표는 ‘최근 표 열기’에서 볼 수 있습니다.');
    } else { resultVersion = ''; renderHistory(); showResult(); schedulePoll(); $('JobHeading').focus({ preventScroll:true }); }
  }
  $('New').onclick = () => showPage('draft');
  write($('Recent'), '최근 표 열기');
  $('Recent').onclick = () => loadResult(history[0]?.id);
  $('Close').onclick = () => dialog.close();
  dialog.addEventListener('close', () => {
    if (dialog.open) return;
    opening++; clearTimeout(poll); importAbort?.abort(); backToTable(false); busy = false;
    const running = history.find(item => item.status === 'running');
    if (running) watch(running.id); else setBadge(false);
    if (opener?.isConnected) opener.focus({ preventScroll: true });
  });

  // opts.jobId opens that saved table; otherwise a running table, else the new-table form.
  async function open(libraryScope, trigger, opts = {}) {
    if (dialog.open) return;
    const seq = ++opening;
    scope = libraryScope; opener = trigger;
    watching = null; clearTimeout(watchTimer);
    const chosen = new Set(scope.selected);
    source = 'library'; localItems = [];
    dialog.querySelector('[name="reviewSource"][value="library"]').checked = true;
    $('Pc').hidden = true; $('Papers').open = scope.papers.length > 0;
    const titleCount = new Map();
    for (const p of scope.papers) { const k = nameKey(p.title || p.filename || ''); titleCount.set(k, (titleCount.get(k) || 0) + 1); }
    libraryItems = scope.papers.map(p => {
      const name = p.title || p.filename || '이름 없는 논문';
      const label = titleCount.get(nameKey(p.title || p.filename || '')) > 1 && p.filename && p.filename !== name ? `${name} · ${p.filename}` : name;
      return { paperId: p.id, label, selected: chosen.has(p.id) };
    });
    dialog.showModal(); showPage('draft'); setBusy(true); say('비교표를 불러오는 중…');
    try {
      const [settings, saved] = await Promise.all([
        settingsLoaded ? null : api(BASE + '/settings', { timeout: 12000 }),
        api(BASE + '/jobs', { timeout: 12000 }),
      ]);
      if (!dialog.open || opening !== seq) return;
      if (settings) {
        columns = settings.columns; $('Format').value = settings.format; $('Length').value = settings.length;
        settingsLoaded = true; renderColumns();
      }
      history = saved; job = null;
      providerChanged();
      setBusy(false); showPage('draft');
      const target = opts.jobId && history.some(item => item.id === opts.jobId) ? opts.jobId : activeJob() ? history[0].id : null;
      if (target) await loadResult(target);
    } catch (e) {
      if (!dialog.open || opening !== seq) return;
      setBusy(false); $('Start').disabled = true; say(''); write($('Error'), `비교표 설정을 불러오지 못했습니다. ${errorText(e)}`);
      const retry = button('다시 불러오기', 'Reload'); retry.onclick = () => { dialog.close(); setTimeout(() => open(libraryScope, trigger, opts), 0); }; $('Actions').append(retry);
    }
  }
  return { open, providerChanged };
}
