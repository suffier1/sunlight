// AI service connection state and the settings dialog. Owns S.settings / S.backends / S.models.
import { api, esc, toast, errorText, bindBackdropClose } from './ui-kit.js';
import { S, $, $$ } from './reader/state.js';
import { prepareAppExit, closeReader } from './reader/paper.js';

export const NO_SERVER = 'Sunlight 서버에 연결하지 못했습니다. Sunlight를 다시 실행한 뒤 이 화면에서 다시 시도하세요.';
const NAMES = { codex: 'Codex', claude: 'Claude', gemini: 'Gemini' };
const ACCOUNTS = { codex: 'ChatGPT 계정', claude: 'Claude 계정', gemini: 'Google 계정' };
export const engineName = (p = S.settings?.provider) => NAMES[p] || 'Codex';
export const isAuthExpired = err => err?.code === 'auth_expired' || /로그인이 만료/.test(errorText(err));
export const shortcutsEnabled = () => { try { return localStorage.getItem('sl.shortcuts') !== 'off'; } catch { return true; } };

const engineListeners = new Set();
export function onEngineChange(cb) { engineListeners.add(cb); }

let settingsRequest = null, settingsRevision = 0, refreshSettingsForm = null;
export async function loadSettings(bootstrap = false) {
  if (!bootstrap && settingsRequest) return settingsRequest;
  const revision = settingsRevision;
  if (!bootstrap) { S.statusPending = true; S.statusError = false; renderEngineBadge(); refreshSettingsForm?.(); }
  const request = (async () => {
    try {
      // A slow GET must not hold Chromium's HTTP cache lock ahead of a settings PUT.
      const r = await api(bootstrap ? '/api/settings?bootstrap=true' : '/api/settings', { cache: 'no-store' });
      // A discovery response started before the user saved must not undo that choice.
      if (revision === settingsRevision) S.settings = r.settings;
      if (!bootstrap) S.backends = r.backends || {};
      S.langs = r.langs || []; S.models = r.models || {};
      S.statusPending = false; S.statusError = r.settings_error || false;
      S.pdfFonts = r.pdf_fonts || [];
      S.appName = 'Sunlight';
      $('#appName').textContent = S.appName;
      $('#appVersion').textContent = r.version ? `v${r.version}` : '';
      if (!r.version) toast('이전 버전 서버가 실행 중입니다. 기존 Sunlight를 종료하고 새 버전을 실행하세요.', { kind: 'error', ms: 10000 });
      renderEngineBadge(); refreshSettingsForm?.();
      return r;
    } catch (e) {
      S.statusPending = false; S.statusError = errorText(e);
      renderEngineBadge(); refreshSettingsForm?.();
      throw e;
    } finally {
      if (!bootstrap) settingsRequest = null;
    }
  })();
  if (!bootstrap) settingsRequest = request;
  return request;
}
// After the first paint: discover the CLIs in the background so the first AI action does not wait.
export function warmSettings() {
  const run = () => { if (!S.backends && !settingsRequest) loadSettings().catch(() => {}); };
  if ('requestIdleCallback' in window) requestIdleCallback(run, { timeout: 2500 }); else setTimeout(run, 800);
}

export function chatScopeText() {
  return `질문과 논문 내용을 ${engineName()}에 보냅니다. 최근 대화와 첨부가 있으면 함께 보냅니다.`;
}
export function engineReady(p = S.settings?.provider) {
  const b = S.backends?.[p];
  return !S.statusPending && !S.statusError && b?.available && b.logged_in === true;
}
export function currentModel(p = S.settings?.provider) {
  if (p === 'claude') return S.settings?.claude_model || 'sonnet';
  return S.settings?.[`${p}_model`] || S.models?.[p]?.default || '기본';
}
export function renderEngineBadge() {
  const el = $('#engineBadge');
  if (el) el.textContent = S.statusPending ? 'AI 연결 확인 중' : engineReady() ? engineName() + ' 연결 설정' : 'AI 연결 설정';
  const ce = $('#chatEngine');
  if (ce) ce.textContent = engineReady() ? `${engineName()} · ${currentModel()}` : '';
  for (const cb of engineListeners) { try { cb(); } catch (e) { console.warn(e); } }
}
export async function requireEngine(isCurrent = () => true) {
  if (!engineReady()) {
    if (!S.backends || S.statusPending) toast('AI 연결을 확인하고 있습니다.');
    await loadSettings().catch(() => {});
  }
  if (!isCurrent()) return false;
  if (engineReady()) return true;
  openSettings(false);
  if (!S.statusError) toast('사용할 AI 계정을 연결하세요.', 5000);
  return false;
}

/* ---------------------------------------------------------------- dialog */
const EFFORT_LABEL = { minimal: '최소', low: '낮음', medium: '보통', high: '높음', xhigh: '매우 높음', max: '최대', ultra: 'Ultra' };
const settingsDialog = $('#settingsModal');
let settingsTrigger = null, loginPoll = null;
const hasGemini = () => !!(S.models?.gemini || S.backends?.gemini);

export function openSettings(refresh = true) {
  const s = S.settings;
  if (!s) { toast(NO_SERVER, { kind: 'error', ms: 6000 }); return; }
  const m = settingsDialog;
  if (m.open) return;
  settingsTrigger = document.activeElement;
  let prov = s.provider;
  let providerPicked = false;
  const picked = { codex: s.codex_model || '', claude: s.claude_model || 'sonnet', gemini: s.gemini_model || '' };
  const list = p => S.models?.[p]?.models || [];
  const modelOf = p => list(p).find(x => x.slug === (picked[p] || S.models?.[p]?.default)) || list(p)[0];
  const fillEfforts = () => {
    const model = modelOf(prov);
    // Gemini has no effort setting: an explicit empty list hides the choice (the saved value stays).
    const none = Array.isArray(model?.efforts) && !model.efforts.length || (prov === 'gemini' && !model?.efforts?.length);
    $('#effortRow').hidden = none;
    if (none) return;
    const efforts = model?.efforts?.length ? model.efforts : ['low', 'medium', 'high'];
    for (const [id, cur, fb] of [['#trEffort', $('#trEffort').value || s.translate_effort, 'low'], ['#chatEffort', $('#chatEffort').value || s.chat_effort, 'medium']]) {
      const v = efforts.includes(cur) ? cur : (efforts.includes(fb) ? fb : efforts[0]);
      $(id).innerHTML = efforts.map(e => `<option value="${esc(e)}" ${e === v ? 'selected' : ''}>${esc(EFFORT_LABEL[e] || e)}</option>`).join('');
    }
  };
  const fillModels = () => {
    const def = S.models?.[prov]?.default;
    $('#modelLabel').textContent = `${engineName(prov)} 모델`;
    // One default entry ("" = the service's own default), labelled with the server's Korean
    // default_name when it has one. Gemini's list may also contain that model (or "auto"): it is not
    // repeated. Codex keeps both, since pinning its current default is a real choice.
    const m = S.models?.[prov] || {};
    const own = list(prov).find(x => x.slug === def || (prov === 'gemini' && x.slug === 'auto'));
    const shown = list(prov).filter(x => !(prov === 'gemini' && x === own));
    const opts = shown.map(x => `<option value="${esc(x.slug)}">${esc(x.name)}${x === own ? ' (기본)' : ''}</option>`);
    if (prov !== 'claude') {
      const label = typeof m.default_name === 'string' && m.default_name.trim() ? m.default_name.trim()
        : `기본값 따르기 (${own?.name || def || `${engineName(prov)} 설정`})`;
      opts.unshift(`<option value="">${esc(label)}</option>`);
    }
    $('#modelSel').innerHTML = opts.join('');
    const want = prov === 'gemini' && own && picked[prov] === own.slug ? '' : picked[prov];
    $('#modelSel').value = want;
    if ($('#modelSel').value !== want) $('#modelSel').selectedIndex = 0;
    // a model's description only when the server has one (Korean or null)
    const chosen = list(prov).find(x => x.slug === ($('#modelSel').value || own?.slug || def));
    const desc = typeof chosen?.desc === 'string' ? chosen.desc.trim() : '';
    $('#modelDesc').textContent = desc;
    $('#modelDesc').hidden = !desc;
    fillEfforts();
  };
  $('#modelSel').onchange = () => { providerPicked = true; picked[prov] = $('#modelSel').value; fillModels(); };
  $('#trEffort').onchange = $('#chatEffort').onchange = () => { providerPicked = true; };
  clearInterval(loginPoll);  // a poll left by an earlier opening would keep resetting this form
  // after "connect": keep checking until the CLI reports a login (no manual "check again")
  const watch = () => {
    clearInterval(loginPoll);
    const until = Date.now() + 5 * 60 * 1000;
    let pending = false;  // one check at a time (it can take up to 20 s)
    const id = loginPoll = setInterval(async () => {
      if (!m.open || Date.now() > until) { clearInterval(id); return; }
      if (pending) return;
      pending = true;
      const r = await loadSettings().catch(() => null);
      pending = false;
      if (!r || loginPoll !== id || !m.open) return;
      if (engineReady(prov)) { clearInterval(id); toast(`${engineName(prov)} 연결됨`, { kind: 'success' }); }
      setProv(prov, !engineReady(prov));
    }, 3000);
  };
  const act = async what => {
    try {
      const r = await api(`/api/${prov}/${what}`, { method: 'POST' });
      toast(r?.how === 'browser' ? `${engineName(prov)} 설치 페이지를 열었습니다.` : '열린 창에서 계정 연결을 마치세요.', 7000);
      setProv(prov, true);
      watch();
    } catch (e) { toast(e, { kind: 'error' }); }
  };
  const setProv = (p, waiting = false) => {
    prov = p;
    $('#provSeg [data-p="gemini"]').hidden = !hasGemini() && p !== 'gemini';
    $$('#provSeg button').forEach(b => {
      b.classList.toggle('on', b.dataset.p === p);
      b.setAttribute('aria-pressed', String(b.dataset.p === p));
      const st = S.backends?.[b.dataset.p];
      const state = S.statusPending || st?.available && st.logged_in == null ? 'pending' : st?.available ? (st.logged_in === true ? 'ok' : 'login') : 'none';
      b.dataset.state = state;
      b.setAttribute('aria-description', { ok: '연결됨', login: '로그인 필요', none: '설치 안 됨', pending: '확인 중' }[state]);
    });
    const b = S.backends?.[p] || {};
    let h;
    if (S.statusPending) {
      h = '<span class="spinner sm"></span>연결 확인 중';
    } else if (S.statusError || b.available && b.logged_in == null) {
      const detail = typeof S.statusError === 'string' ? S.statusError : '연결 상태를 확인하지 못했습니다.';
      h = `<span class="bad">${esc(detail)}</span> <button type="button" class="link-btn" data-recheck>다시 확인</button>`;
    } else if (b.available && b.logged_in === true) {
      h = `<span class="good">연결됨</span>${b.account ? ` · ${esc(b.account)}` : ` · ${ACCOUNTS[p]}`}`;
      if (typeof b.path === 'string' && b.path) h += `<details class="sub cli-path"><summary>자세히</summary><code>${esc(b.path)}</code></details>`;
    } else if (waiting) {
      h = `<span class="spinner sm"></span>${ACCOUNTS[p]} 연결을 기다리는 중`;
    } else if (b.available) {
      h = `<span class="bad">${b.expired ? '로그인 만료' : '로그인 필요'}</span> <button type="button" class="link-btn" data-act="login">${ACCOUNTS[p]} ${b.expired ? '다시 ' : ''}연결하기</button>`;
    } else {
      const cli = { codex: 'Codex CLI', claude: 'Claude Code', gemini: 'Gemini CLI' }[p];
      const how = p === 'claude' ? 'Claude Code 설치 후 로그인을 진행합니다.'
        : S.backends?.npm ? `${cli} 설치 후 ${ACCOUNTS[p]} 로그인을 진행합니다.`
          : S.backends?.winget ? `Node.js와 ${cli}를 설치한 뒤 로그인을 진행합니다.`
            : `${engineName(p)} 설치 페이지를 엽니다.`;
      h = `<span class="bad">설치 안 됨</span> <button type="button" class="link-btn" data-act="install">설치하고 연결</button>
           <div class="sub">${esc(how)}</div>`;
    }
    const hint = $('#provHint');
    const focused = hint.contains(document.activeElement);
    hint.innerHTML = h;
    $('[data-recheck]', hint)?.addEventListener('click', () => loadSettings().catch(() => {}));
    $$('[data-act]', hint).forEach(x => x.onclick = () => act(x.dataset.act));
    if (focused) ($('button', hint) || $$('#provSeg button').find(x => x.dataset.p === p))?.focus();
    $('#provScope').textContent = `AI 기능을 실행하면 논문 내용이나 선택한 영역이 ${engineName(p)}에 전송됩니다.`;
    fillModels();
  };
  $$('#provSeg button').forEach(b => b.onclick = () => { providerPicked = true; setProv(b.dataset.p); });
  $('#trEffort').innerHTML = ''; $('#chatEffort').innerHTML = '';
  setProv(prov);
  $('#langSel').innerHTML = S.langs.map(l => `<option ${l === s.lang ? 'selected' : ''}>${esc(l)}</option>`).join('');
  $('#workers').value = s.workers;
  $('#shortcutsOn').checked = shortcutsEnabled();
  // PDF font: each choice shows a sample in its own face (files come from /api/fonts/…)
  let font = s.pdf_font || S.pdfFonts[0]?.id;
  if (!$('#pdfFontFaces') && S.pdfFonts.length) {
    const st = document.createElement('style');
    st.id = 'pdfFontFaces';
    st.textContent = S.pdfFonts.map(f => `@font-face { font-family: "SLpdf-${f.id}"; src: url("/api/fonts/${encodeURIComponent(f.file)}"); font-display: swap; }`).join(' ');
    document.head.append(st);
  }
  const fp = $('#fontPick');
  fp.closest('.field').classList.toggle('hidden', S.pdfFonts.length < 2);
  fp.innerHTML = S.pdfFonts.map(f => `<button type="button" data-f="${esc(f.id)}">
      <b>${esc(f.name)}</b><span style="font-family: 'SLpdf-${esc(f.id)}', serif">그림 1. 실험 결과</span></button>`).join('');
  const paintFontStates = () => $$('button', fp).forEach(b => {
    b.classList.toggle('on', b.dataset.f === font);
    b.setAttribute('aria-pressed', String(b.dataset.f === font));
  });
  $$('button', fp).forEach(b => b.onclick = () => { font = b.dataset.f; paintFontStates(); });
  paintFontStates();
  m.classList.remove('hidden');
  m.showModal();
  $$('#provSeg button').find(b => b.dataset.p === prov)?.focus({ preventScroll: true });
  refreshSettingsForm = () => {
    if (!providerPicked) prov = S.settings.provider;
    setProv(prov);
  };
  $$('[data-close]', m).forEach(b => b.onclick = closeSettings);
  $('#saveSettings').onclick = async () => {
    picked[prov] = $('#modelSel').value;
    const effortsShown = !$('#effortRow').hidden;
    try {
      ++settingsRevision;
      S.settings = await api('/api/settings', {
        method: 'PUT', body: {
          provider: prov, codex_model: picked.codex, claude_model: picked.claude || 'sonnet',
          ...(hasGemini() ? { gemini_model: picked.gemini } : {}),
          lang: $('#langSel').value, workers: Math.min(8, Math.max(1, Math.round(+$('#workers').value || 4))),
          translate_effort: effortsShown ? $('#trEffort').value : s.translate_effort,
          chat_effort: effortsShown ? $('#chatEffort').value : s.chat_effort,
          ...(font ? { pdf_font: font } : {}),
        },
      });
    } catch (e) { toast(`설정을 저장하지 못했습니다. ${errorText(e)}`, { kind: 'error' }); return; }
    try { localStorage.setItem('sl.shortcuts', $('#shortcutsOn').checked ? 'on' : 'off'); } catch { /* session only */ }
    const refont = font && font !== s.pdf_font;
    if (refont) settingsListeners.forEach(cb => cb({ refont: S.settings.pdf_font || font }));
    renderEngineBadge();
    closeSettings();
    toast(refont ? '번역 PDF에 새 글꼴을 적용하고 있습니다.' : '저장했습니다.', { kind: 'success', ms: refont ? 5000 : undefined });
  };
  if (refresh !== false) loadSettings().catch(() => {});
}
const settingsListeners = new Set();
export function onSettingsSaved(cb) { settingsListeners.add(cb); }

export function closeSettings() {
  clearInterval(loginPoll);
  refreshSettingsForm = null;
  if (!settingsDialog.open) return;
  settingsDialog.close();
  settingsDialog.classList.add('hidden');
  if (settingsTrigger?.isConnected) settingsTrigger.focus({ preventScroll: true });
  settingsTrigger = null;
}
settingsDialog.addEventListener('cancel', event => { event.preventDefault(); closeSettings(); });
bindBackdropClose(settingsDialog, closeSettings);
settingsDialog.addEventListener('keydown', event => {
  if (event.key !== 'Tab') return;
  const available = $$('button:enabled, input:enabled, select:enabled, summary', settingsDialog).filter(el => el.getClientRects().length);
  const from = event.shiftKey ? available[0] : available.at(-1);
  const to = event.shiftKey ? available.at(-1) : available[0];
  if (document.activeElement === from && to) { event.preventDefault(); to.focus(); }
});
$('#engineBadge').onclick = () => openSettings();

// Sunlight 종료 (the ⋯ menus; desktop-menu.js asks for confirmation first)
export async function exitApp() {
  await prepareAppExit();
  await api('/api/shutdown', { method: 'POST', body: {} });
  if (window.chrome?.webview) { window.chrome.webview.postMessage('sunlight-exit'); return; }
  closeSettings();
  closeReader();
  clearInterval(loginPoll);
  document.title = 'Sunlight 종료';
  const message = document.createElement('dialog');
  message.className = 'confirm-dialog';
  message.addEventListener('cancel', e => e.preventDefault());
  message.innerHTML = '<div class="confirm-card"><h2>Sunlight를 종료했습니다</h2><p>이 창을 닫아도 됩니다. 다시 열려면 Sunlight를 실행하세요.</p></div>';
  document.body.append(message);
  message.showModal();
}
