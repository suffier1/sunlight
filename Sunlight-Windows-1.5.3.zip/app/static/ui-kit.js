// Shared page helpers for the desktop UI (reader, library, review, phone control).
//
//   api(path, opt)            fetch wrapper → parsed JSON / text; throws ApiError {code, status, detail}
//   errorText(err)            Korean sentence for any error (what happened + what to do next)
//   errorDetail(err)          raw detail for a "자세히" disclosure ('' when there is nothing extra)
//   toast(msg, opt)           short notice; opt = number (ms) or {kind:'info'|'success'|'error', ms, action:{label, run}}
//                             (an action adds a focusable button; kind 'error' is announced with role="alert")
//   dismissToast(text?)       hide the visible notice (only if it still shows text)
//   confirmDialog(opt)        in-app confirmation → Promise<boolean>; opt = {title, body, confirm, cancel, danger}
//   esc(text)                 HTML-escape
//   bindBackdropClose(dialog, close)   close only when the press starts AND ends on the backdrop
//
// No module here reads or writes application state; everything is a pure helper or a DOM widget.

export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const HANGUL = /[가-힣]/;
const CODE_TEXT = {
  not_found: '찾을 수 없습니다. 목록을 새로 고친 뒤 다시 시도하세요.',
  busy: '다른 작업이 진행 중입니다. 끝난 뒤 다시 시도하세요.',
  invalid: '요청을 처리할 수 없습니다. 입력한 내용을 확인해 주세요.',
  storage_read: '저장된 파일을 읽지 못했습니다. 디스크와 보관 폴더를 확인해 주세요.',
  storage_write: '저장하지 못했습니다. 디스크 공간과 폴더 권한을 확인한 뒤 다시 시도하세요.',
  session: 'Sunlight 앱에서 열어 주세요.',
  auth_expired: 'AI 계정 로그인이 만료되었습니다. 설정에서 다시 연결하세요.',
  provider_missing: 'AI 서비스가 연결되어 있지 않습니다. 설정에서 연결하세요.',
  provider_failed: 'AI 서비스가 답하지 못했습니다. 잠시 후 다시 시도하세요.',
  timeout: '응답 시간이 초과되었습니다. 다시 시도하세요.',
  cancelled: '중지했습니다.',
  too_large: '파일이나 요청이 너무 큽니다. 범위를 줄여 다시 시도하세요.',
  unsupported: '지금 설정에서는 이 기능을 사용할 수 없습니다.',
  network: 'Sunlight 서버에 연결하지 못했습니다. Sunlight가 실행 중인지 확인하세요.',
};
const STATUS_CODE = { 401: 'session', 404: 'not_found', 408: 'timeout', 409: 'busy', 413: 'too_large', 422: 'invalid', 400: 'invalid', 504: 'timeout' };

export class ApiError extends Error {
  constructor({ code = '', status = 0, detail = '', raw = '' } = {}) {
    super('');
    this.name = 'ApiError';
    this.code = code; this.status = status; this.detail = detail; this.raw = raw;
    this.message = errorText(this);
  }
}

// err: ApiError | Error | DOMException | {code, detail|error} | string
export function errorText(err) {
  if (err == null) return '알 수 없는 오류가 발생했습니다. 다시 시도하세요.';
  if (typeof err === 'string') return HANGUL.test(err) ? err : '작업을 끝내지 못했습니다. 다시 시도하세요.';
  if (err.name === 'AbortError') return CODE_TEXT.cancelled;
  if (err.name === 'TimeoutError') return CODE_TEXT.timeout;
  const detail = typeof err.detail === 'string' ? err.detail.trim() : typeof err.error === 'string' ? err.error.trim() : '';
  // The server's Korean `detail` is the user message (contract §4); a code only fills in when it is missing.
  if (detail && HANGUL.test(detail)) return detail;
  if (err.code && CODE_TEXT[err.code]) return CODE_TEXT[err.code];
  if (err instanceof ApiError || err.name === 'ApiError') return '작업을 끝내지 못했습니다. 다시 시도하세요.';
  const message = typeof err.message === 'string' ? err.message.trim() : '';
  if (message && HANGUL.test(message)) return message;
  if (err instanceof TypeError) return CODE_TEXT.network;  // fetch() network failure
  return '작업을 끝내지 못했습니다. 다시 시도하세요.';
}
export function errorDetail(err) {
  if (!err || typeof err !== 'object') return '';
  // the server's untranslated detail (raw) first, then whatever the message was built from
  const raw = [err.raw, err.detail, err.error, err.name !== 'ApiError' ? err.message : ''].find(x => typeof x === 'string' && x.trim()) || '';
  const shown = errorText(err);
  const parts = [raw && raw !== shown ? raw : '', err.code ? `code: ${err.code}` : '', err.status ? `HTTP ${err.status}` : ''].filter(Boolean);
  return parts.join(' · ');
}

let sessionShown = false;
export function showSessionScreen() {
  if (sessionShown) return;
  sessionShown = true;
  eventSource?.close(); eventSource = null; clearTimeout(eventRetry);
  const screen = document.createElement('div');
  screen.className = 'session-screen';
  screen.setAttribute('role', 'alertdialog');
  screen.setAttribute('aria-modal', 'true');
  screen.setAttribute('aria-labelledby', 'sessionTitle');
  screen.innerHTML = `<div class="session-card"><h1 id="sessionTitle" tabindex="-1">Sunlight 앱에서 열어 주세요</h1>
    <p>이 창은 Sunlight 앱이 연 창이 아니어서 논문을 불러올 수 없습니다. 시작 메뉴나 바탕 화면의 Sunlight를 실행하세요.</p>
    <button type="button" class="btn">다시 확인</button></div>`;
  screen.querySelector('button').onclick = () => location.reload();
  for (const el of document.body.children) if (el !== screen) el.inert = true;
  document.querySelectorAll('dialog[open]').forEach(d => d.close());
  document.body.append(screen);
  screen.querySelector('h1').focus();
}

// opt: fetch options plus {timeout: ms, raw: true (return the Response, e.g. for streams)}.
// A plain-object body is sent as JSON; a string body is assumed to be JSON (legacy callers).
export async function api(path, opt = {}) {
  const { timeout, raw, ...init } = opt;
  const headers = new Headers(init.headers || {});
  if (init.body != null && !(init.body instanceof FormData) && !(init.body instanceof Blob)) {
    if (typeof init.body !== 'string') init.body = JSON.stringify(init.body);
    if (!headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  }
  init.headers = headers;
  if (timeout) init.signal = init.signal ? AbortSignal.any([init.signal, AbortSignal.timeout(timeout)]) : AbortSignal.timeout(timeout);
  let response;
  try { response = await fetch(path, init); } catch (error) {
    if (error?.name === 'AbortError' || error?.name === 'TimeoutError') {
      // AbortSignal.any keeps the reason; surface a timeout as code "timeout", a user stop as AbortError.
      if (init.signal?.reason?.name === 'TimeoutError' || error.name === 'TimeoutError') throw new ApiError({ code: 'timeout', detail: '' });
      throw error;
    }
    throw new ApiError({ code: 'network', detail: String(error?.message || '') });
  }
  if (!response.ok) {
    let body = null;
    try { body = await response.json(); } catch { /* not JSON */ }
    const code = typeof body?.code === 'string' ? body.code : STATUS_CODE[response.status] || '';
    const detail = typeof body?.detail === 'string' ? body.detail : typeof body?.error === 'string' ? body.error : response.statusText;
    const error = new ApiError({ code, status: response.status, detail, raw: typeof body?.raw === 'string' ? body.raw : '' });
    if (code === 'session') showSessionScreen();
    throw error;
  }
  if (raw) return response;
  if (response.status === 204) return null;
  return response.headers.get('content-type')?.includes('json') ? response.json() : response.text();
}

/* ---------------------------------------------------------------- server events (contract §9)
 * One EventSource per page on GET /api/events, shared by every module.
 *   onServerEvent(type, cb) → unsubscribe()   type: 'paper' | 'library' | 'review' | 'lifecycle' | …,
 *                                             cb(data) with the event's parsed JSON.
 *     Special type 'resync': fired after the stream (re)connects following a drop — refetch with normal GETs.
 *   serverEventsLive() → boolean              true while the stream is open; when false, poll slowly (≥15 s).
 *   onServerEventsState(cb) → unsubscribe()   cb(live) whenever that changes.
 * The stream opens on the first subscription. If the route is missing (older server) it retries every 60 s. */
const eventHandlers = new Map(), eventStates = new Set();
let eventSource = null, eventsLive = false, eventsEverOpen = false, eventRetry = 0;
function setEventsLive(value) {
  if (eventsLive === value) return;
  eventsLive = value;
  for (const cb of eventStates) { try { cb(value); } catch (e) { console.warn(e); } }
}
function emitServerEvent(type, data) {
  for (const cb of eventHandlers.get(type) || []) { try { cb(data); } catch (e) { console.warn(e); } }
}
function connectEvents() {
  if (eventSource || typeof EventSource === 'undefined' || sessionShown) return;
  clearTimeout(eventRetry);
  const source = eventSource = new EventSource('/api/events');
  source.onopen = () => {
    const again = eventsEverOpen;
    eventsEverOpen = true;
    setEventsLive(true);
    if (again) emitServerEvent('resync', {});
  };
  source.onerror = () => {
    setEventsLive(false);
    if (source.readyState === EventSource.CLOSED) {  // refused (404/401) — the browser will not retry by itself
      source.close();
      if (eventSource === source) eventSource = null;
      eventRetry = setTimeout(connectEvents, 60000);
    }
  };
  for (const type of eventHandlers.keys()) listenType(source, type);
}
function listenType(source, type) {
  // 'resync' is both a server event (this client fell behind) and the local reconnect signal
  if (source._types?.has(type)) return;
  (source._types ??= new Set()).add(type);
  source.addEventListener(type, e => {
    let data = null;
    try { data = JSON.parse(e.data); } catch { return; }
    emitServerEvent(type, data);
  });
}
export function onServerEvent(type, cb) {
  if (!eventHandlers.has(type)) eventHandlers.set(type, new Set());
  eventHandlers.get(type).add(cb);
  if (eventSource) listenType(eventSource, type); else connectEvents();
  return () => eventHandlers.get(type)?.delete(cb);
}
export const serverEventsLive = () => eventsLive;
export function onServerEventsState(cb) { eventStates.add(cb); return () => eventStates.delete(cb); }

/* ---------------------------------------------------------------- toast */
let toastTimer = 0;
function toastHost() {
  const dialogs = [...document.querySelectorAll('dialog[open]')];
  return dialogs.at(-1) || document.body;  // a modal dialog is in the top layer: show the notice inside it
}
function toastElements() {
  let status = document.getElementById('toast');
  if (!status) { status = document.createElement('div'); status.id = 'toast'; status.className = 'toast hidden'; status.setAttribute('role', 'status'); document.body.append(status); }
  let alert = document.getElementById('toastAlert');
  if (!alert) { alert = document.createElement('div'); alert.id = 'toastAlert'; alert.className = 'toast error hidden'; alert.setAttribute('role', 'alert'); document.body.append(alert); }
  return { status, alert };
}
// Hide the visible notice now (only if it still shows `text`, when given).
export function dismissToast(text) {
  for (const id of ['toast', 'toastAlert']) {
    const el = document.getElementById(id);
    if (el && !el.classList.contains('hidden') && (text == null || el.textContent.startsWith(text))) el.classList.add('hidden');
  }
}
export function toast(msg, opt = {}) {
  if (typeof opt === 'number') opt = { ms: opt };
  const kind = opt.kind || 'info';
  const text = typeof msg === 'string' ? msg : errorText(msg);
  const { status, alert } = toastElements();
  const el = kind === 'error' ? alert : status, other = el === status ? alert : status;
  other.classList.add('hidden');
  const host = toastHost();
  if (el.parentElement !== host) host.append(el);
  el.classList.toggle('success', kind === 'success');
  el.textContent = text;
  if (opt.action?.label && typeof opt.action.run === 'function') {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'toast-action'; b.textContent = opt.action.label;
    b.onclick = () => { el.classList.add('hidden'); opt.action.run(); };
    el.append(' ', b);
  }
  el.classList.remove('hidden');
  const ms = opt.ms ?? (opt.action ? 10000 : kind === 'error' ? 7000 : Math.min(9000, 2600 + text.length * 40));
  clearTimeout(toastTimer);
  const hide = () => el.classList.add('hidden');
  toastTimer = setTimeout(function wait() {
    // keep it while the pointer or the keyboard is on it
    if (el.matches(':hover') || el.contains(document.activeElement)) { toastTimer = setTimeout(wait, 1000); return; }
    hide();
  }, ms);
}

/* ---------------------------------------------------------------- dialogs */
export function bindBackdropClose(dialog, close) {
  let downOnBackdrop = false;
  dialog.addEventListener('pointerdown', e => { downOnBackdrop = e.target === dialog; });
  dialog.addEventListener('click', e => {
    const both = downOnBackdrop && e.target === dialog;
    downOnBackdrop = false;
    if (both) close();
  });
}

let confirmQueue = Promise.resolve();
export function confirmDialog({ title = '', body = '', confirm = '확인', cancel = '취소', danger = false } = {}) {
  const run = () => new Promise(resolve => {
    const trigger = document.activeElement;
    const d = document.createElement('dialog');
    d.className = 'confirm-dialog';
    d.setAttribute('aria-labelledby', 'confirmTitle');
    d.setAttribute('aria-describedby', 'confirmBody');
    d.innerHTML = `<form method="dialog" class="confirm-card"><h2 id="confirmTitle"></h2><div id="confirmBody" class="confirm-body"></div>
      <div class="confirm-foot"><button type="button" class="btn" value="cancel"></button><button type="submit" class="btn ${danger ? 'danger' : 'primary'}" value="ok"></button></div></form>`;
    d.querySelector('h2').textContent = title;
    d.querySelector('h2').hidden = !title;
    const bodyEl = d.querySelector('.confirm-body');
    for (const line of String(body).split('\n').filter(Boolean)) { const p = document.createElement('p'); p.textContent = line; bodyEl.append(p); }
    const [no, yes] = d.querySelectorAll('button');
    no.textContent = cancel; yes.textContent = confirm;
    let result = false;
    const finish = value => { result = value; if (d.open) d.close(); };
    no.onclick = () => finish(false);
    d.querySelector('form').onsubmit = e => { e.preventDefault(); finish(true); };
    d.addEventListener('cancel', e => { e.preventDefault(); finish(false); });
    bindBackdropClose(d, () => finish(false));
    d.addEventListener('close', () => {
      d.remove();
      if (trigger?.isConnected) trigger.focus({ preventScroll: true });
      resolve(result);
    }, { once: true });
    document.body.append(d);
    d.showModal();
    (danger ? no : yes).focus();
  });
  const next = confirmQueue.then(run, run);
  confirmQueue = next.catch(() => {});
  return next;
}

// An error in a panel: Korean message, an optional retry, raw detail behind "자세히".
export function errorBlock(err, { retry, retryLabel = '다시 시도', role = 'alert' } = {}) {
  const box = document.createElement('div');
  box.className = 'error-block';
  if (role) box.setAttribute('role', role);
  const p = document.createElement('p');
  p.textContent = errorText(err);
  box.append(p);
  const detail = errorDetail(err);
  if (detail) {
    const more = document.createElement('details');
    more.className = 'error-detail';
    more.innerHTML = '<summary>자세히</summary><code></code>';
    more.querySelector('code').textContent = detail;
    box.append(more);
  }
  if (retry) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'btn sm'; b.textContent = retryLabel;
    b.onclick = retry;
    const acts = document.createElement('div');
    acts.className = 'err-acts'; acts.append(b);
    box.append(acts);
  }
  return box;
}
