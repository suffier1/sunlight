const PARALLEL_UPLOADS = 2;
const MODE_KEY = 'sunlight.import.mode';

const uploadError = (detail, code, status = 0) => Object.assign(new Error(detail), { detail, code, status });

// Rejects with {code, status, detail} like ui-kit's api(), so errorText() can word it.
export function sendPdf(file, withAI, report, signal) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `/api/papers?mode=${withAI ? 'ai' : 'original'}`);
    xhr.timeout = 180000;
    const abort = () => xhr.abort();
    if (signal?.aborted) { reject(new DOMException('PDF 추가를 취소했습니다.', 'AbortError')); return; }
    signal?.addEventListener('abort', abort, { once: true });
    xhr.onloadend = () => signal?.removeEventListener('abort', abort);
    xhr.onabort = () => reject(new DOMException('PDF 추가를 취소했습니다.', 'AbortError'));
    xhr.responseType = 'json';
    xhr.upload.onprogress = event => {
      if (event.lengthComputable && event.total) report(Math.min(99, Math.floor(event.loaded * 100 / event.total)));
    };
    xhr.upload.onload = () => report(null);
    xhr.onerror = () => reject(uploadError('Sunlight 서버에 연결하지 못했습니다. Sunlight가 실행 중인지 확인한 뒤 다시 시도하세요.', 'network'));
    xhr.ontimeout = () => reject(uploadError('파일 등록 확인이 3분 넘게 걸렸습니다. 라이브러리에 추가되었는지 확인한 뒤 다시 시도하세요.', 'timeout'));
    xhr.onload = () => {
      const result = xhr.response;
      if (xhr.status >= 200 && xhr.status < 300 && typeof result?.id === 'string' && result.id) { resolve(result); return; }
      const status = xhr.status;
      const fallback = status === 413 ? '파일이 너무 큽니다. 300MB 이하의 PDF를 선택하세요.'
        : status === 401 ? 'Sunlight 앱에서 열어 주세요.'
          : [400, 415, 422].includes(status) ? 'PDF로 열 수 없는 파일입니다. 원본 PDF를 확인하세요.'
            : 'PDF를 추가하지 못했습니다. 다시 시도하세요.';
      const detail = typeof result?.detail === 'string' && /[가-힣]/.test(result.detail) ? result.detail : fallback;
      const error = uploadError(detail, typeof result?.code === 'string' ? result.code : '', status);
      error.invalid = [400, 413, 415, 422].includes(status) || ['invalid', 'too_large', 'unsupported'].includes(error.code);
      reject(error);
    };
    const form = new FormData();
    form.append('file', file);
    xhr.send(form);
  });
}

// kit: ui-kit ({api, toast, errorText}). Files dropped on the reader are added as 원문 (no AI) and offered to open.
export function bindPdfImport({ kit, context, inLibrary, requireEngine, onAdded, onOpen }) {
  const { api, toast, errorText } = kit;
  const library = document.querySelector('#library');
  const drop = document.querySelector('#drop');
  const dropZone = document.querySelector('#libDropZone');
  const input = document.querySelector('#fileInput');
  const modes = [...document.querySelectorAll('[name="libImportMode"]')];
  // Each radio is named by its choice alone; the explanation under it is its description.
  for (const radio of modes) {
    radio.setAttribute('aria-label', radio.value === 'ai' ? '추가하면서 번역·요약' : '원문만 추가');
    const hint = radio.closest('label')?.querySelector('small');
    if (hint) { hint.id ||= `libImportModeHint-${radio.value}`; radio.setAttribute('aria-describedby', hint.id); }
  }
  const panel = document.querySelector('#uploadPanel');
  const status = document.querySelector('#uploadStatus');
  const list = document.querySelector('#uploadList');
  const jobs = new Set();
  const pending = [];
  let running = 0, newest = null, added = 0, duplicates = 0, restored = 0, refreshTimer, successTimer, modeChange = 0;
  let mode = 'ai';
  try { if (localStorage.getItem(MODE_KEY) === 'original') mode = 'original'; } catch { /* preference only */ }

  function announce() {
    clearTimeout(successTimer);
    const active = jobs.size - [...jobs].filter(job => job.failed).length;
    const failed = jobs.size - active;
    const message = [
      active && `${active}개 처리 중`, added && `${added}편 추가`,
      duplicates && `${duplicates}편 이미 있음`, restored && `${restored}편 복구`, failed && `${failed}개 확인 필요`,
    ].filter(Boolean).join(' · ');
    panel.classList.toggle('hidden', !message);
    if (status.textContent !== message) status.textContent = message;
    if (!jobs.size && message) successTimer = setTimeout(() => {
      added = duplicates = restored = 0;
      announce();
    }, 6000);
  }

  function refreshLibrary() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => { if (inLibrary()) onAdded(); }, 80);
  }

  function remove(job) {
    const focused = job.row.contains(document.activeElement);
    jobs.delete(job);
    job.row.remove();
    if (focused && inLibrary()) (list.querySelector('button:not(.hidden)') || drop).focus({ preventScroll: true });
  }

  function show(job, message, { progress = false, retry = '', choice = '', dismiss = '' } = {}) {
    if (document.activeElement.matches('button') && job.row.contains(document.activeElement)) job.row.focus({ preventScroll: true });
    job.text.textContent = message;
    job.progress.classList.toggle('hidden', !progress);
    if (progress) job.progress.removeAttribute('value');
    for (const [button, label] of [[job.retry, retry], [job.choice, choice], [job.dismiss, dismiss]]) {
      button.classList.toggle('hidden', !label);
      button.textContent = label;
      if (label) button.setAttribute('aria-label', `${job.file.name} · ${label}`);
    }
  }

  function enqueue(job) {
    job.failed = false;
    show(job, '대기');
    pending.push(job);
    announce();
    pump();
  }

  function fail(job, message, options) {
    job.failed = true;
    job.row.classList.add('upload-needs-attention');
    show(job, message, options);
    if (document.activeElement === job.row) {
      (job.row.querySelector('button:not(.hidden)') || drop).focus({ preventScroll: true });
    }
    announce();
    settle(job.batch, null, message);
  }

  // A batch dropped on the reader reports once, when every file has an outcome.
  function settle(batch, paper, problem) {
    if (!batch.fromReader || batch.reported) return;
    batch.settled++;
    if (paper) { batch.ok++; batch.paper = paper; }
    if (problem) batch.problem = problem;
    if (batch.settled < batch.count) return;
    batch.reported = true;
    const failed = batch.count - batch.ok;
    if (failed) {
      toast(batch.count === 1 ? `PDF를 추가하지 못했습니다 · ${batch.problem}` : `PDF ${failed}개를 추가하지 못했습니다. 홈의 추가 목록에서 확인하세요.`,
        { kind: 'error', action: { label: '홈으로', run: () => { location.hash = '#/'; } } });
    } else if (batch.ok === 1) {
      const id = batch.paper.id;
      toast(batch.paper.duplicate ? '이미 라이브러리에 있는 PDF입니다' : '라이브러리에 추가했습니다',
        { kind: 'success', ms: 8000, action: { label: '열기', run: () => onOpen(id) } });
    } else toast(`PDF ${batch.ok}편을 라이브러리에 추가했습니다`, { kind: 'success' });
  }

  function addJob(file, batch) {
    const row = document.createElement('li');
    row.className = 'upload-row';
    row.tabIndex = -1;
    row.innerHTML = '<div class="upload-file"><strong></strong><span></span><progress max="100" class="hidden"></progress></div><div class="upload-actions"><button type="button" class="btn sm hidden"></button><button type="button" class="btn sm hidden"></button><button type="button" class="link hidden"></button></div>';
    row.querySelector('strong').textContent = file.name;
    const [retry, choice, dismiss] = row.querySelectorAll('button');
    const job = { file, batch, row, retry, choice, dismiss, text: row.querySelector('span'), progress: row.querySelector('progress'), withAI: batch.withAI };
    job.progress.setAttribute('aria-label', `${file.name} 전송`);
    retry.onclick = () => { batch.engine = null; enqueue(job); };
    choice.onclick = () => { job.withAI = false; enqueue(job); };
    dismiss.onclick = () => { remove(job); announce(); };
    jobs.add(job);
    list.append(row);
    if (!/\.pdf$/i.test(file.name) || !file.size) {
      fail(job, file.size ? 'PDF 파일이 아닙니다. 확장자가 .pdf인 파일을 선택하세요.' : '비어 있는 파일입니다. 원본 PDF를 확인하세요.', { dismiss: '목록에서 닫기' });
    } else enqueue(job);
  }

  async function process(job) {
    const { batch, file } = job;
    try {
      if (!job.paper) {
        if (job.withAI) {
          show(job, 'AI 연결 확인 중');
          batch.engine ??= requireEngine(() => jobs.has(job));
          if (!await batch.engine) {
            fail(job, 'AI가 연결되어 있지 않아 번역·요약과 함께 추가하지 못했습니다.', { retry: 'AI 연결 후 다시 시도', choice: '원문만 추가', dismiss: '목록에서 닫기' });
            return;
          }
        }
        show(job, 'PDF 전송 중', { progress: true });
        job.paper = await sendPdf(file, job.withAI, value => {
          if (value === null) show(job, '전송 완료 · 등록 확인 중');
          else job.progress.value = value;
        });
      }
      const paper = job.paper;
      if (batch.folder && !paper.duplicate && !paper.restored) {
        show(job, `‘${batch.targetName}’에 넣는 중`);
        await api('/api/library/move', {
          method: 'POST', body: { paper_ids: [paper.id], folder_id: batch.folder }, timeout: 15000,
        });
      }
      if (paper.restored) restored++;
      else if (paper.duplicate) duplicates++;
      else added++;
      const current = context();
      const open = !batch.fromReader && batch === newest && batch.count === 1 && jobs.size === 1 && inLibrary()
        && current.scope === batch.scope && current.viewRevision === batch.viewRevision && current.viewFolder === batch.viewFolder;
      remove(job);
      announce();
      settle(batch, paper);
      if (open) {
        if (paper.restored) toast('원본 PDF를 복구했습니다. 기존 메모를 다시 열 수 있습니다.', { ms: 5000 });
        else if (paper.duplicate) toast(job.withAI && paper.status === 'original'
          ? '이미 추가한 PDF입니다. 열린 논문에서 번역이나 요약을 시작하세요.'
          : '이미 추가한 PDF를 열었습니다.', { ms: 5000 });
        onOpen(paper.id);
      } else refreshLibrary();
    } catch (error) {
      if (job.paper) {
        fail(job, `PDF는 추가했지만 ‘${batch.targetName}’에 넣지 못했습니다 · ${errorText(error)}`, { retry: '폴더 이동 다시 시도', dismiss: '목록에서 닫기' });
        refreshLibrary();
      } else fail(job, errorText(error), { retry: error.invalid ? '' : '다시 시도', dismiss: '목록에서 닫기' });
    }
  }

  function pump() {
    while (running < PARALLEL_UPLOADS && pending.length) {
      const job = pending.shift();
      running++;
      job.row.classList.remove('upload-needs-attention');
      process(job).finally(() => { running--; pump(); });
    }
  }

  function importFiles(files, fromReader = false) {
    if (!files.length) return;
    if (!jobs.size) added = duplicates = restored = 0;
    const batch = { ...context(), count: files.length, withAI: mode === 'ai', fromReader, settled: 0, ok: 0 };
    if (fromReader) batch.folder = null;
    newest = batch;
    for (const file of files) addJob(file, batch);
  }

  // The 추가 방식 choice is remembered; the button shows it so AI use is visible where the user acts.
  function displayImportMode() {
    for (const radio of modes) radio.checked = radio.value === mode;
    const ai = mode === 'ai';
    library.classList.toggle('has-import-ai', ai);
    drop.querySelector('.drop-mode')?.classList.toggle('hidden', !ai);
    drop.setAttribute('aria-label', ai ? 'PDF 추가 (번역·요약 함께)' : 'PDF 추가');
  }
  for (const radio of modes) radio.addEventListener('change', async () => {
    if (!radio.checked) return;
    const change = ++modeChange;
    mode = radio.value === 'ai' ? 'ai' : 'original';
    displayImportMode();
    if (mode === 'ai' && !await requireEngine(() => change === modeChange && mode === 'ai' && inLibrary())) {
      if (change !== modeChange) return;
      mode = 'original';
      displayImportMode();
    }
    if (change === modeChange) { try { localStorage.setItem(MODE_KEY, mode); } catch { /* preference only */ } }
  });
  displayImportMode();

  drop.onclick = () => input.click();
  for (const button of document.querySelectorAll('[data-pick-pdf]')) button.onclick = () => input.click();
  input.onchange = () => { importFiles([...input.files]); input.value = ''; };
  const zones = [drop, dropZone].filter(Boolean);
  document.body.addEventListener('dragover', event => {
    if (!event.dataTransfer?.types.includes('Files')) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
    library.classList.toggle('file-dragover', inLibrary());
    document.body.classList.toggle('file-dragover', !inLibrary());
    for (const zone of zones) zone.classList.toggle('over', inLibrary() && zone.contains(event.target));
  });
  const clearDrag = () => {
    library.classList.remove('file-dragover');
    document.body.classList.remove('file-dragover');
    for (const zone of zones) zone.classList.remove('over');
  };
  document.body.addEventListener('dragleave', event => {
    if (!event.relatedTarget || !document.body.contains(event.relatedTarget)) clearDrag();
  });
  for (const zone of zones) zone.addEventListener('dragleave', event => { if (!zone.contains(event.relatedTarget)) zone.classList.remove('over'); });
  document.body.addEventListener('drop', event => {
    const files = event.dataTransfer?.files;
    if (!files?.length) return;
    event.preventDefault();
    clearDrag();
    importFiles([...files], !inLibrary());
  });
}
