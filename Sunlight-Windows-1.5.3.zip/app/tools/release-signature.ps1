# Shared, side-effect-free release signature functions for Windows clients and the publisher.
# Only these fields are authenticated. Extra index metadata is not used by the updater.
function Get-ReleaseCanonicalBytes($Index) {
    if ($Index.version -isnot [string] -or $Index.version -cnotmatch '^[0-9]+\.[0-9]+\.[0-9]+$' -or
        $Index.filename -isnot [string] -or $Index.filename -cnotmatch '^[A-Za-z0-9][A-Za-z0-9._-]{0,127}\.zip$' -or
        $Index.sha256 -isnot [string] -or $Index.sha256 -cnotmatch '^[0-9A-Fa-f]{64}$' -or
        $null -eq $Index.size -or [string]$Index.size -cnotmatch '^[0-9]+$') { throw 'The signed release fields are invalid.' }
    $null = [version]$Index.version
    [long]$size = $Index.size
    if ($size -lt 1 -or $size -gt 1GB) { throw 'The signed release size is outside the permitted range.' }
    $integer = $size.ToString([Globalization.CultureInfo]::InvariantCulture)
    $canonical = 'sunlight-windows-update-v1' + "`n" + $Index.version + "`n" + $Index.filename + "`n" + $integer + "`n" + $Index.sha256.ToLowerInvariant() + "`n"
    return ,([Text.Encoding]::ASCII.GetBytes($canonical))
}

function ConvertTo-ReleaseKeyXml([string]$KeyXml, [switch]$PublicOnly) {
    if (-not $KeyXml -or $KeyXml.Length -gt 65536) { throw 'The release signing key is missing or invalid.' }
    $settings = New-Object Xml.XmlReaderSettings
    $settings.DtdProcessing = [Xml.DtdProcessing]::Prohibit
    $settings.XmlResolver = $null
    $text = New-Object IO.StringReader($KeyXml)
    $reader = [Xml.XmlReader]::Create($text, $settings)
    try {
        $document = New-Object Xml.XmlDocument
        $document.XmlResolver = $null
        $document.Load($reader)
        if ($document.DocumentElement.Name -cne 'RSAKeyValue') { throw 'The release signing key must be an RSA XML key.' }
        if ($PublicOnly) {
            $elements = @($document.DocumentElement.ChildNodes | Where-Object { $_.NodeType -eq [Xml.XmlNodeType]::Element })
            if ($elements.Count -ne 2 -or @($elements | Where-Object { $_.Name -ceq 'Modulus' }).Count -ne 1 -or
                @($elements | Where-Object { $_.Name -ceq 'Exponent' }).Count -ne 1) { throw 'The trusted release key must contain public parameters only.' }
        }
        return $document.DocumentElement.OuterXml
    } finally { $reader.Dispose(); $text.Dispose() }
}

function New-ReleaseSignature($Index, [Security.Cryptography.RSA]$Key) {
    return New-PublisherSignature (Get-ReleaseCanonicalBytes $Index) $Key
}

function Get-InstallerCanonicalBytes($Manifest) {
    if (($Manifest.schema -isnot [int] -and $Manifest.schema -isnot [long]) -or $Manifest.schema -ne 1 -or $Manifest.version -isnot [string] -or
        $Manifest.version -cnotmatch '\A[0-9]+\.[0-9]+\.[0-9]+\z' -or
        $Manifest.filename -cne "Sunlight-Setup-$($Manifest.version).exe" -or
        $Manifest.sha256 -isnot [string] -or $Manifest.sha256 -cnotmatch '\A[0-9A-Fa-f]{64}\z' -or
        ($Manifest.size -isnot [int] -and $Manifest.size -isnot [long]) -or
        $Manifest.size -lt 1 -or $Manifest.size -gt 256MB) { throw 'Invalid installer manifest fields.' }
    if (([version]$Manifest.version).ToString(3) -cne $Manifest.version) { throw 'Invalid installer version.' }
    $size = $Manifest.size.ToString([Globalization.CultureInfo]::InvariantCulture)
    $lines = @('sunlight-windows-installer-v1', $Manifest.version, $Manifest.filename, $size, $Manifest.sha256.ToLowerInvariant(), '')
    return ,([Text.Encoding]::ASCII.GetBytes(($lines -join [char]10)))
}

function New-PublisherSignature([byte[]]$Data, [Security.Cryptography.RSA]$Key) {
    if ($null -eq $Key -or $Key.KeySize -ne 3072) { throw 'Release signatures require an RSA 3072-bit key.' }
    # The publisher owns this key. It can be a non-exportable CurrentUser CSP key.
    $signed = $Key.SignData($Data, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)
    return [Convert]::ToBase64String($signed)
}

function Test-ReleaseSignature($Index, [string]$PublicKeyXml) {
    return Test-PublisherSignature (Get-ReleaseCanonicalBytes $Index) $Index.signature $PublicKeyXml
}

function Test-PublisherSignature([byte[]]$Data, $EncodedSignature, [string]$PublicKeyXml) {
    if ($EncodedSignature -isnot [string] -or $EncodedSignature.Length -ne 512) { return $false }
    try { $signature = [Convert]::FromBase64String($EncodedSignature) } catch { return $false }
    if ($signature.Length -ne 384) { return $false }
    $xml = ConvertTo-ReleaseKeyXml $PublicKeyXml -PublicOnly
    $rsa = New-Object Security.Cryptography.RSACng
    try {
        $rsa.FromXmlString($xml)
        if ($rsa.KeySize -ne 3072) { throw 'The trusted release key must be RSA 3072-bit.' }
        return $rsa.VerifyData($Data, $signature, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)
    } finally { $rsa.Dispose() }
}

function Get-PackageCanonicalBytes($Manifest) {
    if ($Manifest.layout -ne 1 -or $Manifest.version -isnot [string] -or
        $Manifest.version -cnotmatch '\A[0-9]+\.[0-9]+\.[0-9]+\z' -or
        $Manifest.files -isnot [array] -or $Manifest.files.Count -lt 1 -or $Manifest.files.Count -gt 8192) {
        throw 'The package manifest header is invalid.'
    }
    $null = [version]$Manifest.version
    $culture = [Globalization.CultureInfo]::InvariantCulture
    $lines = [Collections.Generic.SortedDictionary[string,string]]::new([StringComparer]::Ordinal)
    $paths = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $Manifest.files) {
        if ($entry.path -isnot [string] -or $entry.path.Length -gt 512 -or
            $entry.path -cnotmatch '\A[A-Za-z0-9_.@ /+-]+\z' -or
            $entry.path -match '\A/|/\z|//|(^|/)\.{1,2}(/|$)' -or
            -not $paths.Add($entry.path) -or $null -eq $entry.size -or [string]$entry.size -cnotmatch '\A[0-9]+\z' -or
            $entry.sha256 -isnot [string] -or $entry.sha256 -cnotmatch '\A[0-9a-fA-F]{64}\z') { throw 'A signed package file entry is invalid.' }
        [long]$size = $entry.size
        if ($size -gt 1GB) { throw 'A signed package file exceeds the size limit.' }
        $lines.Add($entry.path, $entry.path + "`t" + $size.ToString($culture) + "`t" + $entry.sha256.ToLowerInvariant())
    }
    $canonical = "sunlight-windows-package-v1`n1`n" + $Manifest.version + "`n" + $lines.Count.ToString($culture) + "`n" + ($lines.Values -join "`n") + "`n"
    return ,([Text.Encoding]::ASCII.GetBytes($canonical))
}

function New-PackageSignature($Manifest, [Security.Cryptography.RSA]$Key) {
    return New-PublisherSignature (Get-PackageCanonicalBytes $Manifest) $Key
}

function Test-PackageSignature($Manifest, [string]$PublicKeyXml) {
    return Test-PublisherSignature (Get-PackageCanonicalBytes $Manifest) $Manifest.signature $PublicKeyXml
}

# v2 index signature: v1 fields plus a validity window (issued/expires, UTC "yyyy-MM-ddTHH:mm:ssZ").
# Old clients ignore these fields and keep verifying "signature" (v1); 1.5.0+ require signature_v2
# on the official feed so an old index cannot be replayed after it expires.
function Get-ReleaseCanonicalBytesV2($Index) {
    $v1 = [Text.Encoding]::ASCII.GetString((Get-ReleaseCanonicalBytes $Index)) -replace '^sunlight-windows-update-v1', 'sunlight-windows-update-v2'
    foreach ($field in 'issued', 'expires') {
        if ($Index.$field -isnot [string] -or $Index.$field -cnotmatch '\A[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z\z') { throw "The signed release $field time is invalid." }
    }
    if ([string]::CompareOrdinal($Index.expires, $Index.issued) -le 0) { throw 'The release index expires before it is issued.' }
    return ,([Text.Encoding]::ASCII.GetBytes($v1 + $Index.issued + "`n" + $Index.expires + "`n"))
}

function Test-ReleaseSignatureV2($Index, [string]$PublicKeyXml) {
    return Test-PublisherSignature (Get-ReleaseCanonicalBytesV2 $Index) $Index.signature_v2 $PublicKeyXml
}
