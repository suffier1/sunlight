// Google Drive: PDF 추가 ▾ → "Google Drive에서 선택" opens Google's own picker in the default browser. The PDFs and folders
// chosen there are added to the library (the server downloads them); each shows a Drive mark.
import { api, toast, errorText } from './ui-kit.js';
import { requireEngine } from './settings.js';

const MODE_KEY = 'sunlight.import.mode';
const button = document.querySelector('#driveAdd');
const box = document.querySelector('#driveStatus');
let polling = 0, lastFinished = 0, watching = false;

const importMode = () => { try { return localStorage.getItem(MODE_KEY) === 'original' ? 'original' : 'ai'; } catch { return 'ai'; } };

function show(parts, { tone = '', sticky = false } = {}) {
  box.replaceChildren(...parts.map(p => typeof p === 'string' ? document.createTextNode(p) : p));
  box.className = `drive-status${tone ? ' ' + tone : ''}`;
  box.hidden = false;
  clearTimeout(box._hide);
  if (!sticky) box._hide = setTimeout(() => { box.hidden = true; }, 9000);
}
function hide() { clearTimeout(box._hide); box.hidden = true; }

function linkButton(text, onClick) {
  const b = document.createElement('button'); b.type = 'button'; b.className = 'link'; b.textContent = text; b.onclick = onClick; return b;
}

function report(st) {
  const bits = [st.added && `${st.added}편 추가`, st.duplicates && `${st.duplicates}편 이미 있음`, st.failed?.length && `${st.failed.length}개 추가하지 못함`].filter(Boolean);
  const parts = [`Google Drive · ${bits.join(' · ') || '추가한 파일이 없습니다'}`];
  if (st.message) { const note = document.createElement('span'); note.className = 'drive-note'; note.textContent = st.message; parts.push(note); }
  if (st.failed?.length) {
    const more = document.createElement('details');
    more.innerHTML = '<summary>자세히</summary><ul></ul>';
    for (const f of st.failed.slice(0, 20)) {
      const li = document.createElement('li'); li.textContent = `${f.name} · ${f.reason}`; more.querySelector('ul').append(li);
    }
    parts.push(more);
  }
  show(parts, { tone: st.failed?.length ? 'warn' : '', sticky: !!st.failed?.length || !!st.message });
}

async function poll() {
  clearTimeout(polling);
  let st;
  try { st = (await api('/api/drive')).status; } catch { polling = setTimeout(poll, 3000); return; }
  if (st.state === 'importing') {
    const counts = st.total ? ` ${Math.min(st.done + 1, st.total)}/${st.total}` : '';
    show([`Google Drive에서 가져오는 중${counts}${st.current ? ' · ' + st.current : ''}`], { sticky: true });
  } else if ((st.state === 'done' || st.state === 'error') && st.finished && st.finished !== lastFinished) {
    lastFinished = st.finished;
    if (st.state === 'error') show([`Google Drive · ${st.message || '가져오지 못했습니다.'}`], { tone: 'warn', sticky: true });
    else report(st);
    watching = false;
    return;
  } else if (st.state === 'idle' && watching) {
    hide(); watching = false; return;
  }
  if (watching) polling = setTimeout(poll, st.state === 'importing' ? 800 : 1500);
}

async function pick() {
  const mode = importMode();
  if (mode === 'ai' && !await requireEngine()) return;
  button.disabled = true;
  try {
    const { url, opened } = await api('/api/drive/pick', { method: 'POST', body: { mode } });
    const again = document.createElement('a');
    again.href = url; again.target = '_blank'; again.rel = 'noopener'; again.textContent = '여기를 눌러 여세요';
    show([opened ? '브라우저에서 Google Drive의 PDF를 고르세요. 폴더를 열어 여러 개를 한 번에 고를 수 있습니다. 창이 보이지 않으면 ' : '브라우저에서 Google Drive를 열어 PDF를 고르세요. 폴더를 열어 여러 개를 한 번에 고를 수 있습니다. ', again, ' · ',
      linkButton('취소', () => { watching = false; clearTimeout(polling); hide(); })], { sticky: true });
    try { lastFinished = (await api('/api/drive')).status.finished || lastFinished; } catch { /* the poll catches up */ }
    watching = true;
    poll();
  } catch (e) {
    toast(`Google Drive를 열지 못했습니다. ${errorText(e)}`, { kind: 'error' });
  } finally { button.disabled = false; }
}

async function init() {
  if (!button) return;
  try {
    const { available, status } = await api('/api/drive');
    button.hidden = !available;
    lastFinished = status?.finished || 0;
    if (status?.state === 'importing') { watching = true; poll(); }
  } catch { button.hidden = true; }
  button.onclick = () => { closeMenu(); pick(); };
  // Choosing where to add from closes the PDF 추가 ▾ menu (this PC opens the file dialog).
  document.querySelector('.import-sources [data-pick-pdf]')?.addEventListener('click', closeMenu);
}
function closeMenu() { const menu = document.querySelector('#libImportOptions'); if (menu) menu.open = false; }
init();

// A paper's Drive original, opened in the browser (리더 ⋯ 메뉴).
export const driveLink = paper => paper?.source?.kind === 'drive' && /^[A-Za-z0-9_-]{10,200}$/.test(paper.source.id || '')
  ? `https://drive.google.com/file/d/${paper.source.id}/view` : '';
