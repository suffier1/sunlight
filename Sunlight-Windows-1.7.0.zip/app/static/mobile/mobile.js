import { createUploads, forgetTransfers } from './uploads.js';
import { failure } from './errors.js';
import { pdfLink } from './links.js';

const $ = id => document.getElementById(id);
const NOT_MODIFIED = Symbol('not modified');
const POLL_MS = 60000;
let session, uploads, reader, currentId, screen = 0, libraryRequest = 0, libraryTag = null;
let collection = { papers: [], assignments: {}, folders: [] };
let limit = 50, versionPending = false, refreshing = false;
let pairing, pollTimer, waitingCode = false;
const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const pairToken = new URLSearchParams(location.hash.slice(1)).get('pair');
// The QR fragment is never needed in history, logs or the installed web app's start URL.
if (pairToken) history.replaceState(null, '', location.pathname);
const CONNECT_HINT = standalone
  ? '홈 화면 앱은 Safari와 따로 로그인합니다. PC의 Sunlight에서 ‘휴대폰 연결’을 열고 QR 아래의 연결 코드를 입력하세요.'
  : 'PC의 Sunlight에서 ‘휴대폰 연결’을 열고 QR 코드를 스캔하세요. 스캔할 수 없으면 QR 아래의 연결 코드를 입력하세요.';

function show(name) {
  for (const id of ['gate', 'library', 'reader']) $(id).hidden = name !== id;
}
function gate(title, message, retry, codeForm = false) {
  show('gate');
  $('gate-title').textContent = title;
  $('gate-message').textContent = message;
  $('retry-gate').hidden = !retry;
  $('retry-gate').onclick = retry || null;
  $('code-form').hidden = !codeForm;
  $('code-error').textContent = '';
  if (!waitingCode) { $('pair-code').textContent = ''; $('pair-code').hidden = true; }
}
function readPreference(key) { try { return localStorage.getItem(key); } catch { return null; } }
function summaryKey() { return 'sunlight.mobile.summary.' + session.id; }
function storePreference(key, value) { try { localStorage.setItem(key, value); } catch { /* Per-tab settings still work. */ } }
const connected = () => !!session?.id;

// One banner for problems that are not about the current screen: the PC went away or the team login expired.
function showBanner(error) {
  $('banner-text').textContent = error.message;
  const action = $('banner-action');
  if (error.reload) { action.textContent = '새로 고침'; action.onclick = () => location.reload(); }
  else { action.textContent = '다시 확인'; action.onclick = () => { void resume(); }; }
  $('connection-banner').hidden = false;
}
function hideBanner() { $('connection-banner').hidden = true; }

function clearPrivate() {
  ++screen; ++libraryRequest;
  const oldKey = connected() ? summaryKey() : null;
  const old = uploads; uploads = null;
  session = null; libraryTag = null;
  old?.close();
  reader?.close(false); reader = null; currentId = null;
  collection = { papers: [], folders: [], assignments: {} };
  for (const id of ['papers', 'count', 'library-message', 'summary', 'page-text', 'paper-title', 'position-note']) $(id).replaceChildren();
  $('folder').replaceChildren(new Option('모든 폴더', '')); $('search').value = '';
  if ($('settings').open) $('settings').close();
  hideBanner();
  try { if (oldKey) localStorage.removeItem(oldKey); sessionStorage.removeItem('sunlight.pair.code'); } catch {}
  history.replaceState(null, '', location.pathname);
  document.title = 'Sunlight';
}
function disconnected() {
  waitingCode = false;
  clearPrivate();
  void forgetTransfers();
  gate('PC에 연결', CONNECT_HINT, null, true);
}

async function api(path, { json, body, method = 'GET', signal, timeout = 18000, keepalive = false, auth = true, etag, onTag } = {}) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (signal?.aborted) abort();
  signal?.addEventListener('abort', abort, { once: true });
  const deadline = setTimeout(abort, timeout);
  const report = error => {
    if (connected() && ['auth_expired', 'pc_off', 'offline', 'timeout'].includes(error.code) && !signal?.aborted) showBanner(error);
    return error;
  };
  try {
    let response;
    try {
      const headers = json === undefined ? {} : { 'Content-Type': 'application/json' };
      if (etag) headers['If-None-Match'] = etag;
      // A login page in front of the tunnel answers with a redirect; never follow it from a script.
      response = await fetch(path, { method, headers, body: json === undefined ? body : JSON.stringify(json), credentials: 'same-origin', cache: 'no-store', redirect: 'manual', signal: controller.signal, keepalive });
    } catch {
      throw report(failure({ timedOut: controller.signal.aborted && !signal?.aborted }));
    }
    if (response.type === 'opaqueredirect') throw report(failure({ type: response.type }));
    if (response.status === 304) { hideBanner(); return NOT_MODIFIED; }
    if (response.status === 204) { hideBanner(); return null; }
    const isJson = (response.headers.get('Content-Type') || '').includes('application/json');
    const data = isJson ? await response.json().catch(() => ({})) : {};
    if (!response.ok) {
      if (auth && connected() && response.status === 401 && isJson) disconnected();
      throw report(failure({ status: response.status, data }));
    }
    // A 200 page that is not ours (a captive portal, a proxy notice) is not the PC.
    if (!isJson) throw report(failure({}));
    hideBanner();
    onTag?.(response.headers.get('ETag'));
    return data;
  } finally { clearTimeout(deadline); signal?.removeEventListener('abort', abort); }
}

function showPairCode(code) {
  waitingCode = true;
  gate('PC에서 이 번호를 고르세요', 'PC 화면에 번호가 세 개 보입니다. 아래 번호와 같은 번호를 누르면 연결됩니다.', null);
  $('pair-code').textContent = code;
  $('pair-code').hidden = false;
}
function pairFailed(title, message) {
  waitingCode = false;
  try { sessionStorage.removeItem('sunlight.pair.code'); } catch {}
  gate(title, message, null, true);
}
async function poll() {
  clearTimeout(pollTimer);
  if (!waitingCode) return;
  try {
    const result = await api('/m/pair/finish', { method: 'POST', json: {}, auth: false });
    if (result.state === 'connected') {
      waitingCode = false;
      try { sessionStorage.removeItem('sunlight.pair.code'); } catch {}
      await start();
      return;
    }
  } catch (error) {
    if (error.status === 403) return pairFailed('연결이 거절됐습니다', 'PC에서 요청을 거절했거나 다른 번호를 골랐습니다. PC에서 새 QR을 열어 다시 연결하세요.');
    if ([404, 410].includes(error.status)) return pairFailed('다시 연결해 주세요', 'PC에서 새 QR 코드를 열고 스캔하거나 연결 코드를 입력하세요.');
    $('gate-message').textContent = error.code === 'auth_expired' ? error.message : 'PC의 응답을 기다리는 중입니다. 연결되면 다시 확인합니다.';
  }
  pollTimer = setTimeout(poll, 2000);
}
async function beginPair(proof) {
  const agent = navigator.userAgent;
  const name = /iphone/i.test(agent) ? 'iPhone' : /ipad/i.test(agent) ? 'iPad' : /android/i.test(agent) ? 'Android' : '웹 브라우저';
  try {
    const data = await api('/m/pair/start', { method: 'POST', json: { ...proof, name }, auth: false });
    showPairCode(String(data.code));
    try { sessionStorage.setItem('sunlight.pair.code', String(data.code)); } catch {}
    void poll();
  } catch (error) {
    if (error.status === 409) gate('이미 사용된 QR입니다', '이 QR은 이미 다른 기기가 사용했습니다 — PC에서 거절하세요. 그다음 PC에서 새 QR을 열어 다시 연결하세요.', null, true);
    else if (error.status === 400 && proof.code) { gate('PC에 연결', CONNECT_HINT, null, true); $('code-error').textContent = error.message; $('pair-input').focus(); }
    else if (error.status === 410 || error.status === 400) gate('연결 요청이 만료됐습니다', 'PC에서 새 QR을 열고 다시 스캔하거나 새 연결 코드를 입력하세요.', null, true);
    else gate('연결을 시작하지 못했습니다', error.message, () => pair(proof), error.code !== 'auth_expired');
  }
}
function pair(proof) {
  if (pairing) return;
  pairing = beginPair(proof).finally(() => { pairing = null; });
}

const paperFor = id => collection.papers.find(paper => paper.id === id);
const latest = () => collection.papers.reduce((best, p) => p.position?.updated_at > (best?.position?.updated_at || 0) ? p : best, null);

function paperRow(id) {
  const row = document.createElement('li');
  const open = document.createElement('button');
  open.type = 'button'; open.dataset.paperId = id; open.onclick = () => navigate(id);
  const name = document.createElement('span'); name.className = 'paper-name';
  const meta = document.createElement('span'); meta.className = 'paper-meta';
  open.append(name, meta); row.append(open);
  return row;
}

function paperDetails(p) {
  const bits = [];
  if (p.source === 'drive') bits.push('Google Drive');
  if (p.original === false) bits.push('원본 없음');
  if (p.position?.revision && p.position.page) bits.push('읽던 곳 ' + p.position.page + '쪽');
  else if (p.pages) bits.push(p.pages + '쪽');
  if (p.translated) bits.push('번역본');
  if (p.summary_status === 'done') bits.push('요약');
  else if (['queued', 'running'].includes(p.summary_status)) bits.push('요약 중');
  if (!bits.length) bits.push(p.status === 'analyzing' ? 'PDF 확인 중' : 'PDF');
  return bits.join(' · ');
}

function renderPaperRows(papers) {
  const list = $('papers');
  const focus = list.contains(document.activeElement) ? document.activeElement : null;
  let cursor = list.firstElementChild, reordered, tail;
  const count = Math.min(limit, papers.length);
  for (let i = 0; i < count; i++) {
    const p = papers[i];
    let row = cursor;
    if (!cursor) {
      row = paperRow(p.id);
      (tail ??= document.createDocumentFragment()).append(row);
    } else if (cursor.firstElementChild.dataset.paperId !== p.id) {
      // Only index the existing rows when order actually changes.
      reordered ??= new Map(Array.from(list.children, li => [li.firstElementChild.dataset.paperId, li]));
      row = reordered.get(p.id) || paperRow(p.id);
      list.insertBefore(row, cursor);
    }
    const name = row.firstElementChild.firstElementChild, meta = name.nextElementSibling;
    if (name.textContent !== p.title) name.textContent = p.title;
    const details = paperDetails(p);
    if (meta.textContent !== details) meta.textContent = details;
    if (cursor) cursor = row.nextElementSibling;
  }
  while (cursor) {
    const next = cursor.nextElementSibling;
    cursor.remove();
    cursor = next;
  }
  if (tail) list.append(tail);
  if (focus?.isConnected && focus !== document.activeElement) focus.focus({ preventScroll:true });
}

function renderLibrary() {
  if (!connected() || $('library').hidden) return;
  const folder = $('folder');
  const folders = collection.folders || [];
  const options = folder.options;
  if (options.length !== folders.length + 1 || folders.some((f, i) => options[i+1].value !== f.id || options[i+1].text !== f.name)) {
    const selected = folder.value;
    folder.replaceChildren(new Option('모든 폴더', ''), ...folders.map(f => new Option(f.name, f.id)));
    folder.value = folders.some(f => f.id === selected) ? selected : '';
  }
  folder.hidden = !folders.length;
  const selected = folder.value;
  const query = $('search').value.trim().toLocaleLowerCase();
  const filtered = !selected && !query ? collection.papers : collection.papers.filter(p =>
    (!selected || collection.assignments?.[p.id] === selected) && (!query || p.title.toLocaleLowerCase().includes(query)));
  const count = filtered.length + '편';
  if ($('count').textContent !== count) $('count').textContent = count;
  renderPaperRows(filtered);
  $('show-more').hidden = limit >= filtered.length;
  const message = filtered.length ? '' : (collection.papers.length ? '조건에 맞는 논문이 없습니다.' : '라이브러리가 비어 있습니다. PDF를 추가해 주세요.');
  if ($('library-message').textContent !== message) $('library-message').textContent = message;
}
function libraryError(error) {
  const retry = document.createElement('button');
  retry.type = 'button'; retry.className = 'action-link';
  retry.textContent = error.reload ? '새로 고침' : '다시 불러오기';
  retry.onclick = () => error.reload ? location.reload() : refreshLibrary();
  $('library-message').replaceChildren(error.message, retry);
}
async function refreshLibrary() {
  if (!connected()) return false;
  const which = ++libraryRequest;
  try {
    let tag = null;
    const data = await api('/m/api/library', { etag: libraryTag, onTag: value => { tag = value; } });
    if (which !== libraryRequest || !connected()) return false;
    if (data === NOT_MODIFIED) { if ($('library-message').querySelector('button')) renderLibrary(); return true; }
    if (!Array.isArray(data.papers)) throw new Error('라이브러리 목록을 읽을 수 없습니다.');
    collection = data;
    libraryTag = tag;
    if (currentId && paperFor(currentId)) reader?.update(paperFor(currentId));
    if (currentId && !paperFor(currentId)) navigate(null, true);
    renderLibrary(); return true;
  } catch (error) { if (connected() && which === libraryRequest) libraryError(error); return false; }
}
function saveLocal(id, position) {
  const paper = paperFor(id);
  if (paper && position?.revision >= (paper.position?.revision || 0)) { paper.position = position; if (!$('library').hidden) renderLibrary(); }
}
function hashPaper() {
  const fragment = location.hash.slice(1);
  if (!fragment.startsWith('read/')) return null;
  try { return decodeURIComponent(fragment.slice(5)); } catch { return null; }
}
function navigate(id, replace = false) {
  const url = location.pathname + (id ? '#read/' + encodeURIComponent(id) : '');
  if (replace) history.replaceState(null, '', url);
  else history.pushState({ fromShelf: Boolean(id) }, '', url);
  void route();
}
async function route() {
  if (!connected()) return;
  const id = hashPaper();
  if (id === currentId && reader) return;
  const which = ++screen;
  reader?.close(); reader = null; currentId = null;
  const paper = id && paperFor(id);
  if (!paper) {
    show('library'); document.title = '내 라이브러리 · Sunlight';
    renderLibrary();
    $('library-title').focus({ preventScroll: true });
    if (id) { history.replaceState(null, '', location.pathname); $('library-message').textContent = '라이브러리에서 이 논문을 찾을 수 없습니다.'; }
    return;
  }
  currentId = id;
  show('reader');
  $('source-note').hidden = paper.original !== false;
  $('restore-source').onclick = () => { navigate(null, true); $('file-input').click(); };
  $('paper-title').textContent = paper.title;
  $('read-notice').textContent = 'PDF 여는 중'; $('read-notice').hidden = false;
  $('paper-title').focus({ preventScroll: true });
  try {
    const { openReader } = await import('./reader.js');
    if (which !== screen || !connected()) return;
    reader = openReader({
      paper: { ...paper }, api, saveLocal,
      onBack: () => history.state?.fromShelf ? history.back() : navigate(null, true)
    });
  } catch {
    if (which !== screen) return;
    const retry = document.createElement('button'); retry.className = 'action-link'; retry.textContent = '다시 열기'; retry.onclick = route;
    $('read-notice').replaceChildren('읽기 화면을 불러오지 못했습니다.', retry);
    const kind = paper.original !== false ? 'original' : paper.translated ? 'translated' : paper.bilingual ? 'bilingual' : null;
    if (kind) $('read-notice').append(pdfLink('/m/api/papers/' + encodeURIComponent(id) + '/file/' + kind, 'PDF 직접 열기'));
    $('back').onclick = () => { $('back').onclick = null; navigate(null); };
  }
}

function maybeUpdate() {
  if (!versionPending || reader?.changed() || uploads?.unfinished() || document.visibilityState !== 'visible') return;
  versionPending = false;
  location.reload();
}
async function resume(polling = false) {
  if (document.hidden || refreshing || !connected()) return;
  refreshing = true;
  try {
    const next = await api('/m/session');
    if (!connected()) return;
    if (next.id !== session.id) { clearPrivate(); await start(); return; }
    if (next.version !== session.version) { versionPending = true; maybeUpdate(); }
    const id = currentId;
    if (polling && id && reader) {
      // While reading, only the open paper can change the visible controls.
      try {
        const latest = await api('/m/api/papers/' + encodeURIComponent(id));
        if (id === currentId && latest?.id === id && paperFor(id)) {
          Object.assign(paperFor(id), latest);
          reader?.update(latest);
        }
      } catch (error) {
        if (error.status === 404 && id === currentId) await refreshLibrary();
      }
    } else await refreshLibrary();
    if (!polling) uploads?.reconnect();
  } catch (error) {
    if (connected() && !$('library').hidden) libraryError(error);
  } finally { refreshing = false; }
}
async function start() {
  if (pairing) return;
  let restoredCode;
  try { restoredCode = sessionStorage.getItem('sunlight.pair.code'); } catch {}
  try { session = await api('/m/session', { auth: false }); }
  catch (error) {
    if (error.status === 401 && restoredCode) { showPairCode(restoredCode); void poll(); }
    else if (error.status === 401) disconnected();
    else if (error.reload) gate('다시 로그인해 주세요', error.message, () => location.reload());
    else gate(error.code === 'pc_off' ? 'PC가 응답하지 않습니다' : 'PC 연결을 확인해 주세요',
      error.code === 'pc_off' ? error.message : 'PC에서 Sunlight가 실행 중인지 확인한 뒤 다시 시도하세요.', start);
    return;
  }
  if (!connected()) { disconnected(); return; }
  waitingCode = false;
  $('auto-summary').checked = readPreference(summaryKey()) === '1';
  uploads = createUploads({ device: session.id, api, onActivity: () => queueMicrotask(maybeUpdate), onSaved: refreshLibrary, onOpen: async id => { if (!paperFor(id)) await refreshLibrary(); navigate(id); } });
  show('library');
  $('library-message').textContent = '라이브러리 불러오는 중';
  const [loaded] = await Promise.all([refreshLibrary(), uploads.restore()]);
  if (!connected() || !loaded) return;
  if (!hashPaper() && !uploads?.unfinished() && latest()) navigate(latest().id, true);
  else void route();
}

$('add-files').onclick = () => $('file-input').click();
$('file-input').onchange = event => {
  const files = Array.from(event.target.files || []);
  event.target.value = '';
  if (files.length) void uploads?.add(files, $('auto-summary').checked);
};
$('code-form').onsubmit = event => {
  event.preventDefault();
  const raw = $('pair-input').value.trim();
  // A pasted connection link works too; the typed code is the usual path in a Home Screen app.
  const token = raw.match(/#pair=([0-9a-fA-F]{64})(?:$|&)/)?.[1];
  const code = raw.replace(/[\s-]/g, '').toUpperCase();
  if (token) pair({ token });
  else if (/^[2-9A-HJ-NP-Z]{8}$/.test(code)) pair({ code });
  else { $('code-error').textContent = 'PC에 표시된 8자리 연결 코드를 입력해 주세요.'; $('pair-input').focus(); }
};
$('open-settings').onclick = () => $('settings').showModal();
$('close-settings').onclick = () => $('settings').close();
$('auto-summary').onchange = () => { if (connected()) storePreference(summaryKey(), $('auto-summary').checked ? '1' : '0'); };
if (standalone) document.querySelector('.install-note').hidden = true;
$('search').oninput = $('folder').onchange = () => { limit = 50; renderLibrary(); };
$('show-more').onclick = () => { limit += 50; renderLibrary(); };
window.addEventListener('popstate', route);
window.addEventListener('online', () => { void resume(); });
window.addEventListener('pageshow', event => { if (event.persisted) void resume(); });
window.addEventListener('pagehide', () => { void reader?.flush(); });
document.addEventListener('visibilitychange', () => { if (document.hidden) void reader?.flush(); else void resume(); });
// Respect a revoked device even if its foreground tab stays on the same page. Hidden tabs do not poll.
setInterval(() => { if (connected() && !document.hidden) void resume(true); }, POLL_MS);
// Only an offline page is kept by the worker; failure to register changes nothing else.
if ('serviceWorker' in navigator && isSecureContext) navigator.serviceWorker.register('/sw.js').catch(() => {});
if (pairToken) pair({ token: pairToken });
else void start();
