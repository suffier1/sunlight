// Opening and closing a paper, its documents and data, job progress (stop / resume), paper actions.
// Owns S.sess, S.paper, S.docs, S.trVersion, S.mode, S.pendingMode, S.summaryState and the block data.
import * as pdfjsLib from '../vendor/pdfjs/pdf.min.mjs?v=2';
import { api, toast, errorText, confirmDialog, onServerEvent, serverEventsLive, onServerEventsState } from '../ui-kit.js';
import { S, $, $$, live, isAbort, openSession, closeSession, readerShown } from './state.js';
import { buildPages, refreshTranslatedSlots, readPageSizes, renderZoomState } from './layout.js';
import { savePos, stopPositionTimer, currentPos, scrollToPos, updatePageIndicator, promptRemotePosition, hideRemotePrompt } from './navigation.js';
import { hidePops, hideChip, toggleRegion, forgetHoverBlock } from './selection.js';
import { closeExplanation, closeQuick, explanationOpen } from './explain.js';
import { loadHighlights, resetNotes, flushNoteDrafts } from './notes.js';
import { loadChat, syncSendBtn, stashChatDraft, resetChat, restoreChatDraft } from './chat.js';
import { renderSummary, summaryProgress } from './summary.js';
import { restorePanelPreference, showPanelRetry } from './panel.js';
import { resetSearch, loadOutline } from './search.js';
import { resetLinks } from './links.js';
import { gotoPage } from './navigation.js';
import { focusNote } from './notes.js';
import { requireEngine, engineName, renderEngineBadge, openSettings } from '../settings.js';
import { readingPosition } from '../reading-position.js';
import { driveLink } from '../drive-ui.js';

const ACTIVE = ['analyzing', 'queued', 'translating'];
const RESUMABLE = ['stopped', 'interrupted'];
const pagesBox = $('#pages');

/* ---------------------------------------------------------------- open / close */
export function closeReader() {
  setReaderMenuOpen(false);
  savePos();
  stopPositionTimer();
  stashChatDraft();
  closeExplanation(false);
  closeQuick(false);
  hideRemotePrompt();
  closeSession();
  clearTimeout(pollTimer); clearTimeout(trTimer);
  hideChip();
  S.observer?.disconnect(); S.evictor?.disconnect();
  for (const slot of S.slots) { slot.run++; slot.task?.cancel?.(); }
  for (const doc of Object.values(S.docs)) doc.destroy().catch(() => {});
  S.docs = {}; S.paper = null; S.slots = []; S.trVersion = -1; S.trLoadedAt = 0; S.summaryState = null; S.sel = null; S.restorePos = null;
  S.position?.close?.(); S.position = null; S.positionGesture = 0;
  S.pendingMode = null; S.pageSizes = []; S.pageDataReady = false; S.blockFailures = 0;
  S.chatLoading = false;
  S.textLayers.clear();
  setReaderData([], []);
  resetNotes();
  resetSearch();
  resetLinks();
  pagesBox.replaceChildren();
  $('#tab-summary').textContent = '';
  resetChat();
  readerProgress('');
  hidePops();
  S.regionSel = null;
  if (S.region) toggleRegion();
  updatePageIndicator();
}
export async function openPaper(id) {
  closeReader();
  const sess = openSession(id);
  $('#library').classList.add('hidden');
  $('#reader').classList.remove('hidden');
  $('#docTitle').textContent = '논문을 여는 중';
  $('#docTitle').title = '';
  $('#docTitle').focus({ preventScroll: true });
  restorePanelPreference();
  document.title = 'Sunlight';
  pagesBox.innerHTML = '<div class="empty" role="status"><span class="spinner" aria-hidden="true"></span> PDF를 여는 중입니다.</div>';
  $('#dlBtn').disabled = true;
  $('#regionBtn').disabled = true;
  $('#chatText').disabled = true;
  S.mode = 'original';
  setModeButtons();
  syncSendBtn();
  let p;
  try { p = await api(`/api/papers/${encodeURIComponent(id)}`, { signal: sess.signal, timeout: 12000 }); } catch (e) {
    if (live(sess)) { toast(`논문을 열지 못했습니다. ${errorText(e)}`, { kind: 'error' }); location.hash = '#/'; }
    return;
  }
  if (!live(sess)) return;
  S.paper = p;
  $('#chatText').disabled = false;
  const savedMode = localStorage.getItem('sl.mode') || 'side';
  S.pendingMode = p.translated_version > 0 && ['side', 'translated'].includes(savedMode) ? savedMode : null;
  showTitle(p);
  setModeButtons();
  renderZoomState();
  renderEngineBadge();
  updateMenus();
  $('#dlBtn').disabled = false;
  restoreChatDraft(id);
  loadHighlights(sess).catch(err => {
    if (live(sess)) showPanelRetry($('#tab-notes'), err, () => loadHighlights(sess).catch(e => toast(e, { kind: 'error' })));
  });
  loadChat(sess);
  if (p.storage_issue === 'original') { pdfError(null); renderSummary(); return; }
  const position = readingPosition(id, { onNewer: info => promptRemotePosition(info, sess) });
  let doc, savedPosition, sizes;
  try {
    [doc, savedPosition] = await Promise.all([loadDoc(`/api/papers/${encodeURIComponent(id)}/file/original`, sess), position.load()]);
    if (!live(sess)) return;
    sizes = await readPageSizes(doc, sess.signal);
  } catch (e) {
    if (live(sess)) pdfError(e);
    return;
  }
  if (!live(sess)) return;
  S.docs.original = doc;
  if (!S.pageDataReady && sizes) S.pageSizes = sizes;
  $('#regionBtn').disabled = false;
  syncSendBtn();
  S.position = position;
  S.restorePos = savedPosition;
  position.move(savedPosition || { p: 0, f: 0 }, true);
  if (!S.pendingMode) buildPages();
  await syncPaper(sess, true);
  if (!live(sess)) return;
  if (!S.slots.length) buildPages();
  loadOutline(sess);
  requestAnimationFrame(() => applyOpenTarget(sess));
}
// Open a paper at a page (1-based) or at a highlight's note (e.g. a library search hit on a memo).
export function openPaperAt(pid, { page, hid } = {}) {
  S.openTarget = { pid, page, hid };
  if (S.paper?.id === pid && S.slots.length) { applyOpenTarget(S.sess); return; }
  location.hash = `#/paper/${encodeURIComponent(pid)}`;
}
async function applyOpenTarget(sess) {
  const t = S.openTarget;
  if (!t || !live(sess) || t.pid !== S.paper?.id) return;
  S.openTarget = null;
  if (t.hid) {
    for (let i = 0; i < 50 && !S.highlightsReady && live(sess); i++) await new Promise(r => setTimeout(r, 100));
    const h = live(sess) && S.highlights.find(x => x.id === t.hid);
    if (h) { gotoPage(h.page, h.rects[0]?.[1]); focusNote(h.id); return; }
  }
  const n = S.docs.original?.numPages || 0, page = Math.round(Number(t.page));
  if (page >= 1 && page <= n) gotoPage(page - 1);
}
function showTitle(p) {
  document.title = p.title;
  $('#docTitle').textContent = p.title;
  $('#docTitle').title = p.title;
}
function pdfError(e) {
  const missing = S.paper?.storage_issue === 'original';
  const message = missing ? errorText(S.paper.storage_error || '원본 PDF를 다시 추가해 주세요.')
    : e?.name === 'PasswordException' ? '암호가 걸린 PDF입니다. 보호를 해제한 사본을 열어 주세요.'
      : `PDF를 열지 못했습니다. ${errorText(e)}`;
  const box = document.createElement('div');
  box.className = 'empty'; box.setAttribute('role', 'alert');
  box.textContent = message;
  const acts = document.createElement('div'); acts.className = 'err-acts';
  acts.innerHTML = `<button type="button" class="btn sm" data-reopen>다시 시도</button>${missing
    ? '<a class="btn sm" href="#/">라이브러리로 돌아가기</a>'
    : `<a class="btn sm" href="/api/papers/${encodeURIComponent(S.paper?.id || '')}/file/original" target="_blank" rel="noopener">원문 PDF 열기</a>`}`;
  box.append(acts);
  pagesBox.replaceChildren(box);
}
pagesBox.addEventListener('click', e => {
  if (e.target.closest('[data-reopen]')) { if (S.paper) openPaper(S.paper.id); return; }
  const b = e.target.closest('[data-retr]');
  if (b) retranslatePages([+b.dataset.retr], true);
});
async function loadDoc(url, sess) {
  const task = pdfjsLib.getDocument({
    url: url + '?v=' + Date.now(), cMapUrl: 'vendor/pdfjs/cmaps/', cMapPacked: true, isEvalSupported: false,
    standardFontDataUrl: 'vendor/pdfjs/standard_fonts/',
  });
  // PDF.js can leave task.promise pending when destroy() interrupts a document request.
  const stopped = Promise.withResolvers();
  const onAbort = () => stopped.reject(new DOMException('PDF 닫기', 'AbortError'));
  sess.signal.addEventListener('abort', onAbort, { once: true });
  const deadline = setTimeout(() => stopped.reject(Object.assign(new Error('PDF 응답 시간이 초과되었습니다. 다시 시도하세요.'), { code: 'timeout' })), 45000);
  try { return await Promise.race([task.promise, stopped.promise]); }
  catch (error) { task.destroy().catch(() => {}); throw error; }
  finally { clearTimeout(deadline); sess.signal.removeEventListener('abort', onAbort); }
}

/* ---------------------------------------------------------------- block data */
// Page-local lookup lists, built once per data revision, keeping the server's paragraph order.
function setReaderData(blocks, objects) {
  const blocksByPage = new Map(), objectsByPage = new Map(), blockOrder = new Map();
  blocks.forEach((b, i) => {
    if (!blocksByPage.has(b.page)) blocksByPage.set(b.page, []);
    blocksByPage.get(b.page).push(b);
    blockOrder.set(b, i);
  });
  for (const o of objects) {
    if (!objectsByPage.has(o.page)) objectsByPage.set(o.page, []);
    objectsByPage.get(o.page).push(o);
  }
  S.blocks = blocks;
  S.blocksByPage = blocksByPage; S.objectsByPage = objectsByPage; S.blockOrder = blockOrder;
}
async function loadBlocks(sess) {
  const r = await api(`/api/papers/${S.paper.id}/blocks`, { signal: sess.signal, timeout: 12000 }).catch(() => null);
  if (!live(sess)) return;
  if (!Array.isArray(r?.blocks) || !Array.isArray(r.pages)) { S.blockFailures++; return; }
  const moved = !S.pageDataReady && (S.pageSizes.length !== r.pages.length || S.pageSizes.some((p, i) => Math.abs((p?.w || 0) - r.pages[i]?.w) > 0.5 || Math.abs((p?.h || 0) - r.pages[i]?.h) > 0.5));
  setReaderData(r.blocks, Array.isArray(r.objects) ? r.objects : []);
  S.pageSizes = r.pages;
  S.pageDataReady = true;
  S.blockFailures = 0;
  setModeButtons();
  if (moved && S.slots.length) {
    const pos = currentPos();
    buildPages();
    if (pos) requestAnimationFrame(() => scrollToPos(pos));
  }
}

/* ---------------------------------------------------------------- status and progress */
// opt: {tone: 'error', detail: raw text shown behind "자세히"}
export function readerProgress(message, percent = null, actions = [], opt = {}) {
  const panel = $('#progress'), bar = $('#progressBar'), text = $('#progressText'), box = $('#progressAction');
  if (text.textContent !== message) text.textContent = message;
  panel.classList.toggle('error', opt.tone === 'error');
  const key = JSON.stringify([actions.map(a => a.label), opt.detail || '']);
  if (box.dataset.key !== key) {
    box.dataset.key = key;
    box.replaceChildren(...actions.map(a => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = `link-btn${a.primary ? ' primary' : ''}`; b.textContent = a.label;
      b.onclick = async () => { b.disabled = true; try { await a.run(); } finally { b.disabled = false; } };
      return b;
    }));
    if (opt.detail) {
      const more = document.createElement('details');
      more.className = 'progress-detail';
      more.innerHTML = '<summary>자세히</summary><code></code>';
      more.querySelector('code').textContent = opt.detail;
      box.append(more);
    }
  }
  bar.classList.toggle('hidden', percent === null);
  if (percent !== null) { bar.style.width = `${percent}%`; bar.setAttribute('aria-valuenow', String(percent)); }
  else bar.removeAttribute('aria-valuenow');
  panel.classList.toggle('hidden', !message);
}
function pagesDone(p) {
  const total = Number(p.progress?.total) || 0;
  return { total, done: Math.min(total, Math.max(0, Number(p.progress?.done) || 0)) };
}
function renderProgress(p) {
  const { total, done } = pagesDone(p);
  if (p.storage_issue) return readerProgress(errorText(p.storage_error || '논문 파일을 확인해 주세요.'));
  if (p.status === 'analyzing') return readerProgress('분석 중');
  if (p.status === 'queued') return readerProgress('번역 대기', null, stopAction('translation'));
  if (p.status === 'translating') return readerProgress(total ? `번역 중 · 번역할 ${total}쪽 중 ${done}쪽` : '번역 중', total ? Math.round(done * 100 / total) : null, stopAction('translation'));
  if (RESUMABLE.includes(p.status)) {
    const left = total ? ` · ${done}/${total}쪽 완료` : '';
    return readerProgress(p.status === 'stopped' ? `번역을 중지했습니다${left}` : `번역이 중단되었습니다${left}. 이어서 할 수 있습니다.`, null,
      [{ label: '이어서 하기', primary: true, run: () => resumePaper() }]);
  }
  if (p.status === 'error' || p.status === 'partial') {
    const failed = (p.failed_pages || []).filter(n => n > 0);
    const stage = p.pages ? '번역' : 'PDF 분석';
    const cause = { detail: p.error || '', code: p.error_code || '' };
    // the server's message usually says it already ("10쪽 모두 번역하지 못했습니다 …"): don't repeat it
    const said = errorText(cause), lead = `${stage}하지 못했습니다`;
    const message = p.status === 'error' ? (said.includes('하지 못했습니다') ? said : `${lead}. ${said}`)
      : `일부 쪽을 번역하지 못했습니다${failed.length ? ` (${failed.join(', ')}쪽)` : ''}.`;
    const actions = [];
    if (p.status === 'partial' && failed.length && !p.running) actions.push({ label: '실패한 쪽 다시 번역', run: () => retranslatePages(failed.map(n => n - 1)) });
    if (p.status === 'error' && p.pages && !p.running) actions.push({ label: '다시 시도', primary: true, run: retryTranslation });
    const raw = typeof p.error === 'string' && p.error.trim() && p.error.trim() !== errorText(cause) ? p.error.trim() : '';
    return readerProgress(message, null, actions, { tone: 'error', detail: [raw, p.error_code ? `code: ${p.error_code}` : ''].filter(Boolean).join(' · ') });
  }
  if (p.notice) return readerProgress(p.notice);
  if (p.scanned && !p.translated_version) return readerProgress('텍스트를 인식할 수 없는 PDF입니다. 번역하려면 OCR을 적용한 사본을 열어 주세요.');
  if (p.summary_status === 'queued' || p.summary_status === 'running') return readerProgress(summaryProgress(p), null, stopAction('summary'));
  if (p.summary_status === 'interrupted') return readerProgress('요약이 중단되었습니다. 이어서 할 수 있습니다.', null, [{ label: '이어서 하기', primary: true, run: () => resumePaper() }]);
  if (!S.pageDataReady && S.blockFailures >= 3) return readerProgress('문단·표·그림 정보를 불러오지 못했습니다.', null, [{ label: '다시 시도', run: () => { S.blockFailures = 0; return syncPaper(S.sess, true); } }]);
  readerProgress('');
}
const stopAction = what => (S.noCancel ? [] : [{ label: '중지', run: () => cancelJob(what) }]);
const isActive = p => ACTIVE.includes(p.status) || ['queued', 'running'].includes(p.summary_status) || p.running;

// One refresh: GET the paper, apply it, load what changed. Push events and actions trigger it;
// polling is only the fallback when the event stream is down (contract §9).
let syncing = null, syncAgain = false, pollTimer = 0, trTimer = 0;
export function syncPaper(sess = S.sess, first = false) {
  if (!live(sess) || !S.paper) return Promise.resolve();
  if (syncing) { syncAgain = true; return syncing; }
  syncing = (async () => {
    try { await refresh(sess, first); }
    catch (e) {
      if (!live(sess)) return;
      if (e.code === 'not_found') { toast('논문을 찾을 수 없습니다. 라이브러리에서 다시 여세요.', { kind: 'error' }); location.hash = '#/'; return; }
      readerProgress(`논문 상태를 확인하지 못했습니다. ${errorText(e)}`);
    } finally {
      syncing = null;
      if (live(sess)) {
        if (syncAgain) { syncAgain = false; syncPaper(sess); } else schedulePoll(sess);
      }
    }
  })();
  return syncing;
}
function schedulePoll(sess) {
  clearTimeout(pollTimer);
  if (!live(sess) || !S.paper) return;
  let delay = 0;
  if (!S.pageDataReady && S.blockFailures > 0 && S.blockFailures < 3) delay = 5000;
  if (!serverEventsLive()) delay = Math.min(delay || Infinity, isActive(S.paper) ? 15000 : 60000);
  if (delay && Number.isFinite(delay)) pollTimer = setTimeout(() => syncPaper(sess), delay);
}
let eventT = 0;
onServerEvent('paper', data => {
  if (!S.paper || data?.id !== S.paper.id) return;
  clearTimeout(eventT);
  eventT = setTimeout(() => syncPaper(S.sess), 150);
});
onServerEvent('resync', () => { if (S.paper) syncPaper(S.sess); });
onServerEventsState(liveNow => { if (S.paper) (liveNow ? syncPaper(S.sess) : schedulePoll(S.sess)); });

async function refresh(sess, first) {
  const p = await api(`/api/papers/${S.paper.id}`, { signal: sess.signal, timeout: 12000 });
  if (!live(sess)) return;
  const statusChanged = p.status !== S.paper.status;
  S.paper = p;
  showTitle(p);
  if (first || p.status !== 'analyzing' && (!S.pageDataReady || statusChanged)) {
    await loadBlocks(sess);
    if (!live(sess)) return;
  }
  renderProgress(p);
  const summaryState = JSON.stringify([p.summary_status, p.summary_stage, p.summary_error, p.summary_previous_available, p.scanned, p.storage_issue, p.status === 'analyzing']);
  if (summaryState !== S.summaryState) { S.summaryState = summaryState; renderSummary(); }
  updateMenus();
  await syncTranslated(sess);
}

/* ---------------------------------------------------------------- translated document */
// The translated PDF is (re)loaded only when it is on screen; while a translation runs, reloads are
// spaced at least 8 s apart; a translated selection or explanation defers the swap.
const wantsTranslated = () => S.mode !== 'original' || !!S.pendingMode;
async function syncTranslated(sess) {
  clearTimeout(trTimer);
  const p = S.paper;
  if (p.translated_version === S.trVersion) return;
  if (!(p.translated_version > 0)) {
    if (S.trVersion === -1 && !S.docs.translated) { S.trVersion = p.translated_version; return; }
    const old = S.docs.translated;
    delete S.docs.translated;
    S.pendingMode = null; S.mode = 'original'; S.trVersion = p.translated_version;
    setModeButtons();
    buildPages();
    old?.destroy().catch(() => {});
    return;
  }
  setModeButtons();
  if (!wantsTranslated()) return;
  const busy = S.docs.translated && ((S.sel?.kind === 'translated' && !$('#selPop').classList.contains('hidden')) || (explanationOpen() && S.sel?.kind === 'translated'));
  const wait = p.status === 'translating' && S.docs.translated ? 8000 - (performance.now() - (S.trLoadedAt || 0)) : 0;
  if (busy || wait > 0) { trTimer = setTimeout(() => { if (live(sess)) syncTranslated(sess); }, Math.max(wait, 2500)); return; }
  await loadTranslated(sess);
}
async function loadTranslated(sess) {
  const version = S.paper.translated_version;
  let doc;
  try { doc = await loadDoc(`/api/papers/${S.paper.id}/file/translated`, sess); } catch (e) {
    if (!live(sess) || isAbort(e)) return false;
    trTimer = setTimeout(() => { if (live(sess)) syncTranslated(sess); }, 3000);  // the file may be mid-rewrite
    return false;
  }
  if (!live(sess)) { doc.destroy().catch(() => {}); return false; }
  const old = S.docs.translated;
  S.docs.translated = doc;
  S.trLoadedAt = performance.now();
  const fresh = !old || !S.slots.some(s => s.kind === 'translated');
  const restoreMode = S.pendingMode;
  S.pendingMode = null;
  if (restoreMode) S.mode = restoreMode;
  S.trVersion = version;
  setModeButtons();
  if (S.sel?.kind === 'translated') { S.sel = null; hidePops(); }
  forgetHoverBlock();
  const rebuilt = fresh || restoreMode || !S.slots.length;
  if (rebuilt) buildPages(); else refreshTranslatedSlots();
  old?.destroy().catch(() => {});
  if (S.search) S.search.index = null;
  await loadBlocks(sess);
  return rebuilt;
}
export async function setMode(mode) {
  if (mode === S.mode && !S.pendingMode) return;
  S.mode = mode;
  S.pendingMode = null;
  try { localStorage.setItem('sl.mode', mode); } catch { /* session only */ }
  setModeButtons();
  const sess = S.sess;
  if (mode !== 'original' && S.paper?.translated_version > 0 && S.trVersion !== S.paper.translated_version) {
    readerProgress('번역 PDF를 여는 중');
    const rebuilt = await loadTranslated(sess);
    if (!live(sess)) return;
    renderProgress(S.paper);
    if (rebuilt) return;
  }
  buildPages();
}
export function setModeButtons() {
  const p = S.paper;
  const ready = p?.translated_version > 0;
  const translating = ACTIVE.includes(p?.status);
  const canStart = p && S.docs.original && S.pageDataReady && S.blocks.length && !ready && !RESUMABLE.includes(p.status) &&
    !p.scanned && !p.storage_issue && !p.running && !translating && !['queued', 'running'].includes(p.summary_status);
  $('#modeSeg').classList.toggle('hidden', !ready);
  $('#translateStart').classList.toggle('hidden', !canStart);
  for (const button of $$('#modeSeg button')) {
    const on = button.dataset.mode === (S.pendingMode || S.mode);
    button.classList.toggle('on', on);
    button.setAttribute('aria-pressed', String(on));
  }
}
$$('#modeSeg button').forEach(b => b.onclick = () => setMode(b.dataset.mode));

/* ---------------------------------------------------------------- jobs: start, stop, resume */
const pendingAiRequests = new Map();
async function requestRetranslation(pid, action, confirmNew) {
  const pages = action.pages ? [...new Set(action.pages)].sort((a, b) => a - b) : null;
  const key = `sunlight.retranslate.pending.${JSON.stringify([pid, action.translate !== false, !!action.summary, pages])}`;
  const pending = () => {
    try { return localStorage.getItem(key) || pendingAiRequests.get(key); }
    catch { return pendingAiRequests.get(key); }
  };
  let id = pending();
  if (!id && !await confirmNew()) return null;
  id = id || pending() || crypto.randomUUID();
  pendingAiRequests.set(key, id);
  try { localStorage.setItem(key, id); } catch { /* the current tab retains the request */ }
  const forget = () => {
    if (pendingAiRequests.get(key) === id) pendingAiRequests.delete(key);
    try { if (localStorage.getItem(key) === id) localStorage.removeItem(key); } catch { /* storage unavailable */ }
  };
  try {
    const result = await api(`/api/papers/${pid}/retranslate`, { method: 'POST', body: { ...action, request_id: id }, timeout: 12000 });
    forget();
    return result;
  } catch (e) {
    if (e.status >= 400 && e.status < 500 && e.status !== 408) { forget(); throw e; }
    throw Object.assign(new Error('요청 접수 여부를 확인하지 못했습니다. 같은 작업을 다시 누르면 기존 요청을 확인합니다.'), { cause: e });
  }
}
export async function retranslatePages(pages, ask = false) {
  if (!S.docs.original || !pages.length) return;
  const sess = S.sess;
  try {
    const result = await requestRetranslation(S.paper.id, { pages }, async () => {
      if (!await requireEngine(() => live(sess))) return false;
      return !ask || confirmDialog({
        title: `${pages.map(i => i + 1).join(', ')}쪽을 다시 번역할까요?`,
        body: `이 쪽의 본문을 ${engineName()}에 보내 새로 번역합니다. AI 사용량이 듭니다.`, confirm: '다시 번역',
      });
    });
    if (!result || !live(sess)) return;
    toast(result.replayed ? '이미 접수된 번역 요청입니다.' : `${pages.map(i => i + 1).join(', ')}쪽 다시 번역 중`);
    syncPaper(sess);
  } catch (err) { if (live(sess)) { toast(err, { kind: 'error' }); syncPaper(sess); } }
}
export async function cancelJob(what) {
  const sess = S.sess;
  if (!S.paper) return;
  try {
    await api(`/api/papers/${S.paper.id}/cancel`, { method: 'POST', body: { what }, signal: sess.signal, timeout: 15000 });
    if (live(sess)) toast(what === 'summary' ? '요약을 중지했습니다.' : '번역을 중지했습니다. 끝난 쪽은 남아 있습니다.');
  } catch (e) {
    if (!live(sess)) return;
    if (e.status === 404 || e.status === 405) { S.noCancel = true; toast('이 버전의 서버에서는 작업을 중지할 수 없습니다.', { kind: 'error' }); }
    else toast(`중지하지 못했습니다. ${errorText(e)}`, { kind: 'error' });
  }
  syncPaper(sess);
}
// A reader who never chose a view gets the side-by-side view as soon as translated pages exist;
// one who did gets a "번역 보기" button instead of a forced switch.
function afterResume(message) {
  let picked = null;
  try { picked = localStorage.getItem('sl.mode'); } catch { /* treat as not picked */ }
  if (S.mode !== 'original') { toast(message); return; }  // already reading the translation
  if (!picked) { S.pendingMode = 'side'; toast(message); syncPaper(S.sess); return; }
  if (S.paper?.translated_version > 0) toast(message, { action: { label: '번역 보기', run: () => setMode(picked === 'original' ? 'side' : picked) } });
  else toast(`${message} 번역된 쪽이 생기면 상단의 번역·병렬로 볼 수 있습니다.`);
}
export async function resumePaper() {
  const sess = S.sess;
  if (!S.paper || !await requireEngine(() => live(sess))) return;
  const translation = RESUMABLE.includes(S.paper.status);  // else only the summary continues
  try {
    await api(`/api/papers/${S.paper.id}/resume`, { method: 'POST', body: {}, signal: sess.signal, timeout: 15000 });
    if (live(sess)) (translation ? afterResume : toast)('이어서 진행합니다.');
  } catch (e) {
    if (live(sess)) toast(`이어서 하지 못했습니다. ${errorText(e)}`, { kind: 'error' });
  }
  syncPaper(sess);
}
// A failed translation continues its saved plan; without one (older papers) it starts over.
async function retryTranslation() {
  const sess = S.sess;
  if (!S.paper || !await requireEngine(() => live(sess))) return;
  try {
    await api(`/api/papers/${S.paper.id}/resume`, { method: 'POST', body: {}, signal: sess.signal, timeout: 15000 });
    if (live(sess)) afterResume('남은 쪽을 다시 번역합니다.');
    syncPaper(sess);
  } catch (e) {
    if (!live(sess)) return;
    if ([404, 405, 409, 400, 422].includes(e.status)) return runPaperAction('retranslate');
    toast(`다시 시도하지 못했습니다. ${errorText(e)}`, { kind: 'error' });
  }
}
export async function runPaperAction(act) {
  if (act === 'settings') return openSettings();
  if (act === 'reveal') return revealPaper();
  if (act === 'drive') { const url = driveLink(S.paper); if (url) window.open(url, '_blank', 'noopener'); return; }
  if (act !== 'retranslate' && act !== 'resummary') return;
  if (!S.docs.original || !S.paper) return toast('PDF를 연 뒤 다시 시도하세요.');
  if (S.paper.status === 'analyzing') return toast('PDF 분석이 끝나면 시작할 수 있습니다.');
  if (S.paper.scanned) return toast('전체 번역·요약에는 OCR로 인식한 텍스트가 필요합니다.');
  const sess = S.sess;
  try {
    const action = act === 'retranslate' ? { translate: true } : { translate: false, summary: true };
    const result = await requestRetranslation(S.paper.id, action, async () => {
      if (!await requireEngine(() => live(sess))) return false;
      if (act === 'retranslate' && S.paper.translated_version) return confirmDialog({
        title: '전체를 다시 번역할까요?', body: `${(S.paper.kind || 'paper') === 'paper' ? '논문' : '문서'} 본문 전체를 ${engineName()}에 보내 새로 번역합니다. 시간이 걸리고 AI 사용량이 듭니다.`, confirm: '전체 다시 번역',
      });
      return true;
    });
    if (!result || !live(sess)) return;
    if (act === 'retranslate' && !S.paper.translated_version) $('#translateStart').classList.add('hidden');
    toast(result.replayed ? '이미 접수된 요청입니다.' : act === 'retranslate' ? '번역을 시작했습니다.' : '요약을 시작했습니다.');
    syncPaper(sess);
  } catch (err) { if (live(sess)) { toast(err, { kind: 'error' }); syncPaper(sess); } }
}
let revealMissing = false;
async function revealPaper() {
  if (!S.paper) return;
  try { await api(`/api/papers/${S.paper.id}/reveal`, { method: 'POST', body: {} }); }
  catch (e) {
    if (e.status === 404 || e.status === 405) { revealMissing = true; updateMenus(); toast('이 버전에서는 폴더를 열 수 없습니다.'); }
    else toast(`폴더를 열지 못했습니다. ${errorText(e)}`, { kind: 'error' });
  }
}

export async function prepareAppExit() {
  savePos();
  await Promise.all([flushNoteDrafts(), S.position?.flush()]);
}
if (window.chrome?.webview) window.sunlightPrepareExit = async () => {
  try { await prepareAppExit(); window.chrome.webview.postMessage('sunlight-ready-to-stop'); }
  catch { window.chrome.webview.postMessage('sunlight-save-failed'); }
};

/* ---------------------------------------------------------------- reader menu */
const readerMenu = $('#moreMenu'), readerMenuButton = $('#moreBtn'), exportOptions = $('#dlMenu'), exportButton = $('#dlBtn');
export function updateMenus() {
  const p = S.paper;
  if (!p) return;
  const ready = p.translated_version > 0;
  setModeButtons();
  const translate = $('#moreMenu [data-act="retranslate"]');
  const summarize = $('#moreMenu [data-act="resummary"]');
  translate.classList.toggle('hidden', !ready);
  summarize.textContent = p.summary_status === 'idle' ? 'AI 요약 시작' : '요약 다시 생성';
  translate.disabled = summarize.disabled = !!p.storage_issue;
  $('#moreMenu [data-act="reveal"]').hidden = revealMissing;
  $('#moreMenu [data-act="drive"]').hidden = !driveLink(p);
  $$('#moreMenu [data-kind]').forEach(button => {
    button.setAttribute('aria-pressed', String(button.dataset.kind === (p.kind || 'paper')));
    button.disabled = !!p.storage_issue;
  });
  $$('#dlMenu button').forEach(button => {
    const k = button.dataset.dl;
    button.disabled = (k === 'original' && p.storage_issue === 'original') || (k === 'translated' && !ready)
      || (k === 'bilingual' && !['done', 'partial'].includes(p.status));
  });
}
function setExportOpen(open) {
  exportOptions.classList.toggle('hidden', !open);
  exportButton.setAttribute('aria-expanded', String(open));
}
export function setReaderMenuOpen(open) {
  readerMenu.classList.toggle('hidden', !open);
  readerMenuButton.setAttribute('aria-expanded', String(open));
  if (!open) setExportOpen(false);
}
readerMenuButton.onclick = () => setReaderMenuOpen(readerMenu.classList.contains('hidden'));
exportButton.onclick = () => setExportOpen(exportOptions.classList.contains('hidden'));
readerMenuButton.parentElement.addEventListener('focusout', event => {
  if (event.relatedTarget && !readerMenuButton.parentElement.contains(event.relatedTarget)) setReaderMenuOpen(false);
});
readerMenuButton.parentElement.addEventListener('keydown', event => {
  if (event.key !== 'Escape' || readerMenu.classList.contains('hidden')) return;
  event.preventDefault();
  event.stopPropagation();
  if (!exportOptions.classList.contains('hidden') && (exportOptions.contains(event.target) || event.target === exportButton)) {
    setExportOpen(false);
    exportButton.focus();
  } else {
    setReaderMenuOpen(false);
    readerMenuButton.focus();
  }
});
// Dialogs remember the currently focused element as their return target.
readerMenu.addEventListener('click', event => {
  const action = event.target.closest('button');
  if (readerMenu.classList.contains('hidden') || !action || action === exportButton || action.closest('.zoom')) return;
  setReaderMenuOpen(false);
  readerMenuButton.focus({ preventScroll: true });
}, true);
document.addEventListener('click', event => {
  if (!readerMenu.classList.contains('hidden') && !readerMenuButton.parentElement.contains(event.target)) setReaderMenuOpen(false);
});
$('#dlMenu').onclick = async e => {
  const k = e.target.closest('button:enabled')?.dataset.dl;
  if (!k || !S.paper) return;
  const id = S.paper.id, sess = S.sess;
  if (k === 'notes') {
    try { await flushNoteDrafts(draft => draft.pid === id); }
    catch { if (live(sess)) toast('메모를 저장한 뒤 다시 내보내 주세요.', { kind: 'error' }); return; }
    if (!live(sess)) return;
  }
  const a = document.createElement('a');
  a.href = k === 'notes' ? `/api/papers/${id}/export.md` : `/api/papers/${id}/file/${k}?download=true`;
  a.click();
};
$('#moreMenu').addEventListener('click', e => {
  const act = e.target.closest('button[data-act]')?.dataset.act;
  if (act) runPaperAction(act);
  const kind = e.target.closest('button[data-kind]')?.dataset.kind;
  if (kind) setDocKind(kind);
});
const KIND_AS = { paper: '논문으로', lecture: '강의자료로', general: '일반 문서로' };
// Papers keep their study sheet; lecture material is read for understanding and application; other
// documents for translation and summary. Only the next translation or summary uses the new kind.
async function setDocKind(kind) {
  const p = S.paper, sess = S.sess;
  if (!p || (p.kind || 'paper') === kind || !KIND_AS[kind]) return;
  try {
    await api(`/api/papers/${p.id}/kind`, { method: 'POST', body: { kind }, signal: sess.signal, timeout: 15000 });
    if (!live(sess)) return;
    p.kind = kind;
    updateMenus();
    const done = p.translated_version > 0 || (p.summary_status && p.summary_status !== 'idle');
    toast(`문서 종류를 ${KIND_AS[kind]} 바꿨습니다.${done ? ' 전체 다시 번역이나 요약 다시 생성을 하면 새 방식이 적용됩니다.' : ''}`, done ? { ms: 6000 } : {});
    syncPaper(sess);
  } catch (e) { if (live(sess)) toast(`문서 종류를 바꾸지 못했습니다. ${errorText(e)}`, { kind: 'error' }); }
}
$('#translateStart').onclick = async event => {
  const button = event.currentTarget;
  button.disabled = true;
  try { await runPaperAction('retranslate'); }
  finally { button.disabled = false; }
};
$('#backBtn').onclick = () => { location.hash = '#/'; };
export const readerIsOpen = () => readerShown() && !!S.paper;
